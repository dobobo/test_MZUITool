package main

import (
	"fmt"
	"io/ioutil"
	"log"
	"os"
	"path/filepath"
	"regexp"
	"strings"

	"github.com/lxn/walk"
	. "github.com/lxn/walk/declarative"
	"github.com/rentiansheng/xlsx"
)

type MyMainWindow struct {
	*walk.MainWindow
	edit                 *walk.TextEdit
	sourcePath           string
	destPath             string
	transPath            string
	sourceSearchBox      *walk.LineEdit
	destSearchBox        *walk.LineEdit
	transSearchBox       *walk.LineEdit
	selectExcelSheetName *walk.LineEdit
	dir                  string
}

func main() {
	mw := &MyMainWindow{}

	mw.dir, _ = os.Getwd()

	f, err := os.Open(mw.dir + "\\export_dir.txt")
	if err != nil {
		fmt.Println(err)
	}
	defer f.Close()

	exportDir, err := ioutil.ReadAll(f)

	f, err = os.Open(mw.dir + "\\import_dir.txt")
	if err != nil {
		fmt.Println(err)
	}
	importDir, err := ioutil.ReadAll(f)

	MW := MainWindow{
		AssignTo: &mw.MainWindow,
		Title:    "自動翻訳",
		MinSize:  Size{300, 200},
		Size:     Size{500, 400},
		Layout:   VBox{},
		Children: []Widget{
			GroupBox{
				Layout: HBox{},
				Children: []Widget{
					LineEdit{
						AssignTo: &mw.transSearchBox,
					},
					PushButton{
						Text:      "翻訳Excelファイル",
						OnClicked: mw.transPbClicked,
					},
				},
			},
			GroupBox{
				Layout: HBox{},
				Children: []Widget{
					Label{Font: Font{PointSize: 12}, Text: "Excelシート名指定"},
					LineEdit{
						AssignTo: &mw.selectExcelSheetName,
					},
				},
			},
			GroupBox{
				Layout: HBox{},
				Children: []Widget{
					LineEdit{
						AssignTo: &mw.sourceSearchBox,
						Text:     string(importDir),
					},
					PushButton{
						Text:      "元データフォルダ",
						OnClicked: mw.sourcePbClicked,
					},
				},
			},
			GroupBox{
				Layout: HBox{},
				Children: []Widget{
					LineEdit{
						AssignTo: &mw.destSearchBox,
						Text:     string(exportDir),
					},
					PushButton{
						Text:      "保存先フォルダ",
						OnClicked: mw.dest_pbClicked,
					},
				},
			},
			PushButton{
				Text:      "実行",
				OnClicked: mw.execute,
			},
		},
	}
	if _, err := MW.Run(); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}

func (mw *MyMainWindow) sourcePbClicked() {

	dlg := new(walk.FileDialog)
	dlg.FilePath = mw.sourcePath
	dlg.Title = "翻訳する元データフォルダを選択してください"
	dlg.Filter = "All files (*.*)|*.*"

	if ok, err := dlg.ShowBrowseFolder(mw); err != nil {
		walk.MsgBox(mw, "エラー", "ファイルオープンエラー", walk.MsgBoxOK)
		return
	} else if !ok {
		return
	}
	mw.sourcePath = dlg.FilePath
	s := fmt.Sprintf("%s\r\n", mw.sourcePath)
	mw.sourceSearchBox.SetText(s)
}

func (mw *MyMainWindow) dest_pbClicked() {

	dlg := new(walk.FileDialog)
	dlg.FilePath = mw.destPath
	dlg.Title = "翻訳したファイルを保存するフォルダ先を選択してください"
	dlg.Filter = "All files (*.*)|*.*"

	if ok, err := dlg.ShowBrowseFolder(mw); err != nil {
		walk.MsgBox(mw, "エラー", "ファイルオープンエラー", walk.MsgBoxOK)
		return
	} else if !ok {
		return
	}
	mw.destPath = dlg.FilePath
	s := fmt.Sprintf("%s\r\n", mw.destPath)
	mw.destSearchBox.SetText(s)
}

func (mw *MyMainWindow) transPbClicked() {

	dlg := new(walk.FileDialog)
	dlg.FilePath = mw.transPath
	dlg.Title = "翻訳Excelファイルを選択してください"
	dlg.Filter = "All files (*.*)|*.*"

	if ok, err := dlg.ShowOpen(mw); err != nil {
		walk.MsgBox(mw, "エラー", "ファイルオープンエラー", walk.MsgBoxOK)
		return
	} else if !ok {
		return
	}
	mw.transPath = dlg.FilePath
	s := fmt.Sprintf("%s\r\n", mw.transPath)
	mw.transSearchBox.SetText(s)
}

func (mw *MyMainWindow) execute() {
	transSearchBoxText := mw.transSearchBox.Text()
	sourceSearchBoxText := mw.sourceSearchBox.Text()
	destSearchBoxText := mw.destSearchBox.Text()

	file, err := os.Create(mw.dir + "\\export_dir.txt")
	if err != nil {
		fmt.Println(err)
	}
	defer file.Close()

	file.Write(([]byte)(destSearchBoxText))

	file, err = os.Create(mw.dir + "\\import_dir.txt")
	if err != nil {
		fmt.Println(err)
	}

	file.Write(([]byte)(sourceSearchBoxText))

	dir := strings.TrimRight(sourceSearchBoxText, "\r\n")

	files, err := ioutil.ReadDir(dir)
	if err != nil {
		fmt.Println(err)
	}

	for _, file := range files {
		sourceSearchBoxText = filepath.Join(dir, file.Name())

		dirNameSlice_hoge := strings.Split(sourceSearchBoxText, "\\")
		sourceName := dirNameSlice_hoge[len(dirNameSlice_hoge)-1]
		sourceName = strings.TrimRight(sourceName, "\r\n")

		if !strings.Contains(transSearchBoxText, ".xlsx") {
			walk.MsgBox(mw, "エラー", "翻訳ファイルはxlsx形式のものを選んでください", walk.MsgBoxOKCancel)
			return
		}
		if strings.Contains(sourceName, ".json") {
			sourceName = strings.Replace(sourceName, ".json", "", -1)
		} else {
			walk.MsgBox(mw, "エラー", "元データはjson形式のものを選んでください", walk.MsgBoxOKCancel)
			return
		}

		dirNameSliceLtrim := dirNameSlice_hoge[:len(dirNameSlice_hoge)-1]

		// root_dir := strings.Join(dirNameSliceLtrim[:5], "/")

		dirNameLtrim := strings.Join(dirNameSliceLtrim, "/")
		dirNameLtrim = dirNameLtrim + "/" + sourceName

		if sourceName == "Scripts" {
			walk.MsgBox(mw, "エラー", "このゲームデータは翻訳しないでください。"+sourceName+".rvdata2", walk.MsgBoxOKCancel)
			return
		}

		destSearchBoxText = strings.TrimRight(destSearchBoxText, "\r\n")

		sheetNum := 0

		transMap := map[string]string{}
		untransMap := map[string]string{}
		transSearchBoxText = strings.TrimRight(transSearchBoxText, "\r\n")
		excel, err1 := xlsx.OpenFile(transSearchBoxText)
		if err1 != nil {
			walk.MsgBox(mw, "エラー", "Excelファイルを開けませんでした", walk.MsgBoxOKCancel)
			return
		}

		outputName := sourceName
		if mw.selectExcelSheetName.Text() != "" {
			sourceName = mw.selectExcelSheetName.Text()
		}

		for index, sheet := range excel.Sheets {
			if sheet.Name == sourceName {
				fmt.Println("Excelシートの存在確認: " + sheet.Name)
				sheetNum = index
				break
			}
			if len(excel.Sheets)-1 <= index {
				walk.MsgBox(mw, "エラー", "error: 与えられた名前のExcelシートはありません。"+sourceName, walk.MsgBoxOKCancel)
				os.Exit(0)
			}
		}

		for _, row := range excel.Sheets[sheetNum].Rows {
			for _, _ = range row.Cells {
				key := row.Cells[0].String()
				value := row.Cells[1].String()
				transMap[key] = value
				break
			}
		}

		untransMap = transMap
		jsonString, err := ioutil.ReadFile(sourceSearchBoxText)
		if err != nil {
			walk.MsgBox(mw, "エラー", "一時フォルダからjsonファイルを読み込ませんでした", walk.MsgBoxOKCancel)
			os.Exit(1)
		}

		threeOrMoreLineFeeds := ""

		sourceStr := string(jsonString)
		for key, value := range transMap {
			replaceStr := "\\" + "\""
			value = strings.Replace(value, "\"", replaceStr, -1)
			key = strings.Replace(key, "…", "…", -1)
			keyTmp := strings.Replace(key, "*", "\\*", -1)
			keyTmp = strings.Replace(keyTmp, "+", "\\+", -1)
			keyTmp = strings.Replace(keyTmp, "{", "\\{", -1)
			keyTmp = strings.Replace(keyTmp, "}", "\\}", -1)
			keyTmp = strings.Replace(keyTmp, "^", "\\^", -1)
			keyTmp = strings.Replace(keyTmp, "$", "\\$", -1)
			keyTmp = strings.Replace(keyTmp, "-", "\\-", -1)
			keyTmp = strings.Replace(keyTmp, "|", "\\|", -1)
			keyTmp = strings.Replace(keyTmp, "(", "\\(", -1)
			keyTmp = strings.Replace(keyTmp, ")", "\\)", -1)
			keyTmp = strings.Replace(keyTmp, "+", "\\+", -1)
			keyTmp = strings.Replace(keyTmp, "?", "\\?", -1)

			maxOneLine := 50
			if strings.Contains(sourceName, "Map") || strings.Contains(sourceName, "Common") {
				maxOneLine = 59
			}

			if len(value) > maxOneLine {
				if len(value) > 177 {
					threeOrMoreLineFeeds = value + "\r\n"
					fmt.Println("改行3回以上必要" + threeOrMoreLineFeeds)
					continue
				}
				value = strings.Replace(value, "\r\n", " ", -1)
				sourceChar := ""
				sourceChars := strings.Split(value, "\r\n")
				value = ""
				for _, sourceCharsValue := range sourceChars {
					char := strings.Split(sourceCharsValue, " ")
					if len(sourceCharsValue) >= maxOneLine {
						charLength := 0
						for charIndex, charValue := range char {
							charLength += len(charValue) + 1
							if charLength > maxOneLine {
								char[charIndex] = "\\r\\n" + charValue
								charLength = len(charValue)
							}
							sourceChar = strings.Join(char, " ")
						}
						value += sourceChar
					}
				}
			}

			pettern := regexp.MustCompile("\"" + keyTmp + "\"")
			fmt.Println(pettern)

			tmp_sourceStr := sourceStr
			sourceStr = pettern.ReplaceAllString(sourceStr, "\""+value+"\"")

			if sourceStr != tmp_sourceStr {
				delete(untransMap, key)
			}
		}

		if err := os.MkdirAll(destSearchBoxText+"\\未翻訳", 0777); err != nil {
			walk.MsgBox(mw, "エラー", "未翻訳フォルダを作成できませんでした", walk.MsgBoxOKCancel)
			os.Exit(0)
		}

		if err := os.Remove(destSearchBoxText + "\\" + outputName + ".json"); err != nil {
		}
		trans_file, err := os.OpenFile(destSearchBoxText+"\\"+outputName+".json", os.O_RDWR|os.O_CREATE|os.O_EXCL, 0666)
		// trans_file, err := os.OpenFile(".\\"+outputName+".json", os.O_RDWR|os.O_CREATE|os.O_EXCL, 0666)
		if err != nil {
			walk.MsgBox(mw, "エラー", "既に保存するべきファイルが存在するため実行できません", walk.MsgBoxOKCancel)
			log.Fatal(err)
		}
		fmt.Fprintln(trans_file, sourceStr)

		untrans_text := "日本語 : 英語 \r\n"
		for key, value := range untransMap {
			untrans_text += key
			untrans_text += ":"
			untrans_text += value
			untrans_text += "\r\n"
		}

		if err := os.Remove(destSearchBoxText + "\\未翻訳\\" + outputName + "未翻訳ver.txt"); err != nil {
		}
		untrans_file, err := os.OpenFile(destSearchBoxText+"\\未翻訳\\"+outputName+"未翻訳ver.txt", os.O_RDWR|os.O_CREATE|os.O_EXCL, 0666)
		if err != nil {
			walk.MsgBox(mw, "エラー", "既に保存するべきファイルが存在するため実行できません", walk.MsgBoxOKCancel)
			log.Fatal(err)
		}
		fmt.Println("----------未翻訳-----------------")
		fmt.Println(untrans_text)
		fmt.Println("---------------------------------")
		fmt.Fprintln(untrans_file, untrans_text)

		transJsonString, err := ioutil.ReadFile(destSearchBoxText + "\\" + outputName + ".json")
		if err != nil {
			walk.MsgBox(mw, "エラー", "翻訳済みのjsonファイルを読み込ませんでした", walk.MsgBoxOKCancel)
			os.Exit(1)
		}

		japaneseKey := "\"" + ".*([ぁ-ん]*[ァ-ヶ]*[亜-熙])+.*" + "\""

		japanesePettern := regexp.MustCompile(japaneseKey)
		foobar := japanesePettern.FindAllStringSubmatch(string(transJsonString), -1)
		foobarText := ""
		for index := range foobar {
			foobarText += foobar[index][0] + " \r\n"
		}
		if e := os.MkdirAll(destSearchBoxText+"\\未翻訳ver2\\", 0777); e != nil {
			walk.MsgBox(mw, "エラー", "未翻訳フォルダver2を作成できませんでした", walk.MsgBoxOKCancel)
			os.Exit(0)
		}

		if err := os.Remove(destSearchBoxText + "\\未翻訳ver2\\" + outputName + "未翻訳ver.txt"); err != nil {
		}
		foobar_file, err := os.OpenFile(destSearchBoxText+"\\未翻訳ver2\\"+outputName+"未翻訳ver.txt", os.O_RDWR|os.O_CREATE|os.O_EXCL, 0666)
		if err != nil {
			walk.MsgBox(mw, "エラー", "既に保存するべきファイルが存在するため実行できません", walk.MsgBoxOKCancel)
			log.Fatal(err)
		}
		fmt.Fprintln(foobar_file, foobarText)

		transMap = make(map[string]string)
		untransMap = make(map[string]string)
	}
	walk.MsgBox(mw, "完了", "処理が完了しました", walk.MsgBoxOKCancel)
	os.Exit(0)
}
