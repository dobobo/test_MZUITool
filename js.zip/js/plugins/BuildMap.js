/*:
 * @target MZ
 * @plugindesc 建築テンプレ（別マップ）を指定マップに貼り付け（タイル＋イベント）＋削除対応 v0.4.1（座標指定削除A採用）＋設置プレビュー（緑/赤）＋テンプレ半透明ゴースト表示（タイル）＋イベントプレビュー(B案)＋スプライト同期修正＋イベントメモ禁止矩形 v0.4.2
 * @author DB
 *
 * @help
 * ■概要
 * - テンプレ用マップから矩形領域を切り出し、任意マップ座標へ貼り付けます。
 * - タイルは4層（0..3）＋リージョン層（z=5）をコピーします。
 * - テンプレ領域内のイベントも相対座標で複製し、動的イベントとして配置します。
 * - 変更内容はセーブに保存され、ロード後も復元されます。
 *
 * ■削除仕様（v0.3：A採用）
 * - 削除は RemoveBuildingAt（座標指定）だけを公開します。
 * - RemoveBuildingAt は「指定座標が建築矩形範囲内に入っている建物」を特定して一括削除します。
 *   → 1マスずれて指定した場合は「消えない（ブザー）」だけで、中途半端に消える事故が起きません。
 * - 建築時に「上書き前タイル(before)」を保存しているため、削除時に確実に復元できます。
 *
 * ■プレビュー（追加）
 * - 建築モード中、設置予定の矩形範囲を画面上に表示します。
 * - 建築可能→緑、不可→赤
 *
 * ■テンプレ半透明ゴースト（v0.4追加）
 * - 建築モード中、テンプレ建築物（タイル）を半透明で表示します（ゴースト表示）。
 * - 置ける場所→濃いめ、置けない場所→薄め（alpha変更）
 *
 * ■イベントプレビュー（B案：今回追加）
 * - 建築/移動モード中、テンプレ内イベントの「見た目だけ」をダミーイベントとして動的生成し表示します。
 * - 実行内容(list)は空、トリガーも起動しない設定にしてあるため、プレビュー中にイベントが動作することはありません。
 *
 * ■前提
 * - タイルセットは同一（または互換）である想定。
 * - 建築可否はリージョンIDで判定できます。
 *
 * ■リージョン判定（例）
 * - BuildForbiddenRegion（禁止）上は絶対に置けない
 * - BuildAllowedRegion（許可）を0以外にした場合、そのリージョン上でのみ置ける
 *
 * ■イベントメモによる建築禁止矩形
 * - イベントのメモ欄に <prohibit:スイッチID,横幅,縦幅> と書くと、
 *   そのイベントの現在位置を左上として、指定サイズの矩形が建築禁止になります。
 * - 例：<prohibit:10,3,2>
 *   → スイッチ10がOFFの間、イベント位置から横3×縦2マスが建築禁止。
 * - 指定スイッチがONになると、その禁止設定は無効になります。
 * - 通常イベント、動的イベントの両方を判定します。
 *
 * ■注意
 * - リージョン層（z=5）もコピーします。建築禁止リージョンは通行不可として扱います。
 * - 現状：タイル衝突（通行可否）までは見ません（必要なら isPassable 判定を追加）。
 * - 現状：建築同士の重なりは禁止（削除復元の堅牢性優先）。
 * - 現状：targetMapId は「現在マップ」だけ対応（拡張可能）。
 *
 * ------------------------------------------------------------------
 * @param Templates
 * @text テンプレ定義
 * @type struct<BuildTemplate>[]
 * @default []
 *
 * @param BuildAllowedRegion
 * @text 建築許可リージョン（0=無制限）
 * @type number
 * @default 0
 *
 * @param BuildForbiddenRegion
 * @text 建築禁止リージョン（0=なし）
 * @type number
 * @default 0
 *
 * @param BuildCancelSwitchId
 * @text 建築モードキャンセル時スイッチON（0=なし）
 * @type switch
 * @default 0
 *
 * @param BuildCancelCommonEventId
 * @text 建築モードキャンセル時コモンイベント（0=なし）
 * @type common_event
 * @default 0
 *
 * @param MoveCancelSwitchId
 * @text 移動モードキャンセル時スイッチON（0=なし）
 * @type switch
 * @default 0
 *
 * @param MoveCancelCommonEventId
 * @text 移動モードキャンセル時コモンイベント（0=なし）
 * @type common_event
 * @default 0
 *
 * @param BuildStartCommonEventId
 * @text 建築モード開始前コモンイベント（0=なし）
 * @type common_event
 * @default 0
 *
 * @param MoveStartCommonEventId
 * @text 移動モード開始前コモンイベント（0=なし）
 * @type common_event
 * @default 0

 * @param BuildModeCompleteCommonEventId
 * @text 建築モード完了時コモンイベント（0=なし）
 * @type common_event
 * @default 0
 *
 * @param PlaceCommandCompleteCommonEventId
 * @text 即時配置完了時コモンイベント（0=なし）
 * @type common_event
 * @default 0
 *
 * @command OpenBuildMode
 * @text 建築モード開始
 * @arg templateId
 * @text テンプレID
 * @type string
 * @default
 *
 * @command SetSharedMaps
 * @text 共有マップID設定
 * @desc 建築を同期するマップID一覧を設定します（カンマ区切り）。例: 11,12,13,14
 * @arg mapIds
 * @text 共有マップID一覧（カンマ区切り）
 * @type string
 * @default
 *
 * @command ClearSharedMaps
 * @text 共有マップIDクリア
 * @desc 共有マップ設定をクリアします（同期しない）
 * 
 * @arg targetMapId
 * @text 対象マップID（0=現在マップ）
 * @type number
 * @default 0
 *
 * @command SetCancelHandlers
 * @text キャンセル時挙動設定
 *
 * @arg buildCancelSwitchId
 * @text 建築キャンセル：ONにするスイッチ（0=なし）
 * @type switch
 * @default 0
 *
 * @arg buildCancelCommonEventId
 * @text 建築キャンセル：呼ぶコモンイベント（0=なし）
 * @type common_event
 * @default 0
 *
 * @arg moveCancelSwitchId
 * @text 移動キャンセル：ONにするスイッチ（0=なし）
 * @type switch
 * @default 0
 *
 * @arg moveCancelCommonEventId
 * @text 移動キャンセル：呼ぶコモンイベント（0=なし）
 * @type common_event
 * @default 0
 *
 * @command PlaceBuilding
 * @text 建築配置（即時）
 * @arg templateId
 * @text テンプレID
 * @type string
 * @default
 *
 * @arg x
 * @text 配置X
 * @type number
 * @default 0
 *
 * @arg y
 * @text 配置Y
 * @type number
 * @default 0
 *
 * @arg targetMapId
 * @text 対象マップID（0=現在マップ）
 * @type number
 * @default 0
 *
 * @command RemoveBuildingAt
 * @text 建築削除（座標指定）
 * @arg x
 * @text 指定X
 * @type number
 * @default 0
 *
 * @arg y
 * @text 指定Y
 * @type number
 * @default 0
 *
 * @arg targetMapId
 * @text 対象マップID（0=現在マップ）
 * @type number
 * @default 0
 *
 * @command SetBuildRegions
 * @text 建築リージョン設定
 * @arg allowed
 * @text 許可リージョン（0=無制限）
 * @type number
 * @default 0
 *
 * @arg forbidden
 * @text 禁止リージョン（0=なし）
 * @type number
 * @default 0
 *
 * @command OpenMoveMode
 * @text 建築移動モード開始
 * @arg x
 * @text 移動元X（建物内の座標 / -1=プレイヤーX）
 * @type number
 * @default -1
 *
 * @arg y
 * @text 移動元Y（建物内の座標 / -1=プレイヤーY）
 * @type number
 * @default -1
 *
 * @arg targetMapId
 * @text 対象マップID（0=現在マップ）
 * @type number
 * @default 0
 *
 * @command MoveBuildingAt
 * @text 建築移動（座標指定）
 * @arg fromX
 * @text 移動元X（建物内の座標）
 * @type number
 * @default 0
 *
 * @arg fromY
 * @text 移動元Y（建物内の座標）
 * @type number
 * @default 0
 *
 * @arg toX
 * @text 移動先X（基準）
 * @type number
 * @default 0
 *
 * @arg toY
 * @text 移動先Y（基準）
 * @type number
 * @default 0
 *
 * @arg targetMapId
 * @text 対象マップID（0=現在マップ）
 * @type number
 * @default 0

 *
 * @command RecalculateBuildingEffects
 * @text 建築効果再計算
 * @desc 指定マップ群の建築効果を再集計して変数へ反映します
 * @arg targetMapIds
 * @text 対象マップID一覧（カンマ区切り / 0=現在）
 * @type string
 * @default 0
 *
 * @command CountBuildings
 * @text 建物数カウント
 * @desc 指定テンプレIDの建物数を数えて変数へ格納します
 * @arg templateIds
 * @text テンプレID一覧（カンマ区切り / 空=全件）
 * @type string
 * @default
 *
 * @arg targetMapIds
 * @text 対象マップID一覧（カンマ区切り / 0=現在）
 * @type string
 * @default 0
 *
 * @arg resultVariableId
 * @text 結果格納変数ID
 * @type variable
 * @default 0
 *
 * @command RecalculateBuildingAreaEffects
 * @text 建築範囲効果再計算
 * @desc 指定マップ群の範囲効果を再集計して変数へ反映します
 * @arg targetMapIds
 * @text 対象マップID一覧（カンマ区切り / 0=現在）
 * @type string
 * @default 0

 */

/*~struct~BuildTemplate:
 * @param id
 * @text テンプレID
 * @type string
 * @default HOME_1
 *
 * @param sourceMapId
 * @text テンプレマップID
 * @type number
 * @default 1
 *
 * @param rectX
 * @text 矩形X
 * @type number
 * @default 0
 *
 * @param rectY
 * @text 矩形Y
 * @type number
 * @default 0
 *
 * @param rectW
 * @text 矩形W
 * @type number
 * @default 1
 *
 * @param rectH
 * @text 矩形H
 * @type number
 * @default 1
 *
 * @param anchorX
 * @text アンカーX（貼り付け原点）
 * @type number
 * @default 0
 *
 * @param anchorY
 * @text アンカーY（貼り付け原点）
 * @type number
 * @default 0
 *
 * @param effects
 * @text 建築効果一覧
 * @type struct<BuildEffect>[]
 * @default []
 *
 * @param areaEffects
 * @text 範囲効果一覧
 * @type struct<BuildAreaEffect>[]
 * @default []
 */

/*~struct~BuildEffect:
 * @param variableId
 * @text 変数ID
 * @type variable
 * @default 0
 *
 * @param value
 * @text 効果値
 * @type number
 * @min -999999
 * @max 999999
 * @default 0
 */

/*~struct~BuildAreaEffect:
 * @param variableId
 * @text 結果変数ID
 * @type variable
 * @default 0
 *
 * @param value
 * @text 1件あたり効果値
 * @type number
 * @min -999999
 * @max 999999
 * @default 0
 *
 * @param range
 * @text 範囲半径
 * @type number
 * @min 0
 * @default 1
 *
 * @param targetTemplateIds
 * @text 対象テンプレID一覧（カンマ区切り / 空=全建物）
 * @type string
 * @default
 *
 * @param shape
 * @text 範囲形状
 * @type select
 * @option diamond
 * @option square
 * @default diamond
 */

(() => {
  "use strict";

  const PLUGIN_NAME = document.currentScript.src.split("/").pop().replace(/\.js$/, "");
  const params = PluginManager.parameters(PLUGIN_NAME);

  const BUILD_COPY_LAYERS = [1, 2, 3, 5]; // z=5: region layer
  const BUILD_PREVIEW_LAYERS = [1, 2, 3]; // preview/ghost is visual only

  const forEachBuildCopyLayer = (fn) => {
    for (const z of BUILD_COPY_LAYERS) fn(z);
  };


  const parseEffects = (raw) => {
    const arr = JSON.parse(raw || "[]");
    return arr.map(s => {
      const e = JSON.parse(s);
      return {
        variableId: Number(e.variableId || 0),
        value: Number(e.value || 0),
      };
    }).filter(e => e.variableId > 0 && e.value !== 0);
  };

  const parseAreaEffects = (raw) => {
    const arr = JSON.parse(raw || "[]");
    return arr.map(s => {
      const e = JSON.parse(s);
      return {
        variableId: Number(e.variableId || 0),
        value: Number(e.value || 0),
        range: Math.max(0, Number(e.range || 0)),
        targetTemplateIds: String(e.targetTemplateIds || ""),
        shape: String(e.shape || "diamond"),
      };
    }).filter(e => e.variableId > 0 && e.value !== 0);
  };

  const parseTemplates = () => {
    const raw = JSON.parse(params.Templates || "[]");
    const list = raw.map(s => JSON.parse(s));
    const map = new Map();
    for (const t of list) {
      const effects = parseEffects(t.effects);
      const areaEffects = parseAreaEffects(t.areaEffects);
      const legacyVarId = Number(t.effectVariableId || 0);
      const legacyValue = Number(t.effectValue || 0);
      if (effects.length === 0 && legacyVarId > 0 && legacyValue !== 0) {
        effects.push({ variableId: legacyVarId, value: legacyValue });
      }

      map.set(String(t.id), {
        id: String(t.id),
        sourceMapId: Number(t.sourceMapId || 0),
        rectX: Number(t.rectX || 0),
        rectY: Number(t.rectY || 0),
        rectW: Number(t.rectW || 1),
        rectH: Number(t.rectH || 1),
        anchorX: Number(t.anchorX || 0),
        anchorY: Number(t.anchorY || 0),
        effects: effects,
        areaEffects: areaEffects,
      });
    }
    return map;
  };

  // -------------------------------------------------------------------
  // BuildManager（セーブ対象）
  // -------------------------------------------------------------------
  const BuildManager = {
    _templates: parseTemplates(),
    _sharedMapIds: [], // ★共有マップ（このリストに入っているマップへ建築を同期する）
    _allowedRegion: Number(params.BuildAllowedRegion || 0),
    _forbiddenRegion: Number(params.BuildForbiddenRegion || 0),
    _buildCancelSwitchId: Number(params.BuildCancelSwitchId || 0),
    _buildCancelCommonEventId: Number(params.BuildCancelCommonEventId || 0),
    _moveCancelSwitchId: Number(params.MoveCancelSwitchId || 0),
    _moveCancelCommonEventId: Number(params.MoveCancelCommonEventId || 0),
    _buildStartCommonEventId: Number(params.BuildStartCommonEventId || 0),
    _moveStartCommonEventId: Number(params.MoveStartCommonEventId || 0),
    _buildModeCompleteCommonEventId: Number(params.BuildModeCompleteCommonEventId || 0),
    _placeCommandCompleteCommonEventId: Number(params.PlaceCommandCompleteCommonEventId || 0),
    _pendingModeStart: null,

    setCancelHandlers(buildSw, buildCe, moveSw, moveCe) {
      this._buildCancelSwitchId = Number(buildSw || 0);
      this._buildCancelCommonEventId = Number(buildCe || 0);
      this._moveCancelSwitchId = Number(moveSw || 0);
      this._moveCancelCommonEventId = Number(moveCe || 0);
    },

    // mode: "build" | "move"
    runCancelHandlers(mode) {
      const isBuild = (mode === "build");
      const swId = isBuild ? this._buildCancelSwitchId : this._moveCancelSwitchId;
      const ceId = isBuild ? this._buildCancelCommonEventId : this._moveCancelCommonEventId;

      if (swId > 0) $gameSwitches.setValue(swId, true);
      if (ceId > 0) $gameTemp.reserveCommonEvent(ceId);
    },

    runBuildModeCompleteHandler() {
      const ceId = Number(this._buildModeCompleteCommonEventId || 0);
      if (ceId > 0) $gameTemp.reserveCommonEvent(ceId);
    },

    runPlaceCommandCompleteHandler() {
      const ceId = Number(this._placeCommandCompleteCommonEventId || 0);
      if (ceId > 0) $gameTemp.reserveCommonEvent(ceId);
    },

    _dataByMap: {},

    setRegions(allowed, forbidden) {
      this._allowedRegion = Number(allowed || 0);
      this._forbiddenRegion = Number(forbidden || 0);
    },

    isForbiddenRegionId(regionId) {
      const rid = Number(regionId || 0);
      return this._forbiddenRegion > 0 && rid === this._forbiddenRegion;
    },

    isRegionPassageBlocked(x, y, mapId = 0) {
      const targetMapId = Number(mapId || 0) || $gameMap.mapId();
      if (targetMapId !== $gameMap.mapId()) return false;
      if (!$gameMap || !$gameMap.isValid(x, y)) return false;
      return this.isForbiddenRegionId($gameMap.regionId(x, y));
    },


    // ------------------------------------------------------------
    // ★共有マップ設定
    // ------------------------------------------------------------
    setSharedMaps(mapIds) {
      // mapIds: number[] | string("1,2,3")
      let arr = [];
      if (Array.isArray(mapIds)) {
        arr = mapIds;
      } else {
        const s = String(mapIds || "").trim();
        if (s.length > 0) {
          arr = s.split(",").map(v => Number(v.trim())).filter(n => Number.isFinite(n) && n > 0);
        }
      }
      // 重複排除
      const uniq = [];
      const set = new Set();
      for (const id of arr) {
        if (set.has(id)) continue;
        set.add(id);
        uniq.push(id);
      }
      this._sharedMapIds = uniq;
    },

    clearSharedMaps() {
      this._sharedMapIds = [];
    },

    // “同期対象” を返す（必ず baseMapId を含む）
    _sharingTargets(baseMapId) {
      const base = Number(baseMapId || 0);
      const out = [];
      const set = new Set();
      if (base > 0) {
        set.add(base);
        out.push(base);
      }
      for (const id of (this._sharedMapIds || [])) {
        const n = Number(id || 0);
        if (!Number.isFinite(n) || n <= 0) continue;
        if (set.has(n)) continue;
        set.add(n);
        out.push(n);
      }
      return out;
    },

    // rect範囲のキー一覧（建築コピー対象レイヤー）
    _tileKeysForRect(pasteX, pasteY, w, h) {
      const keys = [];
      for (let dy = 0; dy < h; dy++) {
        for (let dx = 0; dx < w; dx++) {
          const tx = pasteX + dx;
          const ty = pasteY + dy;
          forEachBuildCopyLayer((z) => {
            keys.push(`${tx},${ty},${z}`);
          });
        }
      }
      return keys;
    },

    // ★共有先マップの before タイルを MapXXX.json から採取
    async _snapshotTilesBeforeFromMapFile(mapId, pasteX, pasteY, w, h) {
      const mid = Number(mapId || 0);
      const mapData = await BuildTemplateManager._loadMapDataAsync(mid);

      const width = mapData.width;
      const height = mapData.height;

      const getTile = (x, y, z) => {
        const idx = (z * height + y) * width + x;
        return mapData.data[idx] || 0;
      };

      const before = {};
      for (let dy = 0; dy < h; dy++) {
        for (let dx = 0; dx < w; dx++) {
          const tx = pasteX + dx;
          const ty = pasteY + dy;
          forEachBuildCopyLayer((z) => {
            const key = `${tx},${ty},${z}`;
            before[key] = getTile(tx, ty, z);
          });
        }
      }
      return before;
    },

    ensureMapData(mapId) {
      if (!this._dataByMap[mapId]) {
        this._dataByMap[mapId] = { buildings: [], tiles: {}, dynEvents: [] };
      } else {
        if (!this._dataByMap[mapId].buildings) this._dataByMap[mapId].buildings = [];
        if (!this._dataByMap[mapId].tiles) this._dataByMap[mapId].tiles = {};
        if (!this._dataByMap[mapId].dynEvents) this._dataByMap[mapId].dynEvents = [];
      }
      return this._dataByMap[mapId];
    },

    template(templateId) {
      return this._templates.get(String(templateId));
    },

    parseTargetMapIds(mapIds) {
      if (Array.isArray(mapIds)) {
        const arr = mapIds.map(Number).filter(n => Number.isFinite(n) && n > 0);
        return arr.length > 0 ? [...new Set(arr)] : [$gameMap.mapId()];
      }

      const s = String(mapIds || "").trim();
      if (!s || s === "0") return [$gameMap.mapId()];

      const arr = s.split(",").map(v => Number(v.trim())).filter(n => Number.isFinite(n) && n > 0);
      return arr.length > 0 ? [...new Set(arr)] : [$gameMap.mapId()];
    },

    recalculateBuildingEffects(mapIds) {
      const targetMapIds = this.parseTargetMapIds(mapIds);
      const sums = {};
      const targetVarIds = new Set();

      for (const [, t] of this._templates) {
        const effects = Array.isArray(t.effects) ? t.effects : [];
        for (const e of effects) {
          const varId = Number(e.variableId || 0);
          if (varId > 0) targetVarIds.add(varId);
        }
      }

      for (const varId of targetVarIds) {
        sums[varId] = 0;
      }

      for (const mapId of targetMapIds) {
        const store = this.ensureMapData(mapId);
        const buildings = store.buildings || [];

        for (const b of buildings) {
          const t = this.template(b.templateId);
          if (!t || !Array.isArray(t.effects)) continue;

          for (const e of t.effects) {
            const varId = Number(e.variableId || 0);
            const value = Number(e.value || 0);
            if (varId <= 0 || value === 0) continue;
            sums[varId] = (sums[varId] || 0) + value;
          }
        }
      }

      for (const varId of targetVarIds) {
        $gameVariables.setValue(Number(varId), Number(sums[varId] || 0));
      }

      return {
        ok: true,
        mapIds: targetMapIds,
        values: sums
      };
    },

    countBuildings(templateIds, mapIds) {
      const targetMapIds = this.parseTargetMapIds(mapIds);

      let targetTemplateIds = [];
      if (Array.isArray(templateIds)) {
        targetTemplateIds = templateIds.map(String);
      } else {
        const s = String(templateIds || "").trim();
        if (s.length > 0) {
          targetTemplateIds = s.split(",").map(v => String(v.trim())).filter(v => v.length > 0);
        }
      }

      const hasFilter = targetTemplateIds.length > 0;
      const filterSet = new Set(targetTemplateIds);
      let count = 0;

      for (const mapId of targetMapIds) {
        const store = this.ensureMapData(mapId);
        const buildings = store.buildings || [];

        for (const b of buildings) {
          if (!hasFilter || filterSet.has(String(b.templateId))) {
            count++;
          }
        }
      }

      return {
        ok: true,
        mapIds: targetMapIds,
        templateIds: targetTemplateIds,
        count: count
      };
    },

    getBuildingCenter(building) {
      return {
        x: Number(building.pasteX || 0) + Math.floor(Number(building.w || 1) / 2),
        y: Number(building.pasteY || 0) + Math.floor(Number(building.h || 1) / 2),
      };
    },

    isWithinRange(ax, ay, bx, by, range, shape) {
      const dx = Math.abs(ax - bx);
      const dy = Math.abs(ay - by);
      if (String(shape || "diamond") === "square") {
        return dx <= range && dy <= range;
      } else {
        return dx + dy <= range;
      }
    },

    recalculateBuildingAreaEffects(mapIds) {
      const targetMapIds = this.parseTargetMapIds(mapIds);
      const sums = {};
      const targetVarIds = new Set();

      for (const [, t] of this._templates) {
        const areaEffects = Array.isArray(t.areaEffects) ? t.areaEffects : [];
        for (const e of areaEffects) {
          const varId = Number(e.variableId || 0);
          if (varId > 0) targetVarIds.add(varId);
        }
      }

      for (const varId of targetVarIds) {
        sums[varId] = 0;
      }

      for (const mapId of targetMapIds) {
        const store = this.ensureMapData(mapId);
        const buildings = store.buildings || [];

        for (const source of buildings) {
          const tpl = this.template(source.templateId);
          if (!tpl || !Array.isArray(tpl.areaEffects) || tpl.areaEffects.length === 0) continue;

          const sc = this.getBuildingCenter(source);

          for (const ae of tpl.areaEffects) {
            const varId = Number(ae.variableId || 0);
            const value = Number(ae.value || 0);
            const range = Number(ae.range || 0);
            const shape = String(ae.shape || "diamond");
            const targetIds = String(ae.targetTemplateIds || "")
              .split(",")
              .map(s => String(s.trim()))
              .filter(s => s.length > 0);

            if (varId <= 0 || value === 0 || range < 0) continue;

            const hasFilter = targetIds.length > 0;
            const filterSet = new Set(targetIds);

            let hitCount = 0;

            for (const target of buildings) {
              if (source === target) continue;
              if (hasFilter && !filterSet.has(String(target.templateId))) continue;

              const tc = this.getBuildingCenter(target);
              if (this.isWithinRange(sc.x, sc.y, tc.x, tc.y, range, shape)) {
                hitCount++;
              }
            }

            sums[varId] = (sums[varId] || 0) + hitCount * value;
          }
        }
      }

      for (const varId of targetVarIds) {
        $gameVariables.setValue(Number(varId), Number(sums[varId] || 0));
      }

      return {
        ok: true,
        mapIds: targetMapIds,
        values: sums
      };
    },

    _newBuildingId(mapId) {
      const store = this.ensureMapData(mapId);
      const seq = (store._seq || 0) + 1;
      store._seq = seq;
      return `${mapId}_${Date.now()}_${seq}`;
    },

    requestOpenBuildMode(templateId) {
      const ceId = this._buildStartCommonEventId;
      if (ceId > 0) {
        this._pendingModeStart = { type: "build", templateId: String(templateId) };
        $gameTemp.reserveCommonEvent(ceId);
      } else {
        SceneManager.push(Scene_Build);
        SceneManager.prepareNextScene(String(templateId));
      }
    },

    requestOpenMoveMode(mapId) {
      const ceId = this._moveStartCommonEventId;
      if (ceId > 0) {
        this._pendingModeStart = { type: "move", mapId };
        $gameTemp.reserveCommonEvent(ceId);
      } else {
        SceneManager.push(Scene_MovePick);
        SceneManager.prepareNextScene(mapId);
      }
    },

    commitPendingModeStart() {
      const p = this._pendingModeStart;
      if (!p) return;
      this._pendingModeStart = null;
      if (p.type === "build") {
        SceneManager.push(Scene_Build);
        SceneManager.prepareNextScene(p.templateId);
      } else if (p.type === "move") {
        SceneManager.push(Scene_MovePick);
        SceneManager.prepareNextScene(p.mapId);
      }
    },

    _rectsOverlap(ax, ay, aw, ah, bx, by, bw, bh) {
      return ax < bx + bw &&
        ax + aw > bx &&
        ay < by + bh &&
        ay + ah > by;
    },

    _parseProhibitNoteTags(note) {
      const text = String(note || "");
      const list = [];
      const re = /<prohibit\s*:\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*>/gi;
      let m;
      while ((m = re.exec(text)) !== null) {
        const switchId = Number(m[1] || 0);
        const w = Number(m[2] || 0);
        const h = Number(m[3] || 0);
        if (switchId > 0 && w > 0 && h > 0) {
          list.push({ switchId, w, h });
        }
      }
      return list;
    },

    isEventProhibitActive(switchId) {
      const swId = Number(switchId || 0);
      if (swId <= 0) return false;
      // 指定スイッチがONになるまでは禁止。ONなら解除。
      return !$gameSwitches.value(swId);
    },

    isProhibitedByEventNotes(mapId, x, y, w, h, bypassBuildingId = null) {
      const targetMapId = Number(mapId || 0) || $gameMap.mapId();
      if (targetMapId !== $gameMap.mapId()) return false;
      if (!$gameMap || typeof $gameMap.events !== "function") return false;

      const bx = Number(x || 0);
      const by = Number(y || 0);
      const bw = Number(w || 0);
      const bh = Number(h || 0);
      if (bw <= 0 || bh <= 0) return false;

      const events = $gameMap.events();
      for (const ev of events) {
        if (!ev) continue;
        if (typeof ev.isErased === "function" && ev.isErased()) continue;

        const evData = (typeof ev.event === "function") ? ev.event() : null;
        if (!evData) continue;
        if (evData._dbPreview) continue;

        if (bypassBuildingId != null && String(bypassBuildingId) !== "") {
          if (String(evData._dynamicBuildingId || "") === String(bypassBuildingId)) continue;
        }

        const tags = this._parseProhibitNoteTags(evData.note);
        if (tags.length === 0) continue;

        const ex = Number.isFinite(Number(ev.x)) ? Number(ev.x) : Number(evData.x || 0);
        const ey = Number.isFinite(Number(ev.y)) ? Number(ev.y) : Number(evData.y || 0);

        for (const tag of tags) {
          if (!this.isEventProhibitActive(tag.switchId)) continue;
          if (this._rectsOverlap(bx, by, bw, bh, ex, ey, tag.w, tag.h)) {
            return true;
          }
        }
      }

      return false;
    },

    canPlaceAt(mapId, x, y, w, h) {
      const mapData = (mapId === $gameMap.mapId()) ? $gameMap : null;
      const width = mapData ? $gameMap.width() : null;
      const height = mapData ? $gameMap.height() : null;

      if (mapData) {
        if (x < 0 || y < 0 || x + w > width || y + h > height) return false;
      }

      const store = this.ensureMapData(mapId);

      for (const b of store.buildings) {
        const overlap =
          x < b.pasteX + b.w &&
          x + w > b.pasteX &&
          y < b.pasteY + b.h &&
          y + h > b.pasteY;
        if (overlap) return false;
      }

      if (this.isProhibitedByEventNotes(mapId, x, y, w, h)) return false;

      for (let dy = 0; dy < h; dy++) {
        for (let dx = 0; dx < w; dx++) {
          const tx = x + dx;
          const ty = y + dy;

          if (mapId !== $gameMap.mapId()) continue;

          const rid = $gameMap.regionId(tx, ty);
          if (this._forbiddenRegion > 0 && rid === this._forbiddenRegion) return false;
          if (this._allowedRegion > 0 && rid !== this._allowedRegion) return false;
        }
      }
      return true;
    },

    canPlaceAtWithBypass(mapId, x, y, w, h, bypassBuildingId) {
      const mapData = (mapId === $gameMap.mapId()) ? $gameMap : null;
      const width = mapData ? $gameMap.width() : null;
      const height = mapData ? $gameMap.height() : null;

      if (mapData) {
        if (x < 0 || y < 0 || x + w > width || y + h > height) return false;
      }

      const store = this.ensureMapData(mapId);

      for (const b of store.buildings) {
        if (bypassBuildingId && String(b.buildingId) === String(bypassBuildingId)) continue;
        const overlap =
          x < b.pasteX + b.w &&
          x + w > b.pasteX &&
          y < b.pasteY + b.h &&
          y + h > b.pasteY;
        if (overlap) return false;
      }

      if (this.isProhibitedByEventNotes(mapId, x, y, w, h, bypassBuildingId)) return false;

      for (let dy = 0; dy < h; dy++) {
        for (let dx = 0; dx < w; dx++) {
          const tx = x + dx;
          const ty = y + dy;
          if (mapId !== $gameMap.mapId()) continue;
          const rid = $gameMap.regionId(tx, ty);
          if (this._forbiddenRegion > 0 && rid === this._forbiddenRegion) return false;
          if (this._allowedRegion > 0 && rid !== this._allowedRegion) return false;
        }
      }

      return true;
    },

    async moveBuildingAt(fromX, fromY, toBaseX, toBaseY, targetMapId = 0) {
      const mapId = Number(targetMapId || 0) || $gameMap.mapId();
      if (mapId !== $gameMap.mapId()) return { ok: false, reason: "not_current_map" };

      const b = this.findBuildingAt(mapId, Number(fromX), Number(fromY));
      if (!b) return { ok: false, reason: "not_found" };

      const wasDetached = !!b._isDetached;

      const t = this.template(b.templateId);
      if (!t) return { ok: false, reason: "template_missing" };

      const newPasteX = Number(toBaseX) - t.anchorX;
      const newPasteY = Number(toBaseY) - t.anchorY;

      if (newPasteX === b.pasteX && newPasteY === b.pasteY) {
        return { ok: true, moved: false, buildingId: b.buildingId };
      }

      const can = this.canPlaceAtWithBypass(mapId, newPasteX, newPasteY, b.w, b.h, b.buildingId);
      if (!can) return { ok: false, reason: "forbidden_or_outside_or_overlap" };

      const tpl = await BuildTemplateManager.loadTemplate(t);

      if (!wasDetached) {
        for (const k in b.tilesBefore) {
          const [x, y, z] = k.split(",").map(Number);
          $gameMap.setEditableTile(x, y, z, b.tilesBefore[k]);
        }
      }

      if (!wasDetached) {
        for (const evId of b.dynEventIds) $gameMap.eraseDynamicEvent(evId);
      }

      b.pasteX = newPasteX;
      b.pasteY = newPasteY;
      b.w = t.rectW;
      b.h = t.rectH;
      b.tilesBefore = {};
      b.tilesAfter = {};
      b.dynEventIds = [];
      b.dynEventData = [];

      for (let dy = 0; dy < t.rectH; dy++) {
        for (let dx = 0; dx < t.rectW; dx++) {
          forEachBuildCopyLayer((z) => {
            const tx = newPasteX + dx;
            const ty = newPasteY + dy;
            const key = `${tx},${ty},${z}`;

            const beforeId = $gameMap.tileId(tx, ty, z);
            b.tilesBefore[key] = beforeId;

            const afterLayer = tpl.tiles[z];
            const afterId = (afterLayer && afterLayer[dy]) ? (afterLayer[dy][dx] || 0) : 0;
            b.tilesAfter[key] = afterId;

            $gameMap.setEditableTile(tx, ty, z, afterId);
          });
        }
      }

      for (const e of tpl.events) {
        const newEvent = JSON.parse(JSON.stringify(e));
        newEvent.x = newPasteX + (e.x - t.rectX);
        newEvent.y = newPasteY + (e.y - t.rectY);

        newEvent._dynamicMapId = mapId;
        newEvent._dynamicBuildingId = b.buildingId;

        const newId = $gameMap.spawnDynamicEvent(newEvent);
        b.dynEventIds.push(newId);
        b.dynEventData.push(newEvent);
      }

      b._isDetached = false;
      this._rebuildLegacyCache(mapId);

      $gameMap.requestRefresh();

      const scene = SceneManager._scene;
      if (scene && scene._spriteset && scene._spriteset._tilemap) {
        scene._spriteset._tilemap.refresh();
      }
      // ------------------------------------------------------------
      // ★共有マップ群にも「同じbuildingId」を同座標で同期（データ更新）
      //   ※非現在マップは見た目反映しない（入った時 setup で反映）
      // ------------------------------------------------------------
      {
        const targets = this._sharingTargets(mapId);
        const others = targets.filter(mid => mid !== $gameMap.mapId());

        // 共有先の tilesBefore を MapXXX.json から採取（新位置）
        const beforeByMap = {};
        await Promise.all(others.map(async (mid) => {
          try {
            beforeByMap[mid] = await this._snapshotTilesBeforeFromMapFile(mid, b.pasteX, b.pasteY, b.w, b.h);
          } catch (e) {
            console.error("[BUILD] move snapshot before failed mapId=", mid, e);
            beforeByMap[mid] = null;
          }
        }));

        for (const mid of targets) {
          if (mid === $gameMap.mapId()) continue;

          const store = this.ensureMapData(mid);
          const bb = store.buildings.find(x => String(x.buildingId) === String(b.buildingId));
          if (!bb) {
            // 念のため無ければ新規生成（整合性回復）
            store.buildings.push({
              buildingId: String(b.buildingId),
              templateId: String(b.templateId),
              pasteX: b.pasteX,
              pasteY: b.pasteY,
              w: b.w,
              h: b.h,
              tilesBefore: {},
              tilesAfter: {},
              dynEventIds: [],
              dynEventData: [],
            });
          }

          const targetB = store.buildings.find(x => String(x.buildingId) === String(b.buildingId));

          targetB.templateId = String(b.templateId);
          targetB.pasteX = b.pasteX;
          targetB.pasteY = b.pasteY;
          targetB.w = b.w;
          targetB.h = b.h;

          // tilesAfter は現在マップで作ったものをそのままコピー（座標含む）
          targetB.tilesAfter = JSON.parse(JSON.stringify(b.tilesAfter));

          // tilesBefore は共有先マップの元データから
          const snap = beforeByMap[mid];
          if (snap) targetB.tilesBefore = snap;
          else {
            targetB.tilesBefore = {};
            for (const k in targetB.tilesAfter) targetB.tilesBefore[k] = 0;
          }

          // dynEventData も現在マップで作った座標のものをコピーし、_dynamicMapId を差し替え
          targetB.dynEventData = (b.dynEventData || []).map(ev => {
            const c = JSON.parse(JSON.stringify(ev));
            c._dynamicMapId = mid;
            c._dynamicBuildingId = String(b.buildingId);
            return c;
          });

          targetB.dynEventIds = []; // 非現在マップなので実体IDは持たない
          targetB._isDetached = false;

          this._rebuildLegacyCache(mid);
        }
      }

      this.recalculateBuildingEffects(mapId);
      this.recalculateBuildingAreaEffects(mapId);
      return { ok: true, moved: true, buildingId: b.buildingId };
    },

    _detachBuildingVisuals(buildingId, targetMapId = 0) {
      const mapId = Number(targetMapId || 0) || $gameMap.mapId();
      if (mapId !== $gameMap.mapId()) return { ok: false, reason: "not_current_map" };

      const store = this.ensureMapData(mapId);
      const b = store.buildings.find(bb => String(bb.buildingId) === String(buildingId));
      if (!b) return { ok: false, reason: "not_found" };
      if (b._isDetached) return { ok: true, already: true, buildingId: b.buildingId };

      for (const k in b.tilesBefore) {
        const [x, y, z] = k.split(",").map(Number);
        $gameMap.setEditableTile(x, y, z, b.tilesBefore[k]);
      }

      for (const evId of (b.dynEventIds || [])) $gameMap.eraseDynamicEvent(evId);

      b.dynEventIds = [];
      b._isDetached = true;

      this._rebuildLegacyCache(mapId);
      $gameMap.requestRefresh();

      const scene = SceneManager._scene;
      if (scene && scene._spriteset && scene._spriteset._tilemap) {
        scene._spriteset._tilemap.refresh();
      }

      return { ok: true, buildingId: b.buildingId };
    },

    _restoreDetachedBuildingVisuals(buildingId, targetMapId = 0) {
      const mapId = Number(targetMapId || 0) || $gameMap.mapId();
      if (mapId !== $gameMap.mapId()) return { ok: false, reason: "not_current_map" };

      const store = this.ensureMapData(mapId);
      const b = store.buildings.find(bb => String(bb.buildingId) === String(buildingId));
      if (!b) return { ok: false, reason: "not_found" };
      if (!b._isDetached) return { ok: true, already: true, buildingId: b.buildingId };

      for (const k in b.tilesAfter) {
        const [x, y, z] = k.split(",").map(Number);
        $gameMap.setEditableTile(x, y, z, b.tilesAfter[k]);
      }

      b.dynEventIds = [];
      if (b.dynEventData && Array.isArray(b.dynEventData)) {
        for (const evData of b.dynEventData) {
          const cloned = JSON.parse(JSON.stringify(evData));
          cloned._dynamicMapId = mapId;
          cloned._dynamicBuildingId = b.buildingId;
          const newId = $gameMap.spawnDynamicEvent(cloned);
          b.dynEventIds.push(newId);
        }
      }

      b._isDetached = false;

      this._rebuildLegacyCache(mapId);
      $gameMap.requestRefresh();

      const scene = SceneManager._scene;
      if (scene && scene._spriteset && scene._spriteset._tilemap) {
        scene._spriteset._tilemap.refresh();
      }

      return { ok: true, buildingId: b.buildingId };
    },

    findBuildingAt(mapId, x, y) {
      const store = this.ensureMapData(mapId);
      for (let i = store.buildings.length - 1; i >= 0; i--) {
        const b = store.buildings[i];
        if (x >= b.pasteX && x < b.pasteX + b.w && y >= b.pasteY && y < b.pasteY + b.h) {
          return b;
        }
      }
      return null;
    },

    async placeBuilding(templateId, baseX, baseY, targetMapId = 0) {
      const baseMapId = Number(targetMapId || 0) || $gameMap.mapId();
      const t = this.template(templateId);
      if (!t) throw new Error(`Unknown templateId: ${templateId}`);

      // いまの仕様：実際に“今いるマップ”へ置く（演出上）
      if (baseMapId !== $gameMap.mapId()) {
        throw new Error("現状は targetMapId=現在マップ のみ対応（拡張可能）");
      }

      const pasteX = baseX - t.anchorX;
      const pasteY = baseY - t.anchorY;

      // 置けるかチェックは “今いるマップ” 기준でOK（共有先は同座標同リージョン想定）
      if (!this.canPlaceAt(baseMapId, pasteX, pasteY, t.rectW, t.rectH)) {
        return { ok: false, reason: "forbidden_or_outside_or_overlap" };
      }

      const tpl = await BuildTemplateManager.loadTemplate(t);

      // ★建物IDは共有マップすべてで同一にする（削除/移動同期のため）
      const buildingId = this._newBuildingId(baseMapId);

      // ★共有対象マップ一覧（必ず baseMapId を含む）
      const targets = this._sharingTargets(baseMapId);

      // 共有先（非現在マップ）用に before を MapXXX.json から採取しておく
      const others = targets.filter(mid => mid !== $gameMap.mapId());

      // 非現在マップの tilesBefore を並列採取
      const beforeByMap = {};
      await Promise.all(others.map(async (mid) => {
        try {
          beforeByMap[mid] = await this._snapshotTilesBeforeFromMapFile(mid, pasteX, pasteY, t.rectW, t.rectH);
        } catch (e) {
          console.error("[BUILD] snapshot before failed mapId=", mid, e);
          beforeByMap[mid] = null;
        }
      }));

      // まず “データとして” 共有マップすべてへ building を作る
      for (const mid of targets) {
        const store = this.ensureMapData(mid);

        const building = {
          buildingId,
          templateId: String(templateId),
          pasteX,
          pasteY,
          w: t.rectW,
          h: t.rectH,
          tilesBefore: {},
          tilesAfter: {},
          dynEventIds: [],
          dynEventData: [],
        };

        // tilesAfter はテンプレから確定（全マップ共通）
        for (let dy = 0; dy < t.rectH; dy++) {
          for (let dx = 0; dx < t.rectW; dx++) {
            forEachBuildCopyLayer((z) => {
              const tx = pasteX + dx;
              const ty = pasteY + dy;
              const key = `${tx},${ty},${z}`;
              const afterLayer = tpl.tiles[z];
              const afterId = (afterLayer && afterLayer[dy]) ? (afterLayer[dy][dx] || 0) : 0;
              building.tilesAfter[key] = afterId;
            });
          }
        }

        // dynEventData も全マップ共通（座標は貼り付け後座標にする）
        for (const e of tpl.events) {
          const newEvent = JSON.parse(JSON.stringify(e));
          newEvent.x = pasteX + (e.x - t.rectX);
          newEvent.y = pasteY + (e.y - t.rectY);
          newEvent._dynamicMapId = mid;
          newEvent._dynamicBuildingId = buildingId;
          building.dynEventData.push(newEvent);
        }

        // tilesBefore は「今いるマップ」は現状タイルから、他は MapXXX.json から
        if (mid === $gameMap.mapId()) {
          for (const k in building.tilesAfter) {
            const [x, y, z] = k.split(",").map(Number);
            building.tilesBefore[k] = $gameMap.tileId(x, y, z);
          }
        } else {
          const snap = beforeByMap[mid];
          if (snap) building.tilesBefore = snap;
          else {
            // 採取失敗時は最低限の保険（0にする）
            for (const k in building.tilesAfter) building.tilesBefore[k] = 0;
          }
        }

        store.buildings.push(building);
        // 互換キャッシュ再構築（あなたの構造に合わせる）
        this._rebuildLegacyCache(mid);
      }

      // ★今いるマップには “即時反映” も行う（タイル＆イベント生成）
      {
        const store = this.ensureMapData($gameMap.mapId());
        const b = store.buildings.find(bb => String(bb.buildingId) === String(buildingId));
        if (!b) return { ok: false, reason: "internal_missing" };

        // タイル反映
        for (const k in b.tilesAfter) {
          const [x, y, z] = k.split(",").map(Number);
          $gameMap.setEditableTile(x, y, z, b.tilesAfter[k]);
        }

        // イベント生成
        b.dynEventIds = [];
        for (const evData of b.dynEventData) {
          const cloned = JSON.parse(JSON.stringify(evData));
          cloned._dynamicMapId = $gameMap.mapId();
          cloned._dynamicBuildingId = buildingId;
          const newId = $gameMap.spawnDynamicEvent(cloned);
          b.dynEventIds.push(newId);
        }

        $gameMap.requestRefresh();

        const scene = SceneManager._scene;
        if (scene && scene._spriteset && scene._spriteset._tilemap) {
          scene._spriteset._tilemap.refresh();
        }
        if (scene && scene._spriteset && typeof scene._spriteset.dbSyncEventCharacterSprites === "function") {
          scene._spriteset.dbSyncEventCharacterSprites();
        }
      }

      this.recalculateBuildingEffects(baseMapId);
      this.recalculateBuildingAreaEffects(baseMapId);
      return { ok: true, buildingId, sharedMaps: targets };
    },


    _removeBuildingByIdInternal(buildingId, targetMapId = 0) {
      const mapId = Number(targetMapId || 0) || $gameMap.mapId();
      const store = this.ensureMapData(mapId);

      const idx = store.buildings.findIndex(b => b.buildingId === String(buildingId));
      if (idx < 0) return { ok: false, reason: "not_found" };

      const b = store.buildings[idx];
      if (mapId !== $gameMap.mapId()) return { ok: false, reason: "not_current_map" };

      for (const k in b.tilesBefore) {
        const [x, y, z] = k.split(",").map(Number);
        $gameMap.setEditableTile(x, y, z, b.tilesBefore[k]);
      }

      for (const evId of b.dynEventIds) $gameMap.eraseDynamicEvent(evId);

      store.buildings.splice(idx, 1);
      this._rebuildLegacyCache(mapId);


      // 表示を即時反映
      $gameMap.requestRefresh();

      const scene = SceneManager._scene;
      if (scene && scene._spriteset) {
        const ss = scene._spriteset;

        // タイルの描画更新
        if (ss._tilemap && typeof ss._tilemap.refresh === "function") {
          ss._tilemap.refresh();
        }

        // イベントスプライトの同期（増減を反映）
        if (typeof ss.dbSyncEventCharacterSprites === "function") {
          ss.dbSyncEventCharacterSprites();
        }
      }



      return { ok: true };
    },

    removeBuildingAt(x, y, targetMapId = 0) {
      const baseMapId = Number(targetMapId || 0) || $gameMap.mapId();

      // まず基準マップで building を特定
      const b = this.findBuildingAt(baseMapId, Number(x), Number(y));
      if (!b) return { ok: false, reason: "not_found" };

      const buildingId = String(b.buildingId);

      // ★共有対象すべてから消す
      const targets = this._sharingTargets(baseMapId);

      let okAny = false;

      for (const mid of targets) {
        const store = this.ensureMapData(mid);
        const idx = store.buildings.findIndex(bb => String(bb.buildingId) === buildingId);
        if (idx < 0) continue;

        // “今いるマップ” だけは実際にタイル復元＆イベント消しを行う
        if (mid === $gameMap.mapId()) {
          const r = this._removeBuildingByIdInternal(buildingId, mid);
          if (r && r.ok) okAny = true;
        } else {
          // 非現在マップ：データだけ消す（表示は、そのマップに入った時点で反映されない）
          store.buildings.splice(idx, 1);
          this._rebuildLegacyCache(mid);
          okAny = true;
        }
      }

      if (okAny) {
        this.recalculateBuildingEffects(baseMapId);
        this.recalculateBuildingAreaEffects(baseMapId);
        return { ok: true, buildingId, sharedMaps: targets };
      } else {
        return { ok: false, reason: "not_found_in_targets" };
      }
    },


    _rebuildLegacyCache(mapId) {
      const store = this.ensureMapData(mapId);
      store.tiles = {};
      store.dynEvents = [];
      for (const b of store.buildings) {
        for (const k in b.tilesAfter) store.tiles[k] = b.tilesAfter[k];
        for (const ev of b.dynEventData) store.dynEvents.push(ev);
      }
    },
  };

  window.BuildManager = BuildManager;

  // -------------------------------------------------------------------
  // BuildTemplateManager（テンプレマップをロードして切り出す）
  // -------------------------------------------------------------------
  const BuildTemplateManager = {
    _cache: new Map(),

    async loadTemplate(t) {
      const key = `${t.id}`;
      if (this._cache.has(key)) return this._cache.get(key);

      const mapData = await this._loadMapDataAsync(t.sourceMapId);

      const width = mapData.width;
      const height = mapData.height;

      const getTile = (x, y, z) => {
        const idx = (z * height + y) * width + x;
        return mapData.data[idx] || 0;
      };

      const LAYERS = 6;
      const tiles = Array.from({ length: LAYERS }, () => []);

      forEachBuildCopyLayer((z) => {
        for (let dy = 0; dy < t.rectH; dy++) {
          const row = [];
          for (let dx = 0; dx < t.rectW; dx++) {
            row.push(getTile(t.rectX + dx, t.rectY + dy, z));
          }
          tiles[z].push(row);
        }
      });

      const events = [];
      const evList = mapData.events || [];
      for (const ev of evList) {
        if (!ev) continue;
        const inRect =
          ev.x >= t.rectX &&
          ev.y >= t.rectY &&
          ev.x < t.rectX + t.rectW &&
          ev.y < t.rectY + t.rectH;
        if (inRect) events.push(ev);
      }

      const result = { tiles, events };
      this._cache.set(key, result);
      return result;
    },

    _loadMapDataAsync(mapId) {
      return new Promise((resolve, reject) => {
        const filename = "Map%1.json".format(mapId.padZero(3));
        const xhr = new XMLHttpRequest();
        xhr.open("GET", "data/" + filename);
        xhr.overrideMimeType("application/json");
        xhr.onload = () => {
          if (xhr.status < 400) resolve(JSON.parse(xhr.responseText));
          else reject(new Error(`Failed to load ${filename}`));
        };
        xhr.onerror = () => reject(new Error(`XHR error: ${filename}`));
        xhr.send();
      });
    },
  };

  // -------------------------------------------------------------------
  // Game_Map：編集可能タイル＋動的イベント
  // -------------------------------------------------------------------
  const _Game_Map_setup = Game_Map.prototype.setup;
  Game_Map.prototype.setup = function(mapId) {
    _Game_Map_setup.call(this, mapId);

    this._dynamicEvents = [];
    this._dynamicEventTable = {};
    this._dynamicEventNextId = ($dataMap.events ? $dataMap.events.length : 1);

    this._editableData = JSON.parse(JSON.stringify($dataMap.data));
    this._buildPreviewTiles = {};

    const store = BuildManager._dataByMap?.[mapId];
    if (store) {
      if (store.buildings && Array.isArray(store.buildings)) {
        for (const b of store.buildings) {
          if (b.tilesAfter) {
            for (const k in b.tilesAfter) {
              const [x, y, z] = k.split(",").map(Number);
              this.setEditableTile(x, y, z, b.tilesAfter[k]);
            }
          }
          if (b.dynEventData && Array.isArray(b.dynEventData)) {
            for (const evData of b.dynEventData) this.spawnDynamicEvent(evData);
          }
        }
      } else {
        if (store.tiles) {
          for (const k in store.tiles) {
            const [x, y, z] = k.split(",").map(Number);
            this.setEditableTile(x, y, z, store.tiles[k]);
          }
        }
        if (store.dynEvents) {
          for (const evData of store.dynEvents) this.spawnDynamicEvent(evData);
        }
      }
    }
  };

  Game_Map.prototype.data = function() {
    return this._editableData || $dataMap.data;
  };

  Game_Map.prototype.setEditableTile = function(x, y, z, tileId) {
    if (Number(z) === 0) return; // ★追加：最下層(z=0)は絶対に上書きしない
    const width = this.width();
    const height = this.height();
    if (x < 0 || y < 0 || x >= width || y >= height) return;

    const idx = (z * height + y) * width + x;
    if (!this._editableData) this._editableData = JSON.parse(JSON.stringify($dataMap.data));
    this._editableData[idx] = tileId;
  };

  Game_Map.prototype.clearBuildPreviewTiles = function() {
    this._buildPreviewTiles = {};
  };

  Game_Map.prototype.setBuildPreviewTiles = function(tiles) {
    this._buildPreviewTiles = tiles || {};
  };

  const _Game_Map_tileId = Game_Map.prototype.tileId;
  Game_Map.prototype.tileId = function(x, y, z) {
    if (this._buildPreviewTiles) {
      const key = `${x},${y},${z}`;
      if (Object.prototype.hasOwnProperty.call(this._buildPreviewTiles, key)) {
        return this._buildPreviewTiles[key] || 0;
      }
    }
    if (this._editableData) {
      const width = this.width();
      const height = this.height();
      return this._editableData[(z * height + y) * width + x] || 0;
    }
    return _Game_Map_tileId.call(this, x, y, z);
  };

  function isBuildRelatedModeActive() {
    const scene = SceneManager._scene;
    if (!scene) return false;
    return (scene instanceof Scene_Build)
      || (scene instanceof Scene_MovePick)
      || (scene instanceof Scene_MoveBuilding);
  }

  function isBuildRegionBlockedAt(mapId, x, y) {
    if (!isBuildRelatedModeActive()) return false;
    return !!(window.BuildManager && BuildManager.isRegionPassageBlocked(x, y, mapId));
  }

  const _Game_Player_canPass = Game_Player.prototype.canPass;
  Game_Player.prototype.canPass = function(x, y, d) {
    const x2 = $gameMap.roundXWithDirection(x, d);
    const y2 = $gameMap.roundYWithDirection(y, d);
    if (isBuildRegionBlockedAt($gameMap.mapId(), x2, y2)) {
      return false;
    }
    return _Game_Player_canPass.call(this, x, y, d);
  };

  Game_Map.prototype.spawnDynamicEvent = function(eventData) {
    if (!this._dynamicEventTable) this._dynamicEventTable = {};
    if (!this._dynamicEvents) this._dynamicEvents = [];

    let newId = Number(this._dynamicEventNextId || (($dataMap.events ? $dataMap.events.length : 1)));
    while (this._events && this._events[newId]) newId++;
    this._dynamicEventNextId = newId + 1;

    const cloned = JSON.parse(JSON.stringify(eventData));
    cloned.id = newId;
    if (cloned._dynamicMapId == null) cloned._dynamicMapId = this.mapId();

    this._dynamicEventTable[newId] = cloned;

    const ev = new Game_Event(this.mapId(), newId);
    this._events[newId] = ev;
    this._dynamicEvents.push(ev);

    // ★追加：後から増えたイベントの表示同期要求
    if ($gameTemp) $gameTemp._dbNeedCharacterSpriteSync = true;

    return newId;
  };

  Game_Map.prototype.eraseDynamicEvent = function(eventId) {
    const id = Number(eventId);
    if (!id) return;

    if (this._events && this._events[id]) this.eraseEvent(id);
    if (this._events) delete this._events[id];

    if (this._dynamicEventTable) delete this._dynamicEventTable[id];
    if (this._dynamicEvents) this._dynamicEvents = this._dynamicEvents.filter(e => e && e._eventId !== id);

    this.requestRefresh();

    // ★追加：後から減ったイベントの表示同期要求
    if ($gameTemp) $gameTemp._dbNeedCharacterSpriteSync = true;
  };

  const _Game_Event_event = Game_Event.prototype.event;
  Game_Event.prototype.event = function() {
    const map = $gameMap;

    if (map && map._dynamicEventTable) {
      const d = map._dynamicEventTable[this._eventId];
      if (d && d._dynamicMapId === map.mapId()) return d;
    }

    const ev = _Game_Event_event.call(this);
    if (ev) return ev;

    return { id: this._eventId, name: "", note: "", x: this.x, y: this.y, pages: [] };
  };

  // -------------------------------------------------------------------
  // ★Spriteset_Map：後から増えたイベントの Sprite_Character を追加（表示同期）
  //   ＋消えたイベントの Sprite_Character を削除（リーク対策）
  //   ＋ゴーストより上にキャラを積む（ゴーストとイベントの両立）
  // -------------------------------------------------------------------
  const _Game_Temp_initialize = Game_Temp.prototype.initialize;
  Game_Temp.prototype.initialize = function() {
    _Game_Temp_initialize.call(this);
    this._dbNeedCharacterSpriteSync = false;
  };

  // ★追加：ゴーストTilemapの上にキャラを必ず積む
  Spriteset_Map.prototype.dbReorderCharactersAboveGhost = function(ghostTilemap) {
    if (!this._tilemap || !ghostTilemap || !this._characterSprites) return;
    if (ghostTilemap.parent !== this._tilemap) return;

    // いったん外して最後に付け直す（= ghost より前面）
    for (const spr of this._characterSprites) {
      if (!spr || spr.parent !== this._tilemap) continue;
      this._tilemap.removeChild(spr);
    }
    for (const spr of this._characterSprites) {
      if (!spr) continue;
      this._tilemap.addChild(spr);
    }
  };
// ★プレビューイベント専用の最前面レイヤーを作る
const _Spriteset_Map_createUpperLayer = Spriteset_Map.prototype.createUpperLayer;
Spriteset_Map.prototype.createUpperLayer = function() {
  _Spriteset_Map_createUpperLayer.call(this);

  if (!this._dbPreviewEventLayer) {
    this._dbPreviewEventLayer = new Sprite();
    this._dbPreviewEventLayer.z = 9999;

    // Spritesetの一番上に積む（＝タイルより確実に前）
    this.addChild(this._dbPreviewEventLayer);
  }
};

 Spriteset_Map.prototype.dbSyncEventCharacterSprites = function() {
  if (!this._characterSprites) return;

  const isGameEvent = (obj) => {
    return obj && obj.constructor && obj.constructor.name === "Game_Event" && typeof obj.eventId === "function";
  };

  // 現在マップに「生存している Game_Event」を eventId -> Game_Event で集める
  const aliveById = new Map();
  const list = $gameMap.events ? $gameMap.events() : [];
  for (const ev of list) {
    if (!isGameEvent(ev)) continue;
    const erased = (typeof ev.isErased === "function") ? ev.isErased() : false;
    if (erased) continue;
    aliveById.set(ev.eventId(), ev);
  }

  // 1) 既存スプライト：消えたものは破棄、残ってるものは「親を正しい方へ矯正」
  this._characterSprites = this._characterSprites.filter(spr => {
    const ch = spr && spr._character;
    if (!isGameEvent(ch)) return true;

    const id = ch.eventId();
    const aliveEv = aliveById.get(id);
    if (!aliveEv) {
      // 消えたイベント → スプライト破棄
      if (spr.parent) spr.parent.removeChild(spr);
      try { spr.destroy?.({ children: true }); } catch (e) {}
      return false;
    }

    // 生存してるなら「プレビューかどうか」を判定し、親を必ず正しい方へ
    const evData = aliveEv.event && aliveEv.event();
    const isPreview = !!(evData && evData._dbPreview);

    if (isPreview && this._dbPreviewEventLayer) {
      if (spr.parent) spr.parent.removeChild(spr);
      this._dbPreviewEventLayer.addChild(spr);
      spr.z = 9999;
    } else {
      this._tilemap.addChild(spr);
    }


    return true;
  });

  // 2) すでに存在する eventId
  const existing = new Set();
  for (const spr of this._characterSprites) {
    const ch = spr && spr._character;
    if (isGameEvent(ch)) existing.add(ch.eventId());
  }

  // 3) 足りないぶんを追加（ここでも親を正しく）
  for (const [id, ev] of aliveById.entries()) {
    if (existing.has(id)) continue;

    const spr = new Sprite_Character(ev);
    this._characterSprites.push(spr);

    const evData = ev.event && ev.event();
    const isPreview = !!(evData && evData._dbPreview);

    if (isPreview && this._dbPreviewEventLayer) {
      this._dbPreviewEventLayer.addChild(spr);
      spr.z = 9999;
    } else {
      this._tilemap.addChild(spr);
    }
  }

  // 4) ゴーストより上にキャラを積む（tilemap側のキャラだけ対象）
  if (this._dbGhostTilemap) {
    this.dbReorderCharactersAboveGhost(this._dbGhostTilemap);
  }
};

  Spriteset_Map.prototype.dbEnsurePreviewSpritesOnTop = function() {
    if (!this._dbPreviewEventLayer || !this._characterSprites) return;

    for (const spr of this._characterSprites) {
      const ch = spr && spr._character;
      if (!ch || ch.constructor?.name !== "Game_Event") continue;

      const evData = ch.event && ch.event();
      const isPreview = !!(evData && evData._dbPreview);
      if (!isPreview) continue;

      // ★親が違ってたら必ず最前面レイヤーへ戻す
      if (spr.parent !== this._dbPreviewEventLayer) {
        if (spr.parent) spr.parent.removeChild(spr);
        this._dbPreviewEventLayer.addChild(spr);
        spr.z = 9999;
      }
    }
  };


  const _Spriteset_Map_update = Spriteset_Map.prototype.update;
  Spriteset_Map.prototype.update = function() {
    _Spriteset_Map_update.call(this);

    if ($gameTemp && $gameTemp._dbNeedCharacterSpriteSync) {
      $gameTemp._dbNeedCharacterSpriteSync = false;
      this.dbSyncEventCharacterSprites();
    }

    // ★追加：歩行中に親が戻されても最前面を維持
    this.dbEnsurePreviewSpritesOnTop();
  };


  // -------------------------------------------------------------------
  // セーブ連携
  // -------------------------------------------------------------------
  const _DataManager_makeSaveContents = DataManager.makeSaveContents;
  DataManager.makeSaveContents = function() {
    const contents = _DataManager_makeSaveContents.call(this);
    contents._buildSystem = {
      sharedMapIds: BuildManager._sharedMapIds,
      allowedRegion: BuildManager._allowedRegion,
      forbiddenRegion: BuildManager._forbiddenRegion,
      dataByMap: BuildManager._dataByMap,
      cancelHandlers: {
        buildSw: BuildManager._buildCancelSwitchId,
        buildCe: BuildManager._buildCancelCommonEventId,
        moveSw: BuildManager._moveCancelSwitchId,
        moveCe: BuildManager._moveCancelCommonEventId,
        buildModeCompleteCe: BuildManager._buildModeCompleteCommonEventId,
        placeCommandCompleteCe: BuildManager._placeCommandCompleteCommonEventId,
      }
    };
    return contents;
  };

  const _DataManager_extractSaveContents = DataManager.extractSaveContents;
  DataManager.extractSaveContents = function(contents) {
    _DataManager_extractSaveContents.call(this, contents);
    const b = contents._buildSystem;
    if (b) {
      BuildManager._sharedMapIds = b.sharedMapIds ?? BuildManager._sharedMapIds ?? [];
      BuildManager._allowedRegion = b.allowedRegion ?? BuildManager._allowedRegion;
      BuildManager._forbiddenRegion = b.forbiddenRegion ?? BuildManager._forbiddenRegion;
      BuildManager._dataByMap = b.dataByMap ?? {};
      if (b.cancelHandlers) {
        BuildManager._buildCancelSwitchId = b.cancelHandlers.buildSw ?? BuildManager._buildCancelSwitchId;
        BuildManager._buildCancelCommonEventId = b.cancelHandlers.buildCe ?? BuildManager._buildCancelCommonEventId;
        BuildManager._moveCancelSwitchId = b.cancelHandlers.moveSw ?? BuildManager._moveCancelSwitchId;
        BuildManager._moveCancelCommonEventId = b.cancelHandlers.moveCe ?? BuildManager._moveCancelCommonEventId;
        BuildManager._buildModeCompleteCommonEventId =
          b.cancelHandlers.buildModeCompleteCe ?? BuildManager._buildModeCompleteCommonEventId;
        BuildManager._placeCommandCompleteCommonEventId =
          b.cancelHandlers.placeCommandCompleteCe ?? BuildManager._placeCommandCompleteCommonEventId;
      }
    }
  };

  // -------------------------------------------------------------------
  // ★入力ロック（多重キャンセル/多重決定防止）
  // -------------------------------------------------------------------
  function lockSceneInput(scene) {
    scene._dbInputLocked = true;
    Input.clear();
    TouchInput.clear();
  }

  function unlockSceneInput(scene) {
    scene._dbInputLocked = false;
  }

  function isTransitionBusy(scene) {
    if (scene && typeof scene.isBusy === "function" && scene.isBusy()) return true;
    if (SceneManager.isSceneChanging && SceneManager.isSceneChanging()) return true;
    return false;
  }


  // -------------------------------------------------------------------
  // Preview polygon helper (UM7対応)
  // -------------------------------------------------------------------
  function dbIsUltraMode7Active() {
    return !!(window.UltraMode7 && typeof UltraMode7.isActive === "function" && UltraMode7.isActive());
  }

  function dbMapPointToScreen(tileX, tileY) {
    const tw = $gameMap.tileWidth();
    const th = $gameMap.tileHeight();

    if (dbIsUltraMode7Active() && typeof UltraMode7.mapToScreen === "function") {
      let mx = tileX;
      let my = tileY;

      if (typeof $gameMap.adjustUltraMode7LoopedPosition === "function") {
        const p = $gameMap.adjustUltraMode7LoopedPosition(tileX, tileY);
        mx = p.x;
        my = p.y;
      }

      const s = UltraMode7.mapToScreen(mx * tw, my * th);
      return { x: s.x, y: s.y, z: s.z || 0 };
    }

    return {
      x: Math.floor($gameMap.adjustX(tileX) * tw),
      y: Math.floor($gameMap.adjustY(tileY) * th),
      z: 0
    };
  }

  function dbDrawPreviewTilePolygon(g, tx, ty, fillColor, fillAlpha, lineColor, lineAlpha) {
    const p1 = dbMapPointToScreen(tx,     ty);
    const p2 = dbMapPointToScreen(tx + 1, ty);
    const p3 = dbMapPointToScreen(tx + 1, ty + 1);
    const p4 = dbMapPointToScreen(tx,     ty + 1);

    g.lineStyle(1, lineColor, lineAlpha, 1);
    g.beginFill(fillColor, fillAlpha);
    g.drawPolygon([
      p1.x, p1.y,
      p2.x, p2.y,
      p3.x, p3.y,
      p4.x, p4.y
    ]);
    g.endFill();
  }

  // -------------------------------------------------------------------
  // ★イベントプレビュー（B案）用：テンプレイベント→見た目だけページを作る
  // -------------------------------------------------------------------
    function makePreviewEventDataFromTemplateEvent(srcEv) {
    const pages = srcEv.pages || [];
    let img = null;

    // 画像を持つページを探す（最初の1つ）
    for (const p of pages) {
      if (!p) continue;
      const im = p.image || null;
      if (!im) continue;

      const hasTile = (Number(im.tileId || 0) > 0);
      const hasChar = (String(im.characterName || "") !== "");
      if (hasTile || hasChar) {
        img = JSON.parse(JSON.stringify(im));
        break;
      }
    }
    if (!img) return null;

    // ★プレビューは常に最前面（★タイルより前に出す）
    const priorityType = 2; // 2:above characters

    const dummyPage = {
      conditions: {
        actorId: 1, actorValid: false,
        itemId: 1, itemValid: false,
        selfSwitchCh: "A", selfSwitchValid: false,
        switch1Id: 1, switch1Valid: false,
        switch2Id: 1, switch2Valid: false,
        variableId: 1, variableValid: false, variableValue: 0
      },
      image: img,
      moveRoute: { list: [{ code: 0 }], repeat: true, skippable: false, wait: false },
      moveType: 0,
      moveSpeed: 3,
      moveFrequency: 3,
      walkAnime: false,
      stepAnime: false,
      directionFix: true,
      through: true,
      priorityType: priorityType,
      trigger: 0,
      list: [{ code: 0, indent: 0, parameters: [] }]
    };

    const ev = {
      id: 0,
      name: (srcEv.name ? String(srcEv.name) : "PREVIEW"),
      note: "",
      x: srcEv.x,
      y: srcEv.y,
      pages: [dummyPage],
      meta: {},
    };
    return ev;
  }


  // -------------------------------------------------------------------
  // MovePick
  // -------------------------------------------------------------------
  class Scene_MovePick extends Scene_Map {
    initialize() {
      super.initialize();
      this._helpWindow = null;
      this._ready = false;
      this._modeSprite = null;
      this._mapId = 0;
    }

    prepare(mapId) {
      this._mapId = Number(mapId || 0) || $gameMap.mapId();
    }

    onMapLoaded() {
      Scene_Map.prototype.onMapLoaded.call(this);

      if (!this._modeSprite) {
        this._modeSprite = new Sprite(new Bitmap(700, 90));
        this._modeSprite.x = 10;
        this._modeSprite.y = 10;
        this.addChild(this._modeSprite);
      }

      const b = this._modeSprite.bitmap;
      b.clear();
      b.fontSize = 24;
      b.drawText("MOVE PICK", 0, 0, 700, 36, "left");
      b.fontSize = 18;
      b.drawText("建物の上で Enter/Z → 移動先選択へ", 0, 36, 700, 24, "left");
      b.drawText("Esc/X → 終了", 0, 60, 700, 24, "left");

      this._helpWindow = null;
      this._ready = true;
    }

    update() {
      if (!this._ready) {
        Scene_Map.prototype.update.call(this);
        return;
      }
      if (this._dbInputLocked || isTransitionBusy(this)) {
        Scene_Map.prototype.update.call(this);
        return;
      }

      if (Input.isTriggered("cancel")) {
        lockSceneInput(this);
        SoundManager.playCancel();
        BuildManager.runCancelHandlers("move");
        safePopToMap();
        return;
      }

      if (Input.isTriggered("ok")) {
        const x = $gamePlayer.x;
        const y = $gamePlayer.y;

        const b = BuildManager.findBuildingAt(this._mapId, x, y);
        if (!b) {
          SoundManager.playBuzzer();
          return;
        }

        const dr = BuildManager._detachBuildingVisuals(b.buildingId, this._mapId);
        if (!dr || !dr.ok) {
          SoundManager.playBuzzer();
          return;
        }

        lockSceneInput(this);
        SoundManager.playOk();

        SceneManager.push(Scene_MoveBuilding);
        SceneManager.prepareNextScene(b.buildingId, b.templateId, x, y);
        return;
      }

      Scene_Map.prototype.update.call(this);
    }
  }

  // -------------------------------------------------------------------
  // Build
  // -------------------------------------------------------------------
  class Scene_Build extends Scene_Map {
    initialize() {
      super.initialize();
      this._templateId = "";
      this._helpWindow = null;
      this._modeSprite = null;
      this._buildReady = false;

      this._previewSprite = null;
      this._previewBitmap = null;
      this._lastPreviewKey = "";


      this._ghostTilemap = null;
      this._ghostTemplateKey = "";
      this._ghostReady = false;
      this._lastGhostPosKey = "";
      this._ghostTpl = null;
      this._ghostLoading = false;

    // ★イベントプレビュー
    this._previewEventInfos = []; // [{ id, ox, oy }]
    this._lastPreviewEventKey = "";
    this._previewTplLoaded = false;

    }

    start() {
      // ※元コード維持（通常は Scene_Map.prototype.start が自然）
      Scene_Message.prototype.start.call(this);

      if (this._transfer) {
        this.fadeInForTransfer();
        this.onTransferEnd();
      } else if (this.needsFadeIn()) {
        this.startFadeIn(this.fadeSpeed(), false);
      }
      this.menuCalling = false;
    }

    prepare(templateId) {
      this._templateId = String(templateId || "");
    }

    create() {
      Scene_Map.prototype.create.call(this);
    }

    onMapLoaded() {
      Scene_Map.prototype.onMapLoaded.call(this);

      this._createBuildUi();
      this._createBuildPreview();

      this._createGhostTilemap();
      this._refreshGhostTemplate(true);

      this._updateBuildPreview(true);
      this._updateGhostPositionAndAlpha(true);
      this._updatePreviewEvents(true);

      this._buildReady = true;
    }

    _createBuildUi() {
      this._modeSprite = new Sprite(new Bitmap(520, 90));
      this._modeSprite.x = 10;
      this._modeSprite.y = 10;
      this.addChild(this._modeSprite);

      const b = this._modeSprite.bitmap;
      b.clear();
      b.fontSize = 24;
      b.drawText("BUILD MODE", 0, 0, 520, 36, "left");
      b.fontSize = 18;
      b.drawText(`Template: ${this._templateId}`, 0, 36, 520, 24, "left");
      b.drawText("Enter/Z: 設置   Esc/X: 終了", 0, 60, 520, 24, "left");

      this._helpWindow = null;
    }

    _createBuildPreview() {
      this._previewGraphics = new PIXI.Graphics();
      this._previewGraphics.z = 7;
      this.addChild(this._previewGraphics);

      this._previewSprite = this._previewGraphics;
      this._previewBitmap = null;
    }

    _createGhostTilemap() {
      if (this._ghostTilemap) return;

      const mainTilemap = this._spriteset && this._spriteset._tilemap;
      if (!mainTilemap || !mainTilemap.parent) return;

      const bitmaps =
        (Array.isArray(mainTilemap._bitmaps) && mainTilemap._bitmaps.length > 0) ? mainTilemap._bitmaps :
        (typeof mainTilemap.bitmaps === "function" && Array.isArray(mainTilemap.bitmaps())) ? mainTilemap.bitmaps() :
        (Array.isArray(mainTilemap.bitmaps)) ? mainTilemap.bitmaps :
        null;

      if (!Array.isArray(bitmaps) || bitmaps.length === 0 || bitmaps.some(b => !b)) return;

      const ghost = new Tilemap();
      ghost.setBitmaps(bitmaps);
      ghost.flags = $gameMap.tilesetFlags();
      ghost.alpha = 0.6;
      ghost.x = mainTilemap.x || 0;
      ghost.y = mainTilemap.y || 0;
      ghost.origin.x = mainTilemap.origin ? mainTilemap.origin.x : 0;
      ghost.origin.y = mainTilemap.origin ? mainTilemap.origin.y : 0;

      mainTilemap.parent.addChildAt(ghost, mainTilemap.parent.getChildIndex(mainTilemap) + 1);

      this._ghostTilemap = ghost;
      this._ghostReady = false;
      this._ghostTemplateKey = "";
      this._lastGhostPosKey = "";
      this._ghostTpl = null;
      this._ghostLoading = false;

      if (this._spriteset) {
        this._spriteset._dbGhostTilemap = ghost;
        this._spriteset.dbReorderCharactersAboveGhost?.(ghost);
      }
    }

    _refreshGhostTemplate(force = false) {
      const t = BuildManager.template(this._templateId);
      if (!t || !this._ghostTilemap) return;

      const baseX = $gamePlayer.x;
      const baseY = $gamePlayer.y;
      const pasteX = baseX - t.anchorX;
      const pasteY = baseY - t.anchorY;

      const key = [
        this._templateId, t.sourceMapId, t.rectX, t.rectY, t.rectW, t.rectH,
        pasteX, pasteY,
        $gameMap.mapId(), $gameMap.width(), $gameMap.height()
      ].join(",");
      if (!force && key === this._ghostTemplateKey) return;
      this._ghostTemplateKey = key;

      const applyGhostData = (tpl) => {
        if (!this._ghostTilemap) return;

        const mapW = $gameMap.width();
        const mapH = $gameMap.height();
        const LAYERS = 6;
        const data = new Array(mapW * mapH * LAYERS).fill(0);
        const index = (x, y, z) => (z * mapH + y) * mapW + x;

        for (let dy = 0; dy < t.rectH; dy++) {
          for (let dx = 0; dx < t.rectW; dx++) {
            const tx = pasteX + dx;
            const ty = pasteY + dy;
            if (!$gameMap.isValid(tx, ty)) continue;

            for (const z of BUILD_PREVIEW_LAYERS) {
              const tileId = (tpl.tiles[z] && tpl.tiles[z][dy]) ? (tpl.tiles[z][dy][dx] || 0) : 0;
              if (tileId > 0) data[index(tx, ty, z)] = tileId;
            }
          }
        }

        const mainTilemap = this._spriteset && this._spriteset._tilemap;
        const bitmaps = mainTilemap ? (
          (Array.isArray(mainTilemap._bitmaps) && mainTilemap._bitmaps.length > 0) ? mainTilemap._bitmaps :
          (typeof mainTilemap.bitmaps === "function" && Array.isArray(mainTilemap.bitmaps())) ? mainTilemap.bitmaps() :
          (Array.isArray(mainTilemap.bitmaps)) ? mainTilemap.bitmaps : null
        ) : null;

        if (Array.isArray(bitmaps) && bitmaps.length > 0 && !bitmaps.some(b => !b)) {
          this._ghostTilemap.setBitmaps(bitmaps);
        }

        this._ghostTilemap.flags = $gameMap.tilesetFlags();

        // ★UM7対策：内部キャッシュを強制クリア
        if (this._ghostTilemap._lowerLayer) this._ghostTilemap._lowerLayer.clear();
        if (this._ghostTilemap._upperLayer) this._ghostTilemap._upperLayer.clear();
        this._ghostTilemap._lastTiles = [];
        this._ghostTilemap.setData(mapW, mapH, data);
        this._ghostTilemap._needsRepaint = true;
        this._ghostTilemap.refresh();

        this._ghostReady = true;
        this._updateGhostPositionAndAlpha(true);

        if (this._spriteset) {
          this._spriteset.dbReorderCharactersAboveGhost?.(this._ghostTilemap);
        }
      };

      if (this._ghostTpl) {
        applyGhostData(this._ghostTpl);
        return;
      }

      if (this._ghostLoading) return;
      this._ghostLoading = true;

      BuildTemplateManager.loadTemplate(t).then(tpl => {
        this._ghostLoading = false;
        this._ghostTpl = tpl;
        applyGhostData(tpl);
      }).catch(e => {
        this._ghostLoading = false;
        console.error(e);
        this._ghostReady = false;
      });
    }

    _updateGhostPositionAndAlpha(force = false) {
      if (!this._ghostTilemap) return;

      const t = BuildManager.template(this._templateId);
      if (!t) return;

      const mainTilemap = this._spriteset && this._spriteset._tilemap;
      const ox = mainTilemap && mainTilemap.origin ? mainTilemap.origin.x : Math.floor($gameMap.displayX() * $gameMap.tileWidth());
      const oy = mainTilemap && mainTilemap.origin ? mainTilemap.origin.y : Math.floor($gameMap.displayY() * $gameMap.tileHeight());
      const px = mainTilemap ? (mainTilemap.x || 0) : 0;
      const py = mainTilemap ? (mainTilemap.y || 0) : 0;

      const key = [ox, oy, px, py, $gameMap.displayX(), $gameMap.displayY()].join(",");
      if (!force && key === this._lastGhostPosKey) {
        const baseX = $gamePlayer.x;
        const baseY = $gamePlayer.y;
        const pasteX = baseX - t.anchorX;
        const pasteY = baseY - t.anchorY;
        const ok = this._canPlace ? this._canPlace(pasteX, pasteY, t.rectW, t.rectH) : BuildManager.canPlaceAt($gameMap.mapId(), pasteX, pasteY, t.rectW, t.rectH);
        this._ghostTilemap.alpha = ok ? 0.6 : 0.25;
        return;
      }
      this._lastGhostPosKey = key;

      this._ghostTilemap.x = px;
      this._ghostTilemap.y = py;
      this._ghostTilemap.origin.x = ox;
      this._ghostTilemap.origin.y = oy;

      const baseX = $gamePlayer.x;
      const baseY = $gamePlayer.y;
      const pasteX = baseX - t.anchorX;
      const pasteY = baseY - t.anchorY;
      const ok = this._canPlace ? this._canPlace(pasteX, pasteY, t.rectW, t.rectH) : BuildManager.canPlaceAt($gameMap.mapId(), pasteX, pasteY, t.rectW, t.rectH);
      this._ghostTilemap.alpha = ok ? 0.6 : 0.25;
    }

    _updateBuildPreview(force = false) {
      if (!this._previewGraphics) return;

      const t = BuildManager.template(this._templateId);
      if (!t) return;

      const baseX = $gamePlayer.x;
      const baseY = $gamePlayer.y;
      const pasteX = baseX - t.anchorX;
      const pasteY = baseY - t.anchorY;

      const key = [
        baseX, baseY,
        $gameMap.displayX(), $gameMap.displayY(),
        pasteX, pasteY,
        t.rectW, t.rectH,
        BuildManager._allowedRegion, BuildManager._forbiddenRegion,
        dbIsUltraMode7Active() ? "um7" : "normal"
      ].join(",");

      if (!force && key === this._lastPreviewKey) return;
      this._lastPreviewKey = key;

      const ok = BuildManager.canPlaceAt($gameMap.mapId(), pasteX, pasteY, t.rectW, t.rectH);

      const g = this._previewGraphics;
      g.clear();

      const fillColor = ok ? 0x50ff78 : 0xff5050;
      const lineColor = ok ? 0x50ff78 : 0xff5050;
      const fillAlpha = 0.25;
      const lineAlpha = 0.75;

      for (let dy = 0; dy < t.rectH; dy++) {
        for (let dx = 0; dx < t.rectW; dx++) {
          const tx = pasteX + dx;
          const ty = pasteY + dy;
          if (!$gameMap.isValid(tx, ty)) continue;

          dbDrawPreviewTilePolygon(g, tx, ty, fillColor, fillAlpha, lineColor, lineAlpha);
        }
      }
    }

    // ------------------------------------------------------------
    // ★イベントプレビュー（B案）本体
    // ------------------------------------------------------------
    _clearPreviewEvents() {
      if (this._previewEventInfos && this._previewEventInfos.length > 0) {
        for (const info of this._previewEventInfos) {
          $gameMap.eraseDynamicEvent(info.id);
        }
      }
      this._previewEventInfos = [];
      this._previewTplLoaded = false;
      // ※ _lastPreviewEventKey は呼び出し元で必要に応じて消す
    }

_updatePreviewEvents(force = false) {
  const t = BuildManager.template(this._templateId);
  if (!t) return;

  const baseX = $gamePlayer.x;
  const baseY = $gamePlayer.y;
  const pasteX = baseX - t.anchorX;
  const pasteY = baseY - t.anchorY;

  const key = [this._templateId, pasteX, pasteY].join(",");
  if (!force && key === this._lastPreviewEventKey) return;
  this._lastPreviewEventKey = key;

  // -----------------------------------------
  // 1) すでに生成済みなら「位置だけ更新」＝点滅しない
  // -----------------------------------------
  if (this._previewEventInfos && this._previewEventInfos.length > 0) {
    for (const info of this._previewEventInfos) {
      const ev = $gameMap.event(info.id);
      if (!ev) continue;
      ev.locate(pasteX + info.ox, pasteY + info.oy);
      //ev.refresh?.();
    }
    return;
  }

      // -----------------------------------------
      // 2) 未生成なら「1回だけ生成」
      // -----------------------------------------
      BuildTemplateManager.loadTemplate(t).then(tpl => {
        // すでに別キーで生成済みになってたら二重生成を避ける
        if (this._previewEventInfos && this._previewEventInfos.length > 0) return;

        const infos = [];

        for (const srcEv of tpl.events) {
          const previewEv = makePreviewEventDataFromTemplateEvent(srcEv);
          if (!previewEv) continue;

          const ox = (srcEv.x - t.rectX);
          const oy = (srcEv.y - t.rectY);

          previewEv.x = pasteX + ox;
          previewEv.y = pasteY + oy;

          previewEv._dynamicMapId = $gameMap.mapId();
          previewEv._dynamicBuildingId = "__PREVIEW__";
          previewEv._dbPreview = true;

          const newId = $gameMap.spawnDynamicEvent(previewEv);
          infos.push({ id: newId, ox, oy });
        }

        this._previewEventInfos = infos;

        // 最初の生成だけは同期が必要（追加されたため）
        if ($gameTemp) $gameTemp._dbNeedCharacterSpriteSync = true;
      }).catch(e => console.error(e));
    }



    update() {
      if (!this._buildReady) {
        Scene_Map.prototype.update.call(this);
        return;
      }

      if (this._dbInputLocked || isTransitionBusy(this)) {
        Scene_Map.prototype.update.call(this);
        return;
      }

      if (Input.isTriggered("ok")) {
        lockSceneInput(this);
        const x = $gamePlayer.x;
        const y = $gamePlayer.y;

        BuildManager.placeBuilding(this._templateId, x, y, $gameMap.mapId())
          .then(r => {
            if (r && r.ok) {
              BuildManager.runBuildModeCompleteHandler();
              SoundManager.playOk();
              safePopToMap();
            } else {
              SoundManager.playBuzzer();
              unlockSceneInput(this);
            }
          })
          .catch(e => {
            console.error(e);
            SoundManager.playBuzzer();
            unlockSceneInput(this);
          });

        return;
      }

      if (Input.isTriggered("cancel")) {
        lockSceneInput(this);

        BuildManager.runCancelHandlers("build");
        SoundManager.playCancel();

        // ★プレビューイベント消す
        this._clearPreviewEvents();
        this._lastPreviewEventKey = "";
        safePopToMap();
        return;
      }

      Scene_Map.prototype.update.call(this);

      this._updateBuildPreview(false);

      if (!this._ghostTilemap) {
        this._createGhostTilemap();
      }
      if (this._ghostTilemap) this._refreshGhostTemplate(false);
      this._updateGhostPositionAndAlpha(false);

      // ★イベントプレビュー更新（プレイヤー移動で貼り付け基準が変わる）
      this._updatePreviewEvents(false);
    }

    terminate() {
      Scene_Map.prototype.terminate.call(this);

      // ★プレビューイベント消す
      this._clearPreviewEvents();
      this._lastPreviewEventKey = ""; // ★ここだけでOK

      if (this._previewGraphics) {
        this.removeChild(this._previewGraphics);
        this._previewGraphics.destroy();
        this._previewGraphics = null;
      }
      this._previewSprite = null;

      if (this._previewBitmap) {
        this._previewBitmap.destroy();
        this._previewBitmap = null;
      }

      this._ghostTpl = null;
      this._ghostLoading = false;

      if (this._ghostTilemap) {
        // ★Spriteset 側の参照も外す
        if (this._spriteset && this._spriteset._dbGhostTilemap === this._ghostTilemap) {
          this._spriteset._dbGhostTilemap = null;
        }

        const p = this._ghostTilemap.parent;
        if (p) p.removeChild(this._ghostTilemap);
        this._ghostTilemap.destroy({ children: true });
        this._ghostTilemap = null;
      }
      this._ghostReady = false;
      this._ghostTemplateKey = "";
      this._lastGhostPosKey = "";
    }
  }

  // -------------------------------------------------------------------
  // MoveBuilding（イベントプレビューも同じB案）
  // -------------------------------------------------------------------
  class Scene_MoveBuilding extends Scene_Map {
    initialize() {
      super.initialize();

      this._buildingId = "";
      this._templateId = "";
      this._pickX = 0;
      this._pickY = 0;

      this._helpWindow = null;
      this._modeSprite = null;
      this._buildReady = false;

      this._previewSprite = null;
      this._previewBitmap = null;
      this._lastPreviewKey = "";

      this._ghostTilemap = null;
      this._ghostTemplateKey = "";
      this._ghostReady = false;
      this._lastGhostPosKey = "";

      this._returnToPick = false;
      this._committed = false;

// ★イベントプレビュー
this._previewEventInfos = []; // [{ id, ox, oy }]
this._lastPreviewEventKey = "";
this._previewTplLoaded = false;


    }

    prepare(buildingId, templateId, pickX, pickY) {
      this._buildingId = String(buildingId || "");
      this._templateId = String(templateId || "");
      this._pickX = Number(pickX || 0);
      this._pickY = Number(pickY || 0);
    }

    start() {
      Scene_Map.prototype.start.call(this);
      if (this._transfer) {
        this.fadeInForTransfer();
        this.onTransferEnd();
      } else if (this.needsFadeIn()) {
        this.startFadeIn(this.fadeSpeed(), false);
      }
      this.menuCalling = false;
    }

    create() {
      Scene_Map.prototype.create.call(this);
    }

    onMapLoaded() {
      Scene_Map.prototype.onMapLoaded.call(this);

      this._createMoveUi();
      this._createBuildPreview();

      this._createGhostTilemap();
      this._refreshGhostTemplate(true);

      this._updateBuildPreview(true);
      this._updateGhostPositionAndAlpha(true);
      this._updatePreviewEvents(true);

      this._buildReady = true;
    }

    _createMoveUi() {
      this._modeSprite = new Sprite(new Bitmap(520, 90));
      this._modeSprite.x = 10;
      this._modeSprite.y = 10;
      this.addChild(this._modeSprite);

      const b = this._modeSprite.bitmap;
      b.clear();
      b.fontSize = 24;
      b.drawText("MOVE MODE", 0, 0, 520, 36, "left");
      b.fontSize = 18;
      b.drawText(`BuildingId: ${this._buildingId}`, 0, 36, 520, 24, "left");
      b.drawText("Enter/Z: 移動確定   Esc/X: キャンセル(元に戻す)", 0, 60, 520, 24, "left");

      this._helpWindow = null;
    }

    _createBuildPreview() {
      this._previewGraphics = new PIXI.Graphics();
      this._previewGraphics.z = 7;
      this.addChild(this._previewGraphics);

      this._previewSprite = this._previewGraphics;
      this._previewBitmap = null;
    }

    _createGhostTilemap() {
      if (this._ghostTilemap) return;

      const mainTilemap = this._spriteset && this._spriteset._tilemap;
      if (!mainTilemap || !mainTilemap.parent) return;

      const bitmaps =
        (Array.isArray(mainTilemap._bitmaps) && mainTilemap._bitmaps.length > 0) ? mainTilemap._bitmaps :
        (typeof mainTilemap.bitmaps === "function" && Array.isArray(mainTilemap.bitmaps())) ? mainTilemap.bitmaps() :
        (Array.isArray(mainTilemap.bitmaps)) ? mainTilemap.bitmaps :
        null;

      if (!Array.isArray(bitmaps) || bitmaps.length === 0 || bitmaps.some(b => !b)) return;

      const ghost = new Tilemap();
      ghost.setBitmaps(bitmaps);
      ghost.flags = $gameMap.tilesetFlags();
      ghost.alpha = 0.6;
      ghost.x = mainTilemap.x || 0;
      ghost.y = mainTilemap.y || 0;
      ghost.origin.x = mainTilemap.origin ? mainTilemap.origin.x : 0;
      ghost.origin.y = mainTilemap.origin ? mainTilemap.origin.y : 0;

      mainTilemap.parent.addChildAt(ghost, mainTilemap.parent.getChildIndex(mainTilemap) + 1);

      this._ghostTilemap = ghost;
      this._ghostReady = false;
      this._ghostTemplateKey = "";
      this._lastGhostPosKey = "";

      if (this._spriteset) {
        this._spriteset._dbGhostTilemap = ghost;
        this._spriteset.dbReorderCharactersAboveGhost?.(ghost);
      }
    }

    _refreshGhostTemplate(force = false) {
      const t = BuildManager.template(this._templateId);
      if (!t || !this._ghostTilemap) return;

      const baseX = $gamePlayer.x;
      const baseY = $gamePlayer.y;
      const pasteX = baseX - t.anchorX;
      const pasteY = baseY - t.anchorY;

      const key = [
        this._templateId, t.sourceMapId, t.rectX, t.rectY, t.rectW, t.rectH,
        pasteX, pasteY,
        $gameMap.mapId(), $gameMap.width(), $gameMap.height()
      ].join(",");
      if (!force && key === this._ghostTemplateKey) return;
      this._ghostTemplateKey = key;

      const applyGhostData = (tpl) => {
        if (!this._ghostTilemap) return;

        const mapW = $gameMap.width();
        const mapH = $gameMap.height();
        const LAYERS = 6;
        const data = new Array(mapW * mapH * LAYERS).fill(0);
        const index = (x, y, z) => (z * mapH + y) * mapW + x;

        for (let dy = 0; dy < t.rectH; dy++) {
          for (let dx = 0; dx < t.rectW; dx++) {
            const tx = pasteX + dx;
            const ty = pasteY + dy;
            if (!$gameMap.isValid(tx, ty)) continue;

            for (const z of BUILD_PREVIEW_LAYERS) {
              const tileId = (tpl.tiles[z] && tpl.tiles[z][dy]) ? (tpl.tiles[z][dy][dx] || 0) : 0;
              if (tileId > 0) data[index(tx, ty, z)] = tileId;
            }
          }
        }

        const mainTilemap = this._spriteset && this._spriteset._tilemap;
        const bitmaps = mainTilemap ? (
          (Array.isArray(mainTilemap._bitmaps) && mainTilemap._bitmaps.length > 0) ? mainTilemap._bitmaps :
          (typeof mainTilemap.bitmaps === "function" && Array.isArray(mainTilemap.bitmaps())) ? mainTilemap.bitmaps() :
          (Array.isArray(mainTilemap.bitmaps)) ? mainTilemap.bitmaps : null
        ) : null;

        if (Array.isArray(bitmaps) && bitmaps.length > 0 && !bitmaps.some(b => !b)) {
          this._ghostTilemap.setBitmaps(bitmaps);
        }

        this._ghostTilemap.flags = $gameMap.tilesetFlags();

        // ★UM7対策：内部キャッシュを強制クリア
        if (this._ghostTilemap._lowerLayer) this._ghostTilemap._lowerLayer.clear();
        if (this._ghostTilemap._upperLayer) this._ghostTilemap._upperLayer.clear();
        this._ghostTilemap._lastTiles = [];
        this._ghostTilemap.setData(mapW, mapH, data);
        this._ghostTilemap._needsRepaint = true;
        this._ghostTilemap.refresh();

        this._ghostReady = true;
        this._updateGhostPositionAndAlpha(true);

        if (this._spriteset) {
          this._spriteset.dbReorderCharactersAboveGhost?.(this._ghostTilemap);
        }
      };

      if (this._ghostTpl) {
        applyGhostData(this._ghostTpl);
        return;
      }

      if (this._ghostLoading) return;
      this._ghostLoading = true;

      BuildTemplateManager.loadTemplate(t).then(tpl => {
        this._ghostLoading = false;
        this._ghostTpl = tpl;
        applyGhostData(tpl);
      }).catch(e => {
        this._ghostLoading = false;
        console.error(e);
        this._ghostReady = false;
      });
    }

    _updateGhostPositionAndAlpha(force = false) {
      if (!this._ghostTilemap) return;

      const t = BuildManager.template(this._templateId);
      if (!t) return;

      const mainTilemap = this._spriteset && this._spriteset._tilemap;
      const ox = mainTilemap && mainTilemap.origin ? mainTilemap.origin.x : Math.floor($gameMap.displayX() * $gameMap.tileWidth());
      const oy = mainTilemap && mainTilemap.origin ? mainTilemap.origin.y : Math.floor($gameMap.displayY() * $gameMap.tileHeight());
      const px = mainTilemap ? (mainTilemap.x || 0) : 0;
      const py = mainTilemap ? (mainTilemap.y || 0) : 0;

      const key = [ox, oy, px, py, $gameMap.displayX(), $gameMap.displayY()].join(",");
      if (!force && key === this._lastGhostPosKey) {
        const baseX = $gamePlayer.x;
        const baseY = $gamePlayer.y;
        const pasteX = baseX - t.anchorX;
        const pasteY = baseY - t.anchorY;
        const ok = this._canPlace ? this._canPlace(pasteX, pasteY, t.rectW, t.rectH) : BuildManager.canPlaceAt($gameMap.mapId(), pasteX, pasteY, t.rectW, t.rectH);
        this._ghostTilemap.alpha = ok ? 0.6 : 0.25;
        return;
      }
      this._lastGhostPosKey = key;

      this._ghostTilemap.x = px;
      this._ghostTilemap.y = py;
      this._ghostTilemap.origin.x = ox;
      this._ghostTilemap.origin.y = oy;

      const baseX = $gamePlayer.x;
      const baseY = $gamePlayer.y;
      const pasteX = baseX - t.anchorX;
      const pasteY = baseY - t.anchorY;
      const ok = this._canPlace ? this._canPlace(pasteX, pasteY, t.rectW, t.rectH) : BuildManager.canPlaceAt($gameMap.mapId(), pasteX, pasteY, t.rectW, t.rectH);
      this._ghostTilemap.alpha = ok ? 0.6 : 0.25;
    }

    _updateBuildPreview(force = false) {
      if (!this._previewGraphics) return;

      const t = BuildManager.template(this._templateId);
      if (!t) return;

      const baseX = $gamePlayer.x;
      const baseY = $gamePlayer.y;
      const pasteX = baseX - t.anchorX;
      const pasteY = baseY - t.anchorY;

      const key = [
        baseX, baseY,
        $gameMap.displayX(), $gameMap.displayY(),
        pasteX, pasteY,
        t.rectW, t.rectH,
        BuildManager._allowedRegion, BuildManager._forbiddenRegion,
        this._buildingId,
        dbIsUltraMode7Active() ? "um7" : "normal"
      ].join(",");

      if (!force && key === this._lastPreviewKey) return;
      this._lastPreviewKey = key;

      const ok = this._canPlace(pasteX, pasteY, t.rectW, t.rectH);

      const g = this._previewGraphics;
      g.clear();

      const fillColor = ok ? 0x50ff78 : 0xff5050;
      const lineColor = ok ? 0x50ff78 : 0xff5050;
      const fillAlpha = 0.25;
      const lineAlpha = 0.75;

      for (let dy = 0; dy < t.rectH; dy++) {
        for (let dx = 0; dx < t.rectW; dx++) {
          const tx = pasteX + dx;
          const ty = pasteY + dy;

          if (!$gameMap.isValid(tx, ty)) continue;

          dbDrawPreviewTilePolygon(g, tx, ty, fillColor, fillAlpha, lineColor, lineAlpha);
        }
      }
    }

_clearPreviewEvents() {
  if (this._previewEventInfos && this._previewEventInfos.length > 0) {
    for (const info of this._previewEventInfos) {
      $gameMap.eraseDynamicEvent(info.id);
    }
  }
  this._previewEventInfos = [];
  this._previewTplLoaded = false;
  // ※ _lastPreviewEventKey は呼び出し元で必要に応じて消す
}


_updatePreviewEvents(force = false) {
  const t = BuildManager.template(this._templateId);
  if (!t) return;

  const baseX = $gamePlayer.x;
  const baseY = $gamePlayer.y;
  const pasteX = baseX - t.anchorX;
  const pasteY = baseY - t.anchorY;

  const key = [this._templateId, pasteX, pasteY].join(",");
  if (!force && key === this._lastPreviewEventKey) return;
  this._lastPreviewEventKey = key;

  // -----------------------------------------
  // 1) すでに生成済みなら「位置だけ更新」＝点滅しない
  // -----------------------------------------
  if (this._previewEventInfos && this._previewEventInfos.length > 0) {
    for (const info of this._previewEventInfos) {
      const ev = $gameMap.event(info.id);
      if (!ev) continue;
      ev.locate(pasteX + info.ox, pasteY + info.oy);
      ev.refresh?.();
    }
    return;
  }

  // -----------------------------------------
  // 2) 未生成なら「1回だけ生成」
  // -----------------------------------------
  BuildTemplateManager.loadTemplate(t).then(tpl => {
    // すでに別キーで生成済みになってたら二重生成を避ける
    if (this._previewEventInfos && this._previewEventInfos.length > 0) return;

    const infos = [];

    for (const srcEv of tpl.events) {
      const previewEv = makePreviewEventDataFromTemplateEvent(srcEv);
      if (!previewEv) continue;

      const ox = (srcEv.x - t.rectX);
      const oy = (srcEv.y - t.rectY);

      previewEv.x = pasteX + ox;
      previewEv.y = pasteY + oy;

      previewEv._dynamicMapId = $gameMap.mapId();
      previewEv._dynamicBuildingId = "__PREVIEW__";
      previewEv._dbPreview = true;

      const newId = $gameMap.spawnDynamicEvent(previewEv);
      infos.push({ id: newId, ox, oy });
    }

    this._previewEventInfos = infos;

    // 最初の生成だけは同期が必要（追加されたため）
    if ($gameTemp) $gameTemp._dbNeedCharacterSpriteSync = true;
  }).catch(e => console.error(e));
}


    update() {
      if (!this._buildReady) {
        Scene_Map.prototype.update.call(this);
        return;
      }

      if (this._dbInputLocked || isTransitionBusy(this)) {
        Scene_Map.prototype.update.call(this);
        return;
      }

      if (Input.isTriggered("ok")) {
        lockSceneInput(this);

        const x = $gamePlayer.x;
        const y = $gamePlayer.y;

        BuildManager.moveBuildingAt(this._pickX, this._pickY, x, y, $gameMap.mapId())
          .then(r => {
            if (r && r.ok) {
              this._committed = true;
              SoundManager.playOk();
              this._clearPreviewEvents();
              safePopToMap();
            } else {
              SoundManager.playBuzzer();
              unlockSceneInput(this);
            }
          })
          .catch(e => {
            console.error(e);
            SoundManager.playBuzzer();
            unlockSceneInput(this);
          });

        return;
      }

      if (Input.isTriggered("cancel")) {
        lockSceneInput(this);
        SoundManager.playCancel();

        this._returnToPick = true;

        if (this._buildingId) BuildManager._restoreDetachedBuildingVisuals(this._buildingId, $gameMap.mapId());

        this._clearPreviewEvents();
        safeReturnToMovePick($gameMap.mapId());
        return;
      }

      Scene_Map.prototype.update.call(this);

      this._updateBuildPreview(false);

      if (!this._ghostTilemap) {
        this._createGhostTilemap();
      }
      if (this._ghostTilemap) this._refreshGhostTemplate(false);
      this._updateGhostPositionAndAlpha(false);

      this._updatePreviewEvents(false);
    }

    terminate() {
      Scene_Map.prototype.terminate.call(this);

      this._clearPreviewEvents();

      if (this._previewGraphics) {
        this.removeChild(this._previewGraphics);
        this._previewGraphics.destroy();
        this._previewGraphics = null;
      }
      this._previewSprite = null;

      if (this._previewBitmap) {
        this._previewBitmap.destroy();
        this._previewBitmap = null;
      }

      this._ghostTpl = null;
      this._ghostLoading = false;

      if (this._ghostTilemap) {
        if (this._spriteset && this._spriteset._dbGhostTilemap === this._ghostTilemap) {
          this._spriteset._dbGhostTilemap = null;
        }

        const p = this._ghostTilemap.parent;
        if (p) p.removeChild(this._ghostTilemap);
        this._ghostTilemap.destroy({ children: true });
        this._ghostTilemap = null;
      }

      if (!this._committed && this._buildingId) {
        BuildManager._restoreDetachedBuildingVisuals(this._buildingId, $gameMap.mapId());
        if (!this._returnToPick) BuildManager.runCancelHandlers("move");
      }
    }
  }

  // -------------------------------------------------------------------
  // safe pop helpers
  // -------------------------------------------------------------------
  let __dbPopLockFrame = -1;

  function safePopToMap() {
    if (__dbPopLockFrame === Graphics.frameCount) return;
    __dbPopLockFrame = Graphics.frameCount;

    Input.clear();
    TouchInput.clear();

    if (SceneManager._stack && SceneManager._stack.length > 0) SceneManager.pop();
    else {
      console.warn("[BUILD] safePopToMap: stack empty -> goto(Scene_Map)");
      SceneManager.goto(Scene_Map);
    }
  }

  function safeReturnToMovePick(mapId) {
    Input.clear();
    TouchInput.clear();

    if (SceneManager._stack && SceneManager._stack.length > 0) {
      SceneManager.pop();
      return;
    }

    console.warn("[BUILD] safeReturnToMovePick: stack empty -> goto(Scene_MovePick)");
    SceneManager.goto(Scene_MovePick);
    SceneManager.prepareNextScene(Number(mapId || 0) || $gameMap.mapId());
  }

  // -------------------------------------------------------------------
  // プラグインコマンド（★省略なし）
  // -------------------------------------------------------------------
  PluginManager.registerCommand(PLUGIN_NAME, "SetBuildRegions", args => {
    BuildManager.setRegions(Number(args.allowed || 0), Number(args.forbidden || 0));
  });

  PluginManager.registerCommand(PLUGIN_NAME, "RemoveBuildingAt", args => {
    const x = Number(args.x || 0);
    const y = Number(args.y || 0);
    const targetMapId = Number(args.targetMapId || 0);

    const r = BuildManager.removeBuildingAt(x, y, targetMapId);
    if (!r.ok) SoundManager.playBuzzer();
    else SoundManager.playOk();
  });

  PluginManager.registerCommand(PLUGIN_NAME, "MoveBuildingAt", args => {
    console.warn("[BUILD] MoveBuildingAt called", PLUGIN_NAME, args);

    const fromX = Number(args.fromX || 0);
    const fromY = Number(args.fromY || 0);
    const toX = Number(args.toX || 0);
    const toY = Number(args.toY || 0);
    const targetMapId = Number(args.targetMapId || 0);

    BuildManager.moveBuildingAt(fromX, fromY, toX, toY, targetMapId)
      .then(r => {
        console.warn("[BUILD] MoveBuildingAt result", r);
        if (!r || !r.ok) SoundManager.playBuzzer();
        else SoundManager.playOk();
      })
      .catch(e => {
        console.error(e);
        SoundManager.playBuzzer();
      });
  });

  PluginManager.registerCommand(PLUGIN_NAME, "PlaceBuilding", args => {
    console.warn("[BUILD] PlaceBuilding called", PLUGIN_NAME, args);

    const templateId = String(args.templateId || "");
    const x = Number(args.x || 0);
    const y = Number(args.y || 0);
    const targetMapId = Number(args.targetMapId || 0);

    BuildManager.placeBuilding(templateId, x, y, targetMapId)
      .then(r => {
        console.warn("[BUILD] PlaceBuilding result", r);
        if (!r || !r.ok) {
          SoundManager.playBuzzer();
        } else {
          BuildManager.runPlaceCommandCompleteHandler();
          SoundManager.playOk();
        }
      })
      .catch(e => {
        console.error(e);
        SoundManager.playBuzzer();
      });
  });

  PluginManager.registerCommand(PLUGIN_NAME, "OpenBuildMode", args => {
    const templateId = String(args.templateId || "");
    BuildManager.requestOpenBuildMode(templateId);
  });

  PluginManager.registerCommand(PLUGIN_NAME, "OpenMoveMode", args => {
    // header に x,y もあるが、この実装では「歩いて選ぶ」方式なので targetMapId のみ使用
    const targetMapId = Number(args.targetMapId || 0) || $gameMap.mapId();
    BuildManager.requestOpenMoveMode(targetMapId);
  });

  PluginManager.registerCommand(PLUGIN_NAME, "SetCancelHandlers", args => {
    const buildSw = Number(args.buildCancelSwitchId || 0);
    const buildCe = Number(args.buildCancelCommonEventId || 0);
    const moveSw  = Number(args.moveCancelSwitchId || 0);
    const moveCe  = Number(args.moveCancelCommonEventId || 0);

    BuildManager.setCancelHandlers(buildSw, buildCe, moveSw, moveCe);
  });

  PluginManager.registerCommand(PLUGIN_NAME, "SetSharedMaps", args => {
    const s = String(args.mapIds || "");
    BuildManager.setSharedMaps(s);
    console.warn("[BUILD] SetSharedMaps:", BuildManager._sharedMapIds);
  });

  PluginManager.registerCommand(PLUGIN_NAME, "ClearSharedMaps", args => {
    BuildManager.clearSharedMaps();
    console.warn("[BUILD] ClearSharedMaps");
  });

  PluginManager.registerCommand(PLUGIN_NAME, "RecalculateBuildingEffects", args => {
    const targetMapIds = String(args.targetMapIds || "0");
    const r = BuildManager.recalculateBuildingEffects(targetMapIds);
    if (!r || !r.ok) SoundManager.playBuzzer();
  });

  PluginManager.registerCommand(PLUGIN_NAME, "CountBuildings", args => {
    const templateIds = String(args.templateIds || "");
    const targetMapIds = String(args.targetMapIds || "0");
    const resultVariableId = Number(args.resultVariableId || 0);

    const r = BuildManager.countBuildings(templateIds, targetMapIds);
    if (!r || !r.ok) {
      SoundManager.playBuzzer();
      return;
    }

    if (resultVariableId > 0) {
      $gameVariables.setValue(resultVariableId, Number(r.count || 0));
    }
  });


  PluginManager.registerCommand(PLUGIN_NAME, "RecalculateBuildingAreaEffects", args => {
    const targetMapIds = String(args.targetMapIds || "0");
    const r = BuildManager.recalculateBuildingAreaEffects(targetMapIds);
    if (!r || !r.ok) SoundManager.playBuzzer();
  });


})();
