/*:
 * @target MZ
 * @plugindesc v2.4 簡易画像メニュー作成プラグイン
 * @author OpenAI
 *
 * @help
 * 画像付きの簡易メニューを表示するプラグインです。
 *
 * ■機能
 * ・メニューウィンドウの座標とサイズ指定
 * ・背景画像指定
 * ・呼び出し前画面のスクショ背景対応
 * ・ウィンドウ専用背景画像指定
 * ・縦横項目数指定
 * ・項目開始座標指定
 * ・項目の横間隔 / 縦間隔指定
 * ・項目画像表示
 * ・項目サイズ指定
 * ・カーソル移動押しっぱなし時の待機ウェイト指定
 * ・カーソルループ対応
 * ・マウスクリック決定
 * ・マウス右クリックキャンセル
 * ・カーソル画像指定
 * ・カーソル画像アニメーション対応
 * ・カーソル画像点滅対応
 * ・カーソルSE変更対応
 * ・マウスで項目に乗った時にもカーソルSE再生
 * ・項目選択後にメニューを閉じてコモンイベント実行
 *
 * ■画像配置
 * 背景画像           : img/pictures/
 * ウィンドウ背景画像 : img/pictures/
 * 項目画像           : img/pictures/
 * カーソル画像       : img/pictures/
 *
 * ■SE配置
 * カーソルSE         : audio/se/
 *
 * ■背景について
 * useSceneScreenshotBackground = true の場合、
 * プラグインコマンド実行直前の画面を撮って背景に使います。
 *
 * backgroundImage が指定されている場合は固定画像背景です。
 * useSceneScreenshotBackground が true のときは、固定背景画像よりスクショ背景を優先します。
 *
 * ■windowBackgroundImage について
 * メニューウィンドウの位置とサイズに合わせて表示される背景画像です。
 * 項目より後ろに表示されます。
 *
 * ■カーソル画像について
 * cursorFrames を 1 以上にした場合、
 * カーソル画像を横一列の分割アニメとして扱います。
 *
 * 例:
 * 画像幅 192px, cursorFrames = 3
 * → 64px x 高さ の3コマとして再生
 *
 * cursorFrames = 1 の場合は通常の1枚画像として表示します。
 *
 * ■cursorOffsetX / cursorOffsetY について
 * 選択中項目の左上座標から、カーソル画像をどれだけずらすかの補正値です。
 * 0なら項目左上基準です。
 *
 * ■cursorSeName について
 * audio/se 内のSEファイル名を指定します。
 * 空欄の場合は標準カーソル音を使います。
 *
 * ■items の記述例
 * [
 *   {"name":"道具","image":"MenuItem_Item","commonEventId":"1","enabled":"true"},
 *   {"name":"装備","image":"MenuItem_Equip","commonEventId":"2","enabled":"true"},
 *   {"name":"セーブ","image":"MenuItem_Save","commonEventId":"3","enabled":"true"},
 *   {"name":"終了","image":"MenuItem_End","commonEventId":"4","enabled":"true"}
 * ]
 *
 * @command openMenu
 * @text メニューを開く
 * @desc 指定内容で簡易画像メニューを開きます。
 *
 * @arg x
 * @text ウィンドウX
 * @type number
 * @default 100
 *
 * @arg y
 * @text ウィンドウY
 * @type number
 * @default 100
 *
 * @arg width
 * @text ウィンドウ幅
 * @type number
 * @default 800
 *
 * @arg height
 * @text ウィンドウ高さ
 * @type number
 * @default 500
 *
 * @arg rows
 * @text 縦項目数
 * @type number
 * @min 1
 * @default 2
 *
 * @arg cols
 * @text 横項目数
 * @type number
 * @min 1
 * @default 4
 *
 * @arg startX
 * @text 項目開始X
 * @type number
 * @default 0
 *
 * @arg startY
 * @text 項目開始Y
 * @type number
 * @default 0
 *
 * @arg itemWidth
 * @text 項目幅
 * @type number
 * @min 1
 * @default 120
 *
 * @arg itemHeight
 * @text 項目高さ
 * @type number
 * @min 1
 * @default 120
 *
 * @arg spacingX
 * @text 項目横間隔
 * @type number
 * @default 0
 *
 * @arg spacingY
 * @text 項目縦間隔
 * @type number
 * @default 0
 *
 * @arg useSceneScreenshotBackground
 * @text 画面スクショ背景を使う
 * @type boolean
 * @on 使う
 * @off 使わない
 * @default false
 *
 * @arg backgroundImage
 * @text 固定背景画像
 * @type file
 * @dir img/pictures
 * @default
 *
 * @arg windowBackgroundImage
 * @text ウィンドウ背景画像
 * @type file
 * @dir img/pictures
 * @default
 *
 * @arg repeatWait
 * @text 押しっぱなし初期待機
 * @desc 連続移動開始までの待機フレーム
 * @type number
 * @min 0
 * @default 12
 *
 * @arg repeatInterval
 * @text 押しっぱなし間隔
 * @desc 2回目以降の移動間隔フレーム
 * @type number
 * @min 1
 * @default 4
 *
 * @arg loopCursor
 * @text カーソルループ
 * @type boolean
 * @on する
 * @off しない
 * @default true
 *
 * @arg cursorImage
 * @text カーソル画像
 * @type file
 * @dir img/pictures
 * @default
 *
 * @arg cursorOffsetX
 * @text カーソル補正X
 * @type number
 * @default 0
 *
 * @arg cursorOffsetY
 * @text カーソル補正Y
 * @type number
 * @default 0
 *
 * @arg cursorFrames
 * @text カーソルコマ数
 * @desc 横一列の分割数。1なら通常画像
 * @type number
 * @min 1
 * @default 1
 *
 * @arg cursorFrameWait
 * @text カーソルアニメ間隔
 * @desc コマ送り間隔フレーム
 * @type number
 * @min 1
 * @default 8
 *
 * @arg cursorBlink
 * @text カーソル点滅
 * @type boolean
 * @on する
 * @off しない
 * @default false
 *
 * @arg cursorBlinkSpeed
 * @text カーソル点滅速度
 * @desc 数値が大きいほど遅い
 * @type number
 * @min 1
 * @default 30
 *
 * @arg cursorSeName
 * @text カーソルSEファイル名
 * @desc audio/se 内のファイル名。空なら標準カーソル音
 * @type file
 * @dir audio/se
 * @default
 *
 * @arg cursorSeVolume
 * @text カーソルSE音量
 * @type number
 * @min 0
 * @max 100
 * @default 90
 *
 * @arg cursorSePitch
 * @text カーソルSEピッチ
 * @type number
 * @min 50
 * @max 150
 * @default 100
 *
 * @arg cursorSePan
 * @text カーソルSE位相
 * @type number
 * @min -100
 * @max 100
 * @default 0
 *
 * @arg cancelCommonEventId
 * @text キャンセル時コモンイベント
 * @desc 0なら何もしません
 * @type common_event
 * @default 0
 *
 * @arg items
 * @text 項目一覧
 * @type struct<MenuItem>[]
 * @default []
 */

/*~struct~MenuItem:
 * @param name
 * @text 項目名
 * @type string
 * @default Item
 *
 * @param image
 * @text 項目画像
 * @type file
 * @dir img/pictures
 * @default
 *
 * @param commonEventId
 * @text コモンイベントID
 * @type common_event
 * @default 1
 *
 * @param enabled
 * @text 有効
 * @type boolean
 * @on 有効
 * @off 無効
 * @default true
 */

(() => {
    "use strict";

    const pluginName = "DB_SimpleImageMenu";

    function toNumber(value, defaultValue) {
        const n = Number(value);
        return isNaN(n) ? defaultValue : n;
    }

    function toBoolean(value, defaultValue) {
        if (value === true || value === "true") return true;
        if (value === false || value === "false") return false;
        return defaultValue;
    }

    function clamp(value, min, max) {
        return Math.max(min, Math.min(max, value));
    }

    function parseItems(raw) {
        let array = [];
        try {
            array = JSON.parse(raw || "[]");
        } catch (e) {
            console.error(`[${pluginName}] items parse error(1)`, e);
            return [];
        }

        return array.map(text => {
            let obj = {};
            try {
                obj = JSON.parse(text);
            } catch (e) {
                console.error(`[${pluginName}] items parse error(2)`, e, text);
            }
            return {
                name: String(obj.name || ""),
                image: String(obj.image || ""),
                commonEventId: toNumber(obj.commonEventId, 0),
                enabled: obj.enabled === undefined ? true : toBoolean(obj.enabled, true)
            };
        });
    }

    const SimpleImageMenuManager = {
        _config: null,

        setConfig(config) {
            this._config = config;
        },

        getConfig() {
            return this._config;
        },

        clear() {
            this._config = null;
        }
    };

    PluginManager.registerCommand(pluginName, "openMenu", args => {
        const config = {
            x: toNumber(args.x, 100),
            y: toNumber(args.y, 100),
            width: toNumber(args.width, 800),
            height: toNumber(args.height, 500),
            rows: Math.max(1, toNumber(args.rows, 2)),
            cols: Math.max(1, toNumber(args.cols, 4)),
            startX: toNumber(args.startX, 0),
            startY: toNumber(args.startY, 0),
            itemWidth: Math.max(1, toNumber(args.itemWidth, 120)),
            itemHeight: Math.max(1, toNumber(args.itemHeight, 120)),
            spacingX: toNumber(args.spacingX, 0),
            spacingY: toNumber(args.spacingY, 0),
            useSceneScreenshotBackground: toBoolean(args.useSceneScreenshotBackground, false),
            backgroundImage: String(args.backgroundImage || ""),
            windowBackgroundImage: String(args.windowBackgroundImage || ""),
            repeatWait: Math.max(0, toNumber(args.repeatWait, 12)),
            repeatInterval: Math.max(1, toNumber(args.repeatInterval, 4)),
            loopCursor: toBoolean(args.loopCursor, true),
            cursorImage: String(args.cursorImage || ""),
            cursorOffsetX: toNumber(args.cursorOffsetX, 0),
            cursorOffsetY: toNumber(args.cursorOffsetY, 0),
            cursorFrames: Math.max(1, toNumber(args.cursorFrames, 1)),
            cursorFrameWait: Math.max(1, toNumber(args.cursorFrameWait, 8)),
            cursorBlink: toBoolean(args.cursorBlink, false),
            cursorBlinkSpeed: Math.max(1, toNumber(args.cursorBlinkSpeed, 30)),
            cursorSeName: String(args.cursorSeName || ""),
            cursorSeVolume: clamp(toNumber(args.cursorSeVolume, 90), 0, 100),
            cursorSePitch: clamp(toNumber(args.cursorSePitch, 100), 50, 150),
            cursorSePan: clamp(toNumber(args.cursorSePan, 0), -100, 100),
            cancelCommonEventId: toNumber(args.cancelCommonEventId, 0),
            items: parseItems(args.items)
        };

        SimpleImageMenuManager.setConfig(config);

        if (config.useSceneScreenshotBackground && SceneManager.snapForBackground) {
            SceneManager.snapForBackground();
        }

        SceneManager.push(Scene_SimpleImageMenu);
    });

    Input.isRepeatedEx = function(keyName, wait, interval) {
        if (this._isEscapeCompatible(keyName) && this.isRepeatedEx("escape", wait, interval)) {
            return true;
        }
        return (
            this._latestButton === keyName &&
            (this._pressedTime === 0 ||
                (this._pressedTime >= wait && this._pressedTime % interval === 0))
        );
    };

    function Window_SimpleImageMenu() {
        this.initialize(...arguments);
    }

    Window_SimpleImageMenu.prototype = Object.create(Window_Selectable.prototype);
    Window_SimpleImageMenu.prototype.constructor = Window_SimpleImageMenu;

    Window_SimpleImageMenu.prototype.initialize = function(rect, config) {
        this._config = config;
        this._items = config.items || [];
        this._itemSprites = [];
        this._repeatWait = config.repeatWait;
        this._repeatInterval = config.repeatInterval;
        this._ownerScene = null;
        this._windowBackgroundSprite = null;
        this._windowBackgroundBitmap = null;

        Window_Selectable.prototype.initialize.call(this, rect);

        this.opacity = 0;
        this.backOpacity = 0;
        this.contentsOpacity = 255;

        this.createWindowBackgroundSprite();
        this.refresh();

        if (this.maxItems() > 0) {
            this.select(0);
        } else {
            this._index = -1;
        }

        this.activate();
    };

    Window_SimpleImageMenu.prototype.setOwnerScene = function(scene) {
        this._ownerScene = scene;
    };

    Window_SimpleImageMenu.prototype.maxItems = function() {
        return this._items.length;
    };

    Window_SimpleImageMenu.prototype.maxCols = function() {
        return Math.max(1, this._config.cols || 1);
    };

    Window_SimpleImageMenu.prototype.maxRows = function() {
        return Math.max(1, Math.ceil(this.maxItems() / this.maxCols()));
    };

    Window_SimpleImageMenu.prototype.itemWidth = function() {
        return this._config.itemWidth;
    };

    Window_SimpleImageMenu.prototype.itemHeight = function() {
        return this._config.itemHeight;
    };

    Window_SimpleImageMenu.prototype.colSpacing = function() {
        return 0;
    };

    Window_SimpleImageMenu.prototype.rowSpacing = function() {
        return 0;
    };

    Window_SimpleImageMenu.prototype.spacing = function() {
        return 0;
    };

    Window_SimpleImageMenu.prototype.refreshCursor = function() {
    };

    Window_SimpleImageMenu.prototype.updateCursor = function() {
    };

    Window_SimpleImageMenu.prototype.ensureCursorVisible = function() {
    };

    Window_SimpleImageMenu.prototype.itemRect = function(index) {
        const rect = new Rectangle(0, 0, this.itemWidth(), this.itemHeight());
        const col = index % this.maxCols();
        const row = Math.floor(index / this.maxCols());
        rect.x = this._config.startX + col * (this.itemWidth() + this._config.spacingX);
        rect.y = this._config.startY + row * (this.itemHeight() + this._config.spacingY);
        return rect;
    };

    Window_SimpleImageMenu.prototype.itemScreenRect = function(index) {
        const rect = this.itemRect(index);
        const x = this.x + this.padding + rect.x - this.origin.x;
        const y = this.y + this.padding + rect.y - this.origin.y;
        return new Rectangle(x, y, rect.width, rect.height);
    };

    Window_SimpleImageMenu.prototype.createWindowBackgroundSprite = function() {
        if (!this._config.windowBackgroundImage) {
            return;
        }

        this._windowBackgroundSprite = new Sprite();
        this._windowBackgroundBitmap = ImageManager.loadPicture(this._config.windowBackgroundImage);
        this._windowBackgroundSprite.bitmap = this._windowBackgroundBitmap;
        this._windowBackgroundSprite.x = 0;
        this._windowBackgroundSprite.y = 0;

        this.addChildToBack(this._windowBackgroundSprite);

        this._windowBackgroundBitmap.addLoadListener(() => {
            const bw = Math.max(1, this._windowBackgroundBitmap.width);
            const bh = Math.max(1, this._windowBackgroundBitmap.height);
            this._windowBackgroundSprite.scale.x = this.width / bw;
            this._windowBackgroundSprite.scale.y = this.height / bh;
        });
    };

    Window_SimpleImageMenu.prototype.refresh = function() {
        if (this.contents) {
            this.contents.clear();
        }
        this.clearItemSprites();
        this.drawAllItems();
    };

    Window_SimpleImageMenu.prototype.drawAllItems = function() {
        for (let i = 0; i < this.maxItems(); i++) {
            this.drawItem(i);
        }
    };

    Window_SimpleImageMenu.prototype.drawItem = function(index) {
        const item = this._items[index];
        const rect = this.itemRect(index);

        const sprite = new Sprite();
        sprite.x = rect.x;
        sprite.y = rect.y;

        if (item.image) {
            sprite.bitmap = ImageManager.loadPicture(item.image);
            sprite.bitmap.addLoadListener(() => {
                const bw = Math.max(1, sprite.bitmap.width);
                const bh = Math.max(1, sprite.bitmap.height);
                sprite.scale.x = rect.width / bw;
                sprite.scale.y = rect.height / bh;
            });
        } else {
            const bmp = new Bitmap(rect.width, rect.height);
            bmp.drawText(item.name || "", 0, rect.height / 2 - 18, rect.width, 36, "center");
            sprite.bitmap = bmp;
        }

        sprite.opacity = item.enabled ? 255 : 120;
        this.addInnerChild(sprite);
        this._itemSprites.push(sprite);

        if (!item.enabled) {
            const maskBitmap = new Bitmap(rect.width, rect.height);
            maskBitmap.fillRect(0, 0, rect.width, rect.height, "rgba(0,0,0,0.35)");
            const maskSprite = new Sprite(maskBitmap);
            maskSprite.x = rect.x;
            maskSprite.y = rect.y;
            this.addInnerChild(maskSprite);
            this._itemSprites.push(maskSprite);
        }
    };

    Window_SimpleImageMenu.prototype.clearItemSprites = function() {
        if (!this._itemSprites) return;
        for (const sprite of this._itemSprites) {
            if (sprite && sprite.parent) {
                sprite.parent.removeChild(sprite);
            }
        }
        this._itemSprites = [];
    };

    Window_SimpleImageMenu.prototype.currentItem = function() {
        return this._items[this.index()];
    };

    Window_SimpleImageMenu.prototype.isCurrentItemEnabled = function() {
        const item = this.currentItem();
        return !!(item && item.enabled);
    };

    Window_SimpleImageMenu.prototype.isOkEnabled = function() {
        return this.maxItems() > 0;
    };

    Window_SimpleImageMenu.prototype.isCancelEnabled = function() {
        return true;
    };

    Window_SimpleImageMenu.prototype.playCustomCursorSound = function() {
        const name = String(this._config.cursorSeName || "");
        if (name) {
            AudioManager.playSe({
                name: name,
                volume: this._config.cursorSeVolume,
                pitch: this._config.cursorSePitch,
                pan: this._config.cursorSePan
            });
        } else {
            SoundManager.playCursor();
        }
    };

    Window_SimpleImageMenu.prototype.notifyCursorChanged = function() {
        if (this._ownerScene && this._ownerScene.updateMenuCursorSprite) {
            this._ownerScene.updateMenuCursorSprite(true);
        }
    };

    Window_SimpleImageMenu.prototype.select = function(index) {
        Window_Selectable.prototype.select.call(this, index);
        this.notifyCursorChanged();
    };

    Window_SimpleImageMenu.prototype.processCursorMove = function() {
        if (!this.isCursorMovable()) {
            return;
        }

        const lastIndex = this.index();

        if (Input.isRepeatedEx("down", this._repeatWait, this._repeatInterval)) {
            this.cursorDown(Input.isTriggered("down"));
        }
        if (Input.isRepeatedEx("up", this._repeatWait, this._repeatInterval)) {
            this.cursorUp(Input.isTriggered("up"));
        }
        if (Input.isRepeatedEx("right", this._repeatWait, this._repeatInterval)) {
            this.cursorRight(Input.isTriggered("right"));
        }
        if (Input.isRepeatedEx("left", this._repeatWait, this._repeatInterval)) {
            this.cursorLeft(Input.isTriggered("left"));
        }

        if (this.index() !== lastIndex) {
            this.playCustomCursorSound();
            this.notifyCursorChanged();
        }
    };

    Window_SimpleImageMenu.prototype.cursorDown = function(wrap) {
        if (this.maxItems() <= 0) return;

        const index = this.index();
        const maxItems = this.maxItems();
        const maxCols = this.maxCols();
        const maxRows = this.maxRows();
        const col = index % maxCols;
        let row = Math.floor(index / maxCols);
        row += 1;

        if (row >= maxRows) {
            if (this._config.loopCursor || wrap) {
                row = 0;
            } else {
                return;
            }
        }

        let newIndex = row * maxCols + col;
        while (newIndex >= maxItems && row > 0) {
            row -= 1;
            newIndex = row * maxCols + col;
        }

        this.select(clamp(newIndex, 0, maxItems - 1));
    };

    Window_SimpleImageMenu.prototype.cursorUp = function(wrap) {
        if (this.maxItems() <= 0) return;

        const index = this.index();
        const maxItems = this.maxItems();
        const maxCols = this.maxCols();
        const maxRows = this.maxRows();
        const col = index % maxCols;
        let row = Math.floor(index / maxCols);
        row -= 1;

        if (row < 0) {
            if (this._config.loopCursor || wrap) {
                row = maxRows - 1;
            } else {
                return;
            }
        }

        let newIndex = row * maxCols + col;
        while (newIndex >= maxItems && row > 0) {
            row -= 1;
            newIndex = row * maxCols + col;
        }

        this.select(clamp(newIndex, 0, maxItems - 1));
    };

    Window_SimpleImageMenu.prototype.cursorRight = function(wrap) {
        if (this.maxItems() <= 0) return;

        const index = this.index();
        const maxItems = this.maxItems();
        const maxCols = this.maxCols();
        const rowStart = Math.floor(index / maxCols) * maxCols;
        const rowEnd = Math.min(rowStart + maxCols - 1, maxItems - 1);
        let newIndex = index + 1;

        if (newIndex > rowEnd) {
            if (this._config.loopCursor || wrap) {
                newIndex = rowStart;
            } else {
                return;
            }
        }

        this.select(clamp(newIndex, 0, maxItems - 1));
    };

    Window_SimpleImageMenu.prototype.cursorLeft = function(wrap) {
        if (this.maxItems() <= 0) return;

        const index = this.index();
        const maxItems = this.maxItems();
        const maxCols = this.maxCols();
        const rowStart = Math.floor(index / maxCols) * maxCols;
        const rowEnd = Math.min(rowStart + maxCols - 1, maxItems - 1);
        let newIndex = index - 1;

        if (newIndex < rowStart) {
            if (this._config.loopCursor || wrap) {
                newIndex = rowEnd;
            } else {
                return;
            }
        }

        this.select(clamp(newIndex, 0, maxItems - 1));
    };

    Window_SimpleImageMenu.prototype.processHandling = function() {
        if (!this.isOpenAndActive()) {
            return;
        }

        if (this.isOkEnabled() && this.isOkTriggered()) {
            this.processOk();
        } else if (this.isCancelEnabled() && this.isCancelTriggered()) {
            this.processCancel();
        }
    };

    Window_SimpleImageMenu.prototype.isOkTriggered = function() {
        return Input.isTriggered("ok");
    };

    Window_SimpleImageMenu.prototype.isCancelTriggered = function() {
        return Input.isTriggered("cancel") || TouchInput.isCancelled();
    };

    Window_SimpleImageMenu.prototype.processTouch = function() {
        if (!this.isOpenAndActive()) {
            return;
        }

        if (TouchInput.isHovered() || TouchInput.isMoved() || TouchInput.isTriggered()) {
            const hitIndex = this.hitIndex();
            if (hitIndex >= 0) {
                if (this.index() !== hitIndex) {
                    this.select(hitIndex);
                    this.playCustomCursorSound();
                }
                if (TouchInput.isTriggered()) {
                    this.processOk();
                }
            }
        }

        if (TouchInput.isCancelled()) {
            this.processCancel();
        }
    };

    Window_SimpleImageMenu.prototype.hitIndex = function() {
        if (!this.worldTransform) {
            return -1;
        }

        const point = new Point(TouchInput.x, TouchInput.y);
        const local = this.worldTransform.applyInverse(point);
        const x = local.x - this.padding + this.origin.x;
        const y = local.y - this.padding + this.origin.y;

        for (let i = 0; i < this.maxItems(); i++) {
            const rect = this.itemRect(i);
            if (x >= rect.x && y >= rect.y && x < rect.x + rect.width && y < rect.y + rect.height) {
                return i;
            }
        }
        return -1;
    };

    Window_SimpleImageMenu.prototype.onTouchOkDisabled = function() {
        SoundManager.playBuzzer();
    };

    Window_SimpleImageMenu.prototype.processOk = function() {
        if (this.isCurrentItemEnabled()) {
            Window_Selectable.prototype.processOk.call(this);
        } else {
            this.onTouchOkDisabled();
        }
    };

    Window_SimpleImageMenu.prototype.update = function() {
        Window_Selectable.prototype.update.call(this);
        this.notifyCursorChanged();
    };

    Window_SimpleImageMenu.prototype.destroy = function(options) {
        this.clearItemSprites();
        if (this._windowBackgroundSprite && this._windowBackgroundSprite.parent) {
            this._windowBackgroundSprite.parent.removeChild(this._windowBackgroundSprite);
        }
        this._windowBackgroundSprite = null;
        Window_Selectable.prototype.destroy.call(this, options);
    };

    function Scene_SimpleImageMenu() {
        this.initialize(...arguments);
    }

    Scene_SimpleImageMenu.prototype = Object.create(Scene_MenuBase.prototype);
    Scene_SimpleImageMenu.prototype.constructor = Scene_SimpleImageMenu;

    Scene_SimpleImageMenu.prototype.initialize = function() {
        Scene_MenuBase.prototype.initialize.call(this);
        this._config = SimpleImageMenuManager.getConfig();
        this._menuCursorSprite = null;
        this._menuCursorBitmap = null;
        this._menuCursorAnimCount = 0;
        this._menuCursorBlinkCount = 0;
    };

    Scene_SimpleImageMenu.prototype.create = function() {
        Scene_MenuBase.prototype.create.call(this);
        this.createCustomBackgroundSprite();
        this.createMenuWindow();
        this.createMenuCursorSprite();
    };

    Scene_SimpleImageMenu.prototype.createBackground = function() {
        Scene_MenuBase.prototype.createBackground.call(this);

        if (this._config.useSceneScreenshotBackground) {
            if (this._backgroundSprite) {
                this._backgroundSprite.visible = true;
            }
        } else {
            if (this._backgroundSprite) {
                this._backgroundSprite.visible = false;
            }
        }
    };

    Scene_SimpleImageMenu.prototype.createCustomBackgroundSprite = function() {
        if (this._config.useSceneScreenshotBackground) {
            return;
        }

        if (this._config && this._config.backgroundImage) {
            this._menuBackgroundSprite = new Sprite(ImageManager.loadPicture(this._config.backgroundImage));
            this.addChildAt(this._menuBackgroundSprite, 0);
        }
    };

    Scene_SimpleImageMenu.prototype.createMenuWindow = function() {
        const rect = new Rectangle(
            this._config.x,
            this._config.y,
            this._config.width,
            this._config.height
        );
        this._menuWindow = new Window_SimpleImageMenu(rect, this._config);
        this._menuWindow.setOwnerScene(this);
        this._menuWindow.setHandler("ok", this.onItemOk.bind(this));
        this._menuWindow.setHandler("cancel", this.onItemCancel.bind(this));
        this.addWindow(this._menuWindow);
    };

    Scene_SimpleImageMenu.prototype.createMenuCursorSprite = function() {
        this._menuCursorSprite = new Sprite();
        this._menuCursorSprite.visible = false;

        if (this._config.cursorImage) {
            this._menuCursorBitmap = ImageManager.loadPicture(this._config.cursorImage);
            this._menuCursorSprite.bitmap = this._menuCursorBitmap;
        }

        this.addChild(this._menuCursorSprite);
        this.updateMenuCursorSprite(true);
    };

    Scene_SimpleImageMenu.prototype.updateMenuCursorSprite = function(force) {
        if (!this._menuCursorSprite || !this._menuWindow) {
            return;
        }

        const imageName = this._config.cursorImage || "";
        if (!imageName || !this._menuCursorBitmap) {
            this._menuCursorSprite.visible = false;
            return;
        }

        if (this._menuWindow.index() < 0 || this._menuWindow.maxItems() <= 0) {
            this._menuCursorSprite.visible = false;
            return;
        }

        const rect = this._menuWindow.itemScreenRect(this._menuWindow.index());
        const x = rect.x + this._config.cursorOffsetX;
        const y = rect.y + this._config.cursorOffsetY;

        if (force || this._menuCursorSprite.x !== x || this._menuCursorSprite.y !== y) {
            this._menuCursorSprite.move(x, y);
        }

        this._menuCursorSprite.visible = true;

        if (this._menuCursorBitmap.isReady()) {
            const frames = Math.max(1, this._config.cursorFrames || 1);
            const frameWidth = Math.floor(this._menuCursorBitmap.width / frames);
            const frameHeight = this._menuCursorBitmap.height;
            const frameIndex = frames > 1
                ? Math.floor(this._menuCursorAnimCount / this._config.cursorFrameWait) % frames
                : 0;

            this._menuCursorSprite.setFrame(
                frameIndex * frameWidth,
                0,
                frameWidth,
                frameHeight
            );
        }

        if (this._config.cursorBlink) {
            const speed = Math.max(1, this._config.cursorBlinkSpeed);
            const phase = (this._menuCursorBlinkCount % (speed * 2)) / speed;
            const wave = phase <= 1 ? phase : (2 - phase);
            this._menuCursorSprite.opacity = Math.floor(80 + 175 * wave);
        } else {
            this._menuCursorSprite.opacity = 255;
        }
    };

    Scene_SimpleImageMenu.prototype.update = function() {
        Scene_MenuBase.prototype.update.call(this);

        this._menuCursorAnimCount++;
        this._menuCursorBlinkCount++;
        this.updateMenuCursorSprite(false);
    };

    Scene_SimpleImageMenu.prototype.onItemOk = function() {
        const item = this._menuWindow.currentItem();
        const commonEventId = item ? Number(item.commonEventId || 0) : 0;

        if (commonEventId > 0) {
            $gameTemp.reserveCommonEvent(commonEventId);
        }

        SimpleImageMenuManager.clear();
        SceneManager.pop();
    };

    Scene_SimpleImageMenu.prototype.onItemCancel = function() {
        const commonEventId = Number(this._config.cancelCommonEventId || 0);

        if (commonEventId > 0) {
            $gameTemp.reserveCommonEvent(commonEventId);
        }

        SoundManager.playCancel();
        SimpleImageMenuManager.clear();
        SceneManager.pop();
    };

})();