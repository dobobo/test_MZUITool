/*:
 * @target MZ
 * @plugindesc メッセージウィンドウ再構築プラグイン v1.1.2
 * @author OpenAI
 *
 * @help
 * 既存のメッセージウィンドウ改造プラグインを、表示系だけに絞って
 * 安全寄りに作り直した版です。
 *
 * 主な機能:
 * ・メッセージウィンドウ背景を img/system の画像に差し替え
 * ・メッセージウィンドウ高さ変更
 * ・本文開始位置変更
 * ・背景画像 / アイコン / 名前ウィンドウの座標変更
 * ・メッセージログウィンドウ
 * ・AUTO / SKIP / LOG ボタン
 * ・名前ウィンドウの枠/背景を非表示
 * ・透明背景時の背景画像非表示対応
 * ・改ページ待機アイコン（3コマアニメーション）
 * ・AUTO / SKIP / LOG アイコンは非表示
 *
 * このプラグインは以下を意図的に入れていません。
 * ・セーブ/ロード中のメッセージ状態復元
 * ・インタープリタ index の強制巻き戻し
 * ・Scene_Map の全面上書き
 * ・WindowLayer の render 差し替え
 *
 * 画像:
 *  背景画像やアイコン画像は img/system に置いてください。
 *  アイコン画像名を空欄にした場合は簡易テキストボタンを描画します。
 *
 * 使い方:
 *  1. プラグインパラメータで初期値を設定
 *  2. 必要ならプラグインコマンドで途中変更
 *  3. ApplyMessageWindowConfig で即時反映可能
 *
 * @command SetMessageWindowBackground
 * @text メッセージ背景画像変更
 * @desc メッセージウィンドウの背景画像（img/system）を変更します。空欄で非表示になります。
 *
 * @arg fileName
 * @text ファイル名
 * @desc img/system/ のファイル名（拡張子なし）。空欄で非表示。
 * @type string
 * @default custom_window
 *
 * @arg visible
 * @text 表示する
 * @desc 背景画像を表示するか。
 * @type boolean
 * @default true
 *
 * @command SetMessageWindowHeight
 * @text メッセージウィンドウ高さ変更
 * @desc メッセージウィンドウの高さを変更します。
 *
 * @arg height
 * @text 高さ
 * @type number
 * @min 1
 * @default 300
 *
 * @command SetMessageTextOffset
 * @text テキスト開始位置変更
 * @desc メッセージ本文の開始座標を変更します。
 *
 * @arg startX
 * @text 開始X
 * @type number
 * @default 290
 *
 * @arg startY
 * @text 開始Y
 * @type number
 * @default 92
 *
 * @command SetMessageWindowBgPos
 * @text 背景画像座標変更
 * @desc メッセージ背景画像のX/Y座標を変更します。
 *
 * @arg x
 * @text X
 * @type number
 * @default 50
 *
 * @arg y
 * @text Y
 * @type number
 * @default 0
 *
 * @command SetMessageWindowIconPos
 * @text アイコン基準座標変更
 * @desc アイコン群の基準X/Y座標を変更します。
 *
 * @arg x
 * @text X
 * @type number
 * @default 542
 *
 * @arg y
 * @text Y
 * @type number
 * @default 215
 *
 * @command SetNameWindowPos
 * @text 名前ウィンドウ座標変更
 * @desc 名前ウィンドウのX/Y座標を変更します。
 *
 * @arg x
 * @text X
 * @type number
 * @default 0
 *
 * @arg y
 * @text Y
 * @type number
 * @default 0
 *
 * @command SetWindowOffsetY
 * @text メッセージウィンドウY補正変更
 * @desc メッセージウィンドウの縦位置補正値を変更します。
 *
 * @arg offsetY
 * @text Y補正
 * @type number
 * @default 41
 *
 * @command ApplyMessageWindowConfig
 * @text 設定を即時反映
 * @desc 現在表示中のメッセージウィンドウに設定を即時反映します。
 *
 * @command SetPageWaitIcon
 * @text 改ページ待機アイコン変更
 * @desc 改ページ待機中に表示するアイコン画像（img/system）と表示状態を変更します。
 *        画像は横72x縦24（24x24を3コマ）を想定しています。
 *
 * @arg fileName
 * @text ファイル名
 * @desc img/system/ のファイル名（拡張子なし）。空欄なら画像指定なし。
 * @type string
 * @default
 *
 * @arg visible
 * @text 表示する
 * @desc 改ページ待機アイコンを表示するか。
 * @type boolean
 * @default true
 *
 * @command HidePageWaitIcon
 * @text 改ページ待機アイコン非表示
 * @desc 改ページ待機アイコンを非表示にします。
 *
 * @command SetPageWaitIconPos
 * @text 改ページ待機アイコン座標変更
 * @desc 改ページ待機アイコンのX/Y座標を変更します。
 *
 * @arg x
 * @text X
 * @type number
 * @min -9999
 * @max 9999 
 * @default -42
 *
 * @arg y
 * @text Y
 * @type number
 * @max 9999 
 * @min -9999 
 * @default -42
 *
 * @command ResetMessageWindowConfig
 * @text 設定リセット
 * @desc 変更した設定を初期値に戻し、現在のメッセージウィンドウにも反映します。
 *
 * @param backgroundFile
 * @text 背景画像ファイル
 * @desc img/system/ の背景画像ファイル名（拡張子なし）
 * @type string
 * @default custom_window
 *
 * @param backgroundVisible
 * @text 背景画像を表示
 * @desc 初期状態で背景画像を表示するか。
 * @type boolean
 * @default true
 *
 * @param backSpriteOffSwitch
 * @text 背景画像消去スイッチ
 * @desc このスイッチがONの間だけ背景画像を非表示にします。0で無効。
 * @type switch
 * @default 0
 *
 * @param messageWindowHeight
 * @text メッセージウィンドウ高さ
 * @type number
 * @min 1
 * @default 300
 *
 * @param windowOffsetY
 * @text メッセージウィンドウY補正
 * @desc 上中下の位置計算後に加算するY補正値です。
 * @type number
 * @default 41
 *
 * @param textStartX
 * @text 本文開始X
 * @type number
 * @default 290
 *
 * @param textStartY
 * @text 本文開始Y
 * @type number
 * @default 92
 *
 * @param bgX
 * @text 背景画像X
 * @type number
 * @default 50
 *
 * @param bgY
 * @text 背景画像Y
 * @type number
 * @default 0
 *
 * @param iconBaseX
 * @text アイコン基準X
 * @type number
 * @default 542
 *
 * @param iconBaseY
 * @text アイコン基準Y
 * @type number
 * @default 215
 *
 * @param iconWidth
 * @text アイコン幅
 * @type number
 * @min 1
 * @default 70
 *
 * @param iconHeight
 * @text アイコン高さ
 * @type number
 * @min 1
 * @default 70
 *
 * @param iconSpacing
 * @text アイコン間隔
 * @type number
 * @default 20
 *
 * @param iconMenuImage
 * @text LOGアイコン画像
 * @desc img/system/ のファイル名。空欄ならテキストボタン。
 * @type string
 * @default icon_menu
 *
 * @param iconAutoOffImage
 * @text AUTO通常画像
 * @desc img/system/ のファイル名。空欄ならテキストボタン。
 * @type string
 * @default icon_auto
 *
 * @param iconAutoOnImage
 * @text AUTO有効画像
 * @desc img/system/ のファイル名。空欄ならテキストボタン。
 * @type string
 * @default icon_auto2
 *
 * @param iconSkipOffImage
 * @text SKIP通常画像
 * @desc img/system/ のファイル名。空欄ならテキストボタン。
 * @type string
 * @default icon_skip
 *
 * @param iconSkipOnImage
 * @text SKIP有効画像
 * @desc img/system/ のファイル名。空欄ならテキストボタン。
 * @type string
 * @default icon_skip2
 *
 * @param nameWindowX
 * @text 名前ウィンドウX
 * @type number
 * @default 0
 *
 * @param nameWindowY
 * @text 名前ウィンドウY
 * @type number
 * @default 0
 *
 * @param autoAdvanceFrames
 * @text AUTO待機フレーム
 * @desc AUTO時にポーズ解除するまでの待機フレームです。
 * @type number
 * @min 1
 * @default 120
 *
 * @param useLogWindow
 * @text ログウィンドウを使う
 * @type boolean
 * @default true
 *
 * @param logToggleKey
 * @text ログ切替キー
 * @desc 1文字の英字。例: L
 * @type string
 * @default L
 *
 * @param pageWaitIconFile
 * @text 改ページ待機アイコン画像
 * @desc img/system/ のファイル名。横72x縦24（24x24を3コマ）を想定。空欄で非表示。
 * @type string
 * @default
 *
 * @param pageWaitIconVisible
 * @text 改ページ待機アイコン表示
 * @desc 初期状態で改ページ待機アイコンを表示するか。
 * @type boolean
 * @default true
 *
 * @param pageWaitIconX
 * @text 改ページ待機アイコンX
 * @desc 改ページ待機アイコンの表示X座標です。負数なら右端基準の相対値として扱います。
 * @type number
 * @max 9999 
 * @min -9999  
 * @default -42
 *
 * @param pageWaitIconY
 * @text 改ページ待機アイコンY
 * @desc 改ページ待機アイコンの表示Y座標です。負数なら下端基準の相対値として扱います。
 * @type number
 * @max 9999 
 * @min -9999  
 * @default -42
 */

(() => {
    "use strict";

    const script = document.currentScript;
    const pluginName = (script && script.src)
        ? script.src.split("/").pop().replace(/\.js$/i, "")
        : "DB_MessageWindowRebuild";
    const params = PluginManager.parameters(pluginName);

    const toNumber = (value, defaultValue) => {
        if (value === undefined || value === null || value === "") return defaultValue;
        const n = Number(value);
        return Number.isFinite(n) ? n : defaultValue;
    };
    const toBoolean = (value, defaultValue) => {
        if (value === undefined || value === null || value === "") return defaultValue;
        if (typeof value === "boolean") return value;
        return String(value).toLowerCase() === "true";
    };
    const toStringValue = (value, defaultValue) => {
        if (value === undefined || value === null) return defaultValue;
        return String(value);
    };
    const clamp = (value, min, max) => Math.max(min, Math.min(max, value));

    const DEFAULT_CONFIG = {
        backgroundFile: toStringValue(params.backgroundFile, "custom_window"),
        backgroundVisible: toBoolean(params.backgroundVisible, true),
        backSpriteOffSwitch: toNumber(params.backSpriteOffSwitch, 0),
        height: toNumber(params.messageWindowHeight, 300),
        windowOffsetY: toNumber(params.windowOffsetY, 41),
        textStartX: toNumber(params.textStartX, 290),
        textStartY: toNumber(params.textStartY, 92),
        bgX: toNumber(params.bgX, 50),
        bgY: toNumber(params.bgY, 0),
        iconBaseX: toNumber(params.iconBaseX, 542),
        iconBaseY: toNumber(params.iconBaseY, 215),
        iconWidth: toNumber(params.iconWidth, toNumber(params.iconSize, 70)),
        iconHeight: toNumber(params.iconHeight, toNumber(params.iconSize, 70)),
        iconSpacing: toNumber(params.iconSpacing, 20),
        iconMenuImage: toStringValue(params.iconMenuImage, "icon_menu"),
        iconAutoOffImage: toStringValue(params.iconAutoOffImage, "icon_auto"),
        iconAutoOnImage: toStringValue(params.iconAutoOnImage, "icon_auto2"),
        iconSkipOffImage: toStringValue(params.iconSkipOffImage, "icon_skip"),
        iconSkipOnImage: toStringValue(params.iconSkipOnImage, "icon_skip2"),
        nameWindowX: toNumber(params.nameWindowX, 0),
        nameWindowY: toNumber(params.nameWindowY, 0),
        autoAdvanceFrames: Math.max(1, toNumber(params.autoAdvanceFrames, 120)),
        useLogWindow: toBoolean(params.useLogWindow, true),
        logToggleKey: (toStringValue(params.logToggleKey, "L") || "L").charAt(0).toUpperCase(),
        pageWaitIconFile: toStringValue(params.pageWaitIconFile, ""),
        pageWaitIconVisible: toBoolean(params.pageWaitIconVisible, true),
        pageWaitIconX: toNumber(params.pageWaitIconX, -42),
        pageWaitIconY: toNumber(params.pageWaitIconY, -42)
    };

    function getConfig() {
        if (!$gameSystem) {
            return Object.assign({}, DEFAULT_CONFIG);
        }
        if (!$gameSystem._dbMessageWindowRebuildConfig) {
            $gameSystem._dbMessageWindowRebuildConfig = Object.assign({}, DEFAULT_CONFIG);
        }
        return $gameSystem._dbMessageWindowRebuildConfig;
    }

    Game_System.prototype.dbMessageWindowRebuildConfig = function() {
        return getConfig();
    };

    Game_System.prototype.resetDbMessageWindowRebuildConfig = function() {
        this._dbMessageWindowRebuildConfig = Object.assign({}, DEFAULT_CONFIG);
    };

    const MESSAGE_LOG = [];

    function isBackgroundHiddenBySwitch() {
        const cfg = getConfig();
        const switchId = toNumber(cfg.backSpriteOffSwitch, 0);
        return switchId > 0 && $gameSwitches && $gameSwitches.value(switchId);
    }

    function currentSceneMessageWindow() {
        const scene = SceneManager._scene;
        return scene && scene._messageWindow ? scene._messageWindow : null;
    }

    function currentSceneHasInputWindow() {
        const scene = SceneManager._scene;
        if (!scene) return false;
        return !!(
            (scene._choiceListWindow && scene._choiceListWindow.active) ||
            (scene._numberInputWindow && scene._numberInputWindow.active) ||
            (scene._eventItemWindow && scene._eventItemWindow.active)
        );
    }

    function drawFallbackButton(bitmap, label, onState) {
        const w = bitmap.width;
        const h = bitmap.height;
        bitmap.clear();
        bitmap.fillRect(0, 0, w, h, onState ? "rgba(255,255,255,0.28)" : "rgba(255,255,255,0.14)");
        bitmap.strokeRect(0, 0, w, h, "rgba(255,255,255,0.75)");
        bitmap.fontFace = $gameSystem ? $gameSystem.mainFontFace() : "GameFont";
        bitmap.fontSize = Math.max(16, Math.floor(h * 0.28));
        bitmap.textColor = "#ffffff";
        bitmap.outlineColor = "rgba(0,0,0,0.8)";
        bitmap.outlineWidth = 4;
        bitmap.drawText(label, 0, Math.floor((h - bitmap.fontSize) / 2) - 2, w, h, "center");
    }

    class DB_MessageIconSprite extends Sprite {
        initialize(width, height) {
            Sprite.prototype.initialize.call(this);
            this.bitmap = new Bitmap(width, height);
            this._iconWidth = width;
            this._iconHeight = height;
        }

        isTouchInFrame() {
            if (!this.visible || this.opacity <= 0) return false;
            const x = this.canvasToLocalX(TouchInput.x);
            const y = this.canvasToLocalY(TouchInput.y);
            return x >= 0 && y >= 0 && x < this.width && y < this.height;
        }

        canvasToLocalX(x) {
            let node = this;
            while (node) {
                x -= node.x;
                node = node.parent;
            }
            return x;
        }

        canvasToLocalY(y) {
            let node = this;
            while (node) {
                y -= node.y;
                node = node.parent;
            }
            return y;
        }
    }

    function refreshIconSprite(sprite, imageName, label, onState) {
        const width = sprite._iconWidth || sprite.width || 70;
        const height = sprite._iconHeight || sprite.height || 70;
        if (!sprite.bitmap || sprite.bitmap.width !== width || sprite.bitmap.height !== height) {
            sprite.bitmap = new Bitmap(width, height);
        }
        if (imageName && imageName.trim()) {
            const source = ImageManager.loadSystem(imageName.trim());
            sprite.bitmap.clear();
            source.addLoadListener(() => {
                sprite.bitmap.clear();
                if (source.width > 0 && source.height > 0) {
                    sprite.bitmap.blt(source, 0, 0, source.width, source.height, 0, 0, width, height);
                } else {
                    drawFallbackButton(sprite.bitmap, label, onState);
                }
            });
        } else {
            drawFallbackButton(sprite.bitmap, label, onState);
        }
    }

    function refreshPageWaitIconSprite(sprite, imageName) {
        const fileName = String(imageName || "").trim();
        if (!sprite) return;
        if (fileName) {
            if (sprite._dbSourceName !== fileName) {
                sprite.bitmap = ImageManager.loadSystem(fileName);
                sprite._dbSourceName = fileName;
            }
        } else {
            if (!sprite.bitmap || sprite.bitmap.width !== 1 || sprite.bitmap.height !== 1) {
                sprite.bitmap = new Bitmap(1, 1);
            }
            sprite._dbSourceName = "";
        }
    }

    function applyWindowRuntimeConfig(win) {
        if (!win) return;
        const cfg = getConfig();
        const width = Graphics.boxWidth;
        const height = Math.max(1, Number(cfg.height || DEFAULT_CONFIG.height));
        if (win.width !== width || win.height !== height) {
            win.move(0, win.y, width, height);
            win.createContents();
        }
        if (win._customBackground) {
            win._customBackground.x = Number(cfg.bgX || 0);
            win._customBackground.y = Number(cfg.bgY || 0);
            win._customBackground.width = win.width;
            win._customBackground.height = win.height;
        }
        if (typeof win.updatePlacement === "function") {
            win.updatePlacement();
        }
        if (typeof win.dbUpdateIconLayout === "function") {
            win.dbUpdateIconLayout();
        }
        if (win._nameBoxWindow && typeof win._nameBoxWindow.updatePlacement === "function") {
            win._nameBoxWindow.updatePlacement();
        }
        if (SceneManager._scene) {
            const scene = SceneManager._scene;
            if (scene._choiceListWindow && scene._choiceListWindow.visible) {
                scene._choiceListWindow.updatePlacement();
            }
            if (scene._numberInputWindow && scene._numberInputWindow.visible) {
                scene._numberInputWindow.updatePlacement();
            }
            if (scene._eventItemWindow && scene._eventItemWindow.visible) {
                scene._eventItemWindow.updatePlacement();
            }
        }
    }

    function syncCustomBackground(win) {
        if (!win || !win._customBackground) return;
        const cfg = getConfig();
        const fileName = String(cfg.backgroundFile || "").trim();
        const visible = !!cfg.backgroundVisible && !isBackgroundHiddenBySwitch() && fileName !== "" && win._background !== 2;
        win._customBackground.visible = visible;
        if (visible) {
            if (win._customBackground._dbSourceName !== fileName) {
                win._customBackground.bitmap = ImageManager.loadSystem(fileName);
                win._customBackground._dbSourceName = fileName;
            }
        } else {
            if (!win._customBackground.bitmap || win._customBackground.bitmap.width !== 1 || win._customBackground.bitmap.height !== 1) {
                win._customBackground.bitmap = new Bitmap(1, 1);
            }
            win._customBackground._dbSourceName = "";
        }
        win._customBackground.x = Number(cfg.bgX || 0);
        win._customBackground.y = Number(cfg.bgY || 0);
        win._customBackground.opacity = visible ? win.openness : 0;
    }

    function syncNameBoxAppearance(nameBox) {
        if (!nameBox) return;
        if (nameBox._backSprite) nameBox._backSprite.visible = false;
        if (nameBox._frameSprite) nameBox._frameSprite.visible = false;
        nameBox.opacity = 0;
        nameBox.backOpacity = 0;
    }

    const keyCode = DEFAULT_CONFIG.logToggleKey.charCodeAt(0);
    if (keyCode >= 65 && keyCode <= 90) {
        Input.keyMapper[keyCode] = DEFAULT_CONFIG.logToggleKey;
    }

    const _Window_Message_initialize = Window_Message.prototype.initialize;
    Window_Message.prototype.initialize = function(rect) {
        const cfg = getConfig();
        // MPP_ChoiceEX などが base initialize 中に updatePlacement を呼ぶため、
        // 先に最低限の入れ物だけ作っておく。
        this._dbIconSprites = this._dbIconSprites || {};
        this._dbAutoMode = false;
        this._dbSkipMode = false;
        this._dbAutoTimer = Math.max(1, Number(cfg.autoAdvanceFrames || DEFAULT_CONFIG.autoAdvanceFrames));
        const newRect = new Rectangle(0, 0, Graphics.boxWidth, Math.max(1, Number(cfg.height || DEFAULT_CONFIG.height)));
        _Window_Message_initialize.call(this, newRect);
        this.dbInitCustomElements();
        this.dbRefreshAllVisuals();
    };

    Window_Message.prototype.dbInitCustomElements = function() {
        if (!this._customBackground) {
            this._customBackground = new Sprite();
            this.addChildToBack(this._customBackground);
        }
        if (typeof this._dbAutoMode !== "boolean") this._dbAutoMode = false;
        if (typeof this._dbSkipMode !== "boolean") this._dbSkipMode = false;
        this._dbAutoTimer = Math.max(1, Number(getConfig().autoAdvanceFrames || DEFAULT_CONFIG.autoAdvanceFrames));
        this._dbIconSprites = this._dbIconSprites || {};
        this.dbCreateIconSprites();
        this.dbCreatePageWaitIconSprite();
    };

    Window_Message.prototype.dbCreateIconSprites = function() {
        if (this._dbIconSprites.log) return;
        const cfg = getConfig();
        const iconWidth = Math.max(1, Number(cfg.iconWidth || DEFAULT_CONFIG.iconWidth));
        const iconHeight = Math.max(1, Number(cfg.iconHeight || DEFAULT_CONFIG.iconHeight));
        this._dbIconSprites.log = new DB_MessageIconSprite(iconWidth, iconHeight);
        this._dbIconSprites.auto = new DB_MessageIconSprite(iconWidth, iconHeight);
        this._dbIconSprites.skip = new DB_MessageIconSprite(iconWidth, iconHeight);
        this._iconAutoSprite = this._dbIconSprites.auto;
        this._iconSkipSprite = this._dbIconSprites.skip;
        this.addChild(this._dbIconSprites.log);
        this.addChild(this._dbIconSprites.auto);
        this.addChild(this._dbIconSprites.skip);
        this.dbRefreshAllIconBitmaps();
        this.dbUpdateIconLayout();
    };

    Window_Message.prototype.dbCreatePageWaitIconSprite = function() {
        if (this._dbPageWaitIconSprite) return;
        this._dbPageWaitIconSprite = new Sprite();
        this._dbPageWaitIconSprite.visible = false;
        this._dbPageWaitIconSprite._dbSourceName = "";
        this.addChild(this._dbPageWaitIconSprite);
        this.dbRefreshPageWaitIconBitmap();
        this.dbUpdatePageWaitIconPosition();
    };

    Window_Message.prototype.dbRefreshPageWaitIconBitmap = function() {
        if (!this._dbPageWaitIconSprite) return;
        const cfg = getConfig();
        refreshPageWaitIconSprite(this._dbPageWaitIconSprite, cfg.pageWaitIconFile);
    };

    Window_Message.prototype.dbUpdatePageWaitIconPosition = function() {
        if (!this._dbPageWaitIconSprite) return;
        const cfg = getConfig();
        const frameSize = 24;
        const rawX = Number(cfg.pageWaitIconX ?? -42);
        const rawY = Number(cfg.pageWaitIconY ?? -42);
        const resolvedX = rawX < 0 ? this.width + rawX - frameSize : rawX;
        const resolvedY = rawY < 0 ? this.height + rawY - frameSize : rawY;
        this._dbPageWaitIconSprite.x = Math.max(0, resolvedX);
        this._dbPageWaitIconSprite.y = Math.max(0, resolvedY);
    };

    Window_Message.prototype.dbUpdatePageWaitIcon = function() {
        if (this._pauseSignSprite) {
            this._pauseSignSprite.visible = false;
            this._pauseSignSprite.alpha = 0;
        }
        if (!this._dbPageWaitIconSprite) return;
        const cfg = getConfig();
        const fileName = String(cfg.pageWaitIconFile || "").trim();
        const enabled = !!cfg.pageWaitIconVisible && fileName !== "";
        if (this._dbPageWaitIconSprite._dbSourceName !== fileName) {
            this.dbRefreshPageWaitIconBitmap();
        }
        this.dbUpdatePageWaitIconPosition();
        const sprite = this._dbPageWaitIconSprite;
        const showing = enabled && this.pause && this.isOpen();
        sprite.visible = showing;
        sprite.opacity = showing ? this.openness : 0;
        if (!showing || !sprite.bitmap) {
            sprite.setFrame(0, 0, 0, 0);
            return;
        }
        const frameWidth = 24;
        const frameHeight = 24;
        const animationWait = 12;
        const frame = Math.floor(Graphics.frameCount / animationWait) % 3;
        sprite.setFrame(frame * frameWidth, 0, frameWidth, frameHeight);
    };

    Window_Message.prototype.dbUsesExternalSkipAuto = function() {
        return !!($gameMessage && (typeof $gameMessage.toggleAuto === "function" || typeof $gameMessage.toggleSkip === "function" || "_autoFlg" in $gameMessage || "_skipFlg" in $gameMessage));
    };

    Window_Message.prototype.dbIsAutoMode = function() {
        if (this.dbUsesExternalSkipAuto()) {
            return !!($gameMessage && $gameMessage._autoFlg);
        }
        return !!this._dbAutoMode;
    };

    Window_Message.prototype.dbIsSkipMode = function() {
        if (this.dbUsesExternalSkipAuto()) {
            return !!($gameMessage && $gameMessage._skipFlg);
        }
        return !!this._dbSkipMode;
    };

    Window_Message.prototype.dbRefreshAllIconBitmaps = function() {
        const cfg = getConfig();
        if (!this._dbIconSprites || !this._dbIconSprites.log) return;
        const autoMode = this.dbIsAutoMode();
        const skipMode = this.dbIsSkipMode();
        refreshIconSprite(this._dbIconSprites.log, cfg.iconMenuImage, "LOG", false);
        refreshIconSprite(
            this._dbIconSprites.auto,
            autoMode ? cfg.iconAutoOnImage : cfg.iconAutoOffImage,
            "AUTO",
            autoMode
        );
        refreshIconSprite(
            this._dbIconSprites.skip,
            skipMode ? cfg.iconSkipOnImage : cfg.iconSkipOffImage,
            "SKIP",
            skipMode
        );
    };

    Window_Message.prototype.dbUpdateIconLayout = function() {
        if (!this._dbIconSprites) return;
        Object.values(this._dbIconSprites).forEach(sprite => {
            if (!sprite) return;
            sprite.visible = false;
            sprite.opacity = 0;
            sprite.x = -9999;
            sprite.y = -9999;
        });
    };

    Window_Message.prototype.dbRefreshAllVisuals = function() {
        this.opacity = 0;
        this.backOpacity = 0;
        if (this._backSprite) this._backSprite.visible = false;
        if (this._frameSprite) this._frameSprite.visible = false;
        this.hideBackgroundDimmer();
        syncCustomBackground(this);
        this.dbRefreshAllIconBitmaps();
        this.dbUpdateIconLayout();
        this.dbRefreshPageWaitIconBitmap();
        this.dbUpdatePageWaitIconPosition();
    };

    const _Window_Message_setBackgroundType = Window_Message.prototype.setBackgroundType;
    Window_Message.prototype.setBackgroundType = function(type) {
        _Window_Message_setBackgroundType.call(this, type);
        this.opacity = 0;
        this.backOpacity = 0;
        if (this._backSprite) this._backSprite.visible = false;
        if (this._frameSprite) this._frameSprite.visible = false;
        this.hideBackgroundDimmer();
    };

    Window_Message.prototype.updatePlacement = function() {
        const goldWindow = this._goldWindow;
        const cfg = getConfig();
        this._positionType = $gameMessage.positionType();
        this.y = (this._positionType * (Graphics.boxHeight - this.height)) / 2 + Number(cfg.windowOffsetY || 0);
        if (goldWindow) {
            goldWindow.y = this.y > 0 ? 0 : Graphics.boxHeight - goldWindow.height;
        }
        this.dbUpdateIconLayout();
    };

    const _Window_Message_newPage = Window_Message.prototype.newPage;
    Window_Message.prototype.newPage = function(textState) {
        _Window_Message_newPage.call(this, textState);
        const cfg = getConfig();
        textState.startX = Number(cfg.textStartX || 0);
        textState.x = Number(cfg.textStartX || 0);
        textState.y = Number(cfg.textStartY || 0);
    };

    const _Window_Message_update = Window_Message.prototype.update;
    Window_Message.prototype.update = function() {
        _Window_Message_update.call(this);
        this.dbRefreshAllVisuals();
        this.dbUpdateAutoAndSkip();
        this.dbSyncIconOpacity();
        this.dbUpdatePageWaitIcon();
    };

    Window_Message.prototype.dbSyncIconOpacity = function() {
        if (!this._dbIconSprites) return;
        Object.values(this._dbIconSprites).forEach(sprite => {
            if (!sprite) return;
            sprite.opacity = 0;
            sprite.visible = false;
        });
    };

    Window_Message.prototype.dbUpdateAutoAndSkip = function() {
        if (currentSceneHasInputWindow()) return;
        if (this.dbUsesExternalSkipAuto()) {
            this.dbRefreshAllIconBitmaps();
            return;
        }
        if (this._dbSkipMode) {
            if (this._textState) {
                this._showFast = true;
                this._lineShowFast = true;
                this.pause = false;
            } else if (this.pause) {
                this.pause = false;
            }
        } else if (this._dbAutoMode) {
            if (this.pause) {
                this._dbAutoTimer -= 1;
                if (this._dbAutoTimer <= 0) {
                    this.pause = false;
                    this._dbAutoTimer = Math.max(1, Number(getConfig().autoAdvanceFrames || DEFAULT_CONFIG.autoAdvanceFrames));
                }
            } else {
                this._dbAutoTimer = Math.max(1, Number(getConfig().autoAdvanceFrames || DEFAULT_CONFIG.autoAdvanceFrames));
            }
        }
    };

    Window_Message.prototype.dbHandleIconTouch = function() {
        return false;
    };

    Window_Message.prototype.dbToggleLogWindow = function() {
        const scene = SceneManager._scene;
        if (scene && typeof scene.toggleDbMessageLogWindow === "function") {
            scene.toggleDbMessageLogWindow();
        }
    };

    Window_Message.prototype.onAutoMessageIconClick = function() {
        if (this.dbUsesExternalSkipAuto()) {
            if ($gameMessage) {
                $gameMessage._skipFlg = false;
                if (typeof $gameMessage.toggleAuto === "function") {
                    $gameMessage.toggleAuto();
                } else {
                    $gameMessage._autoFlg = !$gameMessage._autoFlg;
                }
            }
        } else {
            this._dbAutoMode = !this._dbAutoMode;
            if (this._dbAutoMode) {
                this._dbSkipMode = false;
                this._dbAutoTimer = Math.max(1, Number(getConfig().autoAdvanceFrames || DEFAULT_CONFIG.autoAdvanceFrames));
            }
        }
        this.changeAutoIcon(this.dbIsAutoMode());
        this.changeSkipIcon(this.dbIsSkipMode());
    };

    Window_Message.prototype.onSkipMessageIconClick = function() {
        if (this.dbUsesExternalSkipAuto()) {
            if ($gameMessage) {
                $gameMessage._autoFlg = false;
                if (typeof $gameMessage.toggleSkip === "function") {
                    $gameMessage.toggleSkip();
                } else {
                    $gameMessage._skipFlg = !$gameMessage._skipFlg;
                }
            }
        } else {
            this._dbSkipMode = !this._dbSkipMode;
            if (this._dbSkipMode) {
                this._dbAutoMode = false;
            }
        }
        this.changeAutoIcon(this.dbIsAutoMode());
        this.changeSkipIcon(this.dbIsSkipMode());
    };

    Window_Message.prototype.changeAutoIcon = function(isAuto) {
        if (!this.dbUsesExternalSkipAuto() && typeof isAuto === "boolean") {
            this._dbAutoMode = isAuto;
            if (isAuto) this._dbSkipMode = false;
        }
        this.dbRefreshAllIconBitmaps();
    };

    Window_Message.prototype.changeSkipIcon = function(isSkip) {
        if (!this.dbUsesExternalSkipAuto() && typeof isSkip === "boolean") {
            this._dbSkipMode = isSkip;
            if (isSkip) this._dbAutoMode = false;
        }
        this.dbRefreshAllIconBitmaps();
    };

    Window_Message.prototype.isCustomSkipIconPressed = function() {
        return false;
    };

    const _Window_Message_updateInput = Window_Message.prototype.updateInput;
    Window_Message.prototype.updateInput = function() {
        if (this.dbHandleIconTouch()) {
            return true;
        }
        if (TouchInput.isTriggered()) {
            if (this.dbUsesExternalSkipAuto()) {
                if ($gameMessage && ($gameMessage._autoFlg || $gameMessage._skipFlg)) {
                    $gameMessage._autoFlg = false;
                    $gameMessage._skipFlg = false;
                    this.dbRefreshAllIconBitmaps();
                }
            } else if (this._dbAutoMode || this._dbSkipMode) {
                this._dbAutoMode = false;
                this._dbSkipMode = false;
                this.dbRefreshAllIconBitmaps();
            }
        }
        return _Window_Message_updateInput.call(this);
    };

    const _Window_Message_terminateMessage = Window_Message.prototype.terminateMessage;
    Window_Message.prototype.terminateMessage = function() {
        const text = $gameMessage ? $gameMessage.allText() : "";
        if (text) {
            MESSAGE_LOG.push(this.convertEscapeCharacters(text));
        }
        _Window_Message_terminateMessage.call(this);
    };

    const _Window_NameBox_updatePlacement = Window_NameBox.prototype.updatePlacement;
    Window_NameBox.prototype.updatePlacement = function() {
        _Window_NameBox_updatePlacement.call(this);
        const cfg = getConfig();
        this.x = Number(cfg.nameWindowX || 0);
        this.y = Number(cfg.nameWindowY || 0);
        syncNameBoxAppearance(this);
    };

    const _Window_NameBox_update = Window_NameBox.prototype.update;
    Window_NameBox.prototype.update = function() {
        _Window_NameBox_update.call(this);
        syncNameBoxAppearance(this);
    };

    class Window_DBMessageLog extends Window_Base {
        initialize(rect) {
            super.initialize(rect);
            this._scrollY = 0;
            this._maxScrollY = 0;
            this._wheelHandler = this.onWheel.bind(this);
            this.refresh();
        }

        show() {
            super.show();
            window.addEventListener("wheel", this._wheelHandler, { passive: true });
        }

        hide() {
            super.hide();
            window.removeEventListener("wheel", this._wheelHandler);
        }

        onWheel(event) {
            if (!this.visible || !this.active) return;
            if (event.deltaY < 0) {
                this.scrollUp();
            } else if (event.deltaY > 0) {
                this.scrollDown();
            }
        }

        refresh() {
            this.contents.clear();
            let y = -this._scrollY;
            let totalHeight = 0;
            for (const log of MESSAGE_LOG) {
                this.drawTextEx(log, 0, y, this.contentsWidth());
                const lineCount = String(log).split("\n").length;
                const logHeight = this.lineHeight() * (lineCount + 1);
                y += logHeight;
                totalHeight += logHeight;
            }
            this._maxScrollY = Math.max(0, totalHeight - this.contentsHeight());
        }

        update() {
            super.update();
            if (!this.visible || !this.active) return;
            if (Input.isRepeated("up")) {
                this.scrollUp();
            }
            if (Input.isRepeated("down")) {
                this.scrollDown();
            }
        }

        scrollUp() {
            this._scrollY = Math.max(0, this._scrollY - this.lineHeight());
            this.refresh();
        }

        scrollDown() {
            this._scrollY = Math.min(this._maxScrollY, this._scrollY + this.lineHeight());
            this.refresh();
        }
    }

    Scene_Message.prototype.dbMessageLogWindowRect = function() {
        const ww = Graphics.boxWidth;
        const wh = Math.floor(Graphics.boxHeight / 2);
        const wx = 0;
        const wy = Graphics.boxHeight - wh;
        return new Rectangle(wx, wy, ww, wh);
    };

    Scene_Message.prototype.createDbMessageLogWindow = function() {
        if (!getConfig().useLogWindow) return;
        this._dbMessageLogWindow = new Window_DBMessageLog(this.dbMessageLogWindowRect());
        this._dbMessageLogWindow.hide();
        this._dbMessageLogWindow.deactivate();
        this.addWindow(this._dbMessageLogWindow);
    };

    Scene_Message.prototype.toggleDbMessageLogWindow = function() {
        if (!this._dbMessageLogWindow) return;
        if (this._dbMessageLogWindow.visible) {
            this._dbMessageLogWindow.hide();
            this._dbMessageLogWindow.deactivate();
        } else {
            this._dbMessageLogWindow.refresh();
            this._dbMessageLogWindow.show();
            this._dbMessageLogWindow.activate();
        }
    };

    const _Scene_Message_createAllWindows = Scene_Message.prototype.createAllWindows;
    Scene_Message.prototype.createAllWindows = function() {
        _Scene_Message_createAllWindows.call(this);
        this.createDbMessageLogWindow();
    };

    function updateLogToggle(scene) {
        if (!scene || !scene._dbMessageLogWindow || !getConfig().useLogWindow) return;
        const key = (getConfig().logToggleKey || DEFAULT_CONFIG.logToggleKey || "L").charAt(0).toUpperCase();
        if (key.length === 1) {
            const code = key.charCodeAt(0);
            if (code >= 65 && code <= 90) {
                Input.keyMapper[code] = key;
                if (Input.isTriggered(key)) {
                    scene.toggleDbMessageLogWindow();
                }
            }
        }
    }

    const _Scene_Map_update = Scene_Map.prototype.update;
    Scene_Map.prototype.update = function() {
        _Scene_Map_update.call(this);
        updateLogToggle(this);
    };

    const _Scene_Battle_update = Scene_Battle.prototype.update;
    Scene_Battle.prototype.update = function() {
        _Scene_Battle_update.call(this);
        updateLogToggle(this);
    };

    Window_ChoiceList.prototype.updatePlacement = function() {
        const messageWindow = this._messageWindow;
        if (!messageWindow) return;

        const positionType = $gameMessage.choicePositionType();
        this.width = this.windowWidth();
        this.height = this.windowHeight();

        switch (positionType) {
            case 0:
                this.x = 0;
                break;
            case 1:
                this.x = Math.floor((Graphics.boxWidth - this.width) / 2);
                break;
            case 2:
                this.x = Graphics.boxWidth - this.width;
                break;
        }

        const aboveY = messageWindow.y - this.height;
        const belowY = messageWindow.y + messageWindow.height;
        if (messageWindow.y >= Graphics.boxHeight / 2) {
            this.y = aboveY;
            if (this.y < 0) this.y = belowY;
        } else {
            this.y = belowY;
            if (this.y + this.height > Graphics.boxHeight) this.y = aboveY;
        }

        this.x = clamp(this.x, 0, Graphics.boxWidth - this.width);
        this.y = clamp(this.y, 0, Graphics.boxHeight - this.height);
    };

    const _Window_NumberInput_updatePlacement = Window_NumberInput.prototype.updatePlacement;
    Window_NumberInput.prototype.updatePlacement = function() {
        _Window_NumberInput_updatePlacement.call(this);
        this.y = clamp(this.y, 0, Graphics.boxHeight - this.height);
    };

    const _Window_EventItem_updatePlacement = Window_EventItem.prototype.updatePlacement;
    Window_EventItem.prototype.updatePlacement = function() {
        _Window_EventItem_updatePlacement.call(this);
        this.y = clamp(this.y, 0, Graphics.boxHeight - this.height);
    };

    function applyNow() {
        const win = currentSceneMessageWindow();
        if (win) {
            applyWindowRuntimeConfig(win);
            win.dbRefreshAllVisuals();
        }
    }

    PluginManager.registerCommand(pluginName, "SetMessageWindowBackground", args => {
        const cfg = getConfig();
        cfg.backgroundFile = String(args.fileName || "").trim();
        cfg.backgroundVisible = toBoolean(args.visible, true);
        applyNow();
    });

    PluginManager.registerCommand(pluginName, "SetMessageWindowHeight", args => {
        const cfg = getConfig();
        cfg.height = Math.max(1, Number(args.height || DEFAULT_CONFIG.height));
        applyNow();
    });

    PluginManager.registerCommand(pluginName, "SetMessageTextOffset", args => {
        const cfg = getConfig();
        cfg.textStartX = Number(args.startX || DEFAULT_CONFIG.textStartX);
        cfg.textStartY = Number(args.startY || DEFAULT_CONFIG.textStartY);
        applyNow();
    });

    PluginManager.registerCommand(pluginName, "SetMessageWindowBgPos", args => {
        const cfg = getConfig();
        cfg.bgX = Number(args.x || 0);
        cfg.bgY = Number(args.y || 0);
        applyNow();
    });

    PluginManager.registerCommand(pluginName, "SetMessageWindowIconPos", args => {
        const cfg = getConfig();
        cfg.iconBaseX = Number(args.x || 0);
        cfg.iconBaseY = Number(args.y || 0);
        applyNow();
    });

    PluginManager.registerCommand(pluginName, "SetNameWindowPos", args => {
        const cfg = getConfig();
        cfg.nameWindowX = Number(args.x || 0);
        cfg.nameWindowY = Number(args.y || 0);
        applyNow();
    });

    PluginManager.registerCommand(pluginName, "SetWindowOffsetY", args => {
        const cfg = getConfig();
        cfg.windowOffsetY = Number(args.offsetY || 0);
        applyNow();
    });

    PluginManager.registerCommand(pluginName, "SetPageWaitIcon", args => {
        const cfg = getConfig();
        cfg.pageWaitIconFile = String(args.fileName || "").trim();
        cfg.pageWaitIconVisible = toBoolean(args.visible, true);
        applyNow();
    });

    PluginManager.registerCommand(pluginName, "HidePageWaitIcon", () => {
        const cfg = getConfig();
        cfg.pageWaitIconVisible = false;
        applyNow();
    });

    PluginManager.registerCommand(pluginName, "SetPageWaitIconPos", args => {
        const cfg = getConfig();
        cfg.pageWaitIconX = Number(args.x || 0);
        cfg.pageWaitIconY = Number(args.y || 0);
        applyNow();
    });

    PluginManager.registerCommand(pluginName, "ApplyMessageWindowConfig", () => {
        applyNow();
    });

    PluginManager.registerCommand(pluginName, "ResetMessageWindowConfig", () => {
        if ($gameSystem) {
            $gameSystem.resetDbMessageWindowRebuildConfig();
        }
        applyNow();
    });
})();
