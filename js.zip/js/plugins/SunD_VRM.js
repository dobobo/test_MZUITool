//=============================================================================
// RPG Maker MZ - SunD_VRM
//=============================================================================

/*:
 * @target MZ
 * @plugindesc VRMモデル表示
 * @author MUMAMOMEMU
 * @url https://mumamomemu.booth.pm/
 * @base PluginCommonBase
 * @orderAfter PluginCommonBase
 *
 * @help SunD_VRM.js(ver1.0.1)
 *
 * SunD_VRM_MOD.jsと同じフォルダに配置してください。
 *
 * ■外部設定JSON
 * プラグインパラメータ「外部設定JSON」に JSON ファイルを指定すると、
 * VRMリスト、VRMAリスト、ポジション、向き、カメラ、表情エイリアスを
 * プラグイン本体とは別ファイルで管理できます。
 * v0.1.64以降のCommand Toolでは、ツールで保存した登録情報はこの外部JSONへ集約し、
 * イベントコマンド側では登録済みキーだけを参照する運用を推奨します。
 *
 * v0.1.76以降の修正：
 * 表情変更コマンドで指定した表情は、以後のモーション変更・モーション再生中も維持されます。
 * VRMA側に表情トラックが含まれていても、手動指定表情を毎フレーム再適用します。
 *
 * 例:
 * js/plugins/SunD_VRM_Config/SunD_VRM_Config.json
 *
 * 外部設定はプラグインパラメータの後に読み込まれます。
 * 同じキーがある場合は外部設定側で上書きされます。
 *
 * --------------------------
 * ■利用規約
 *
 * Copyright (c) 2024 MUMAMOMEMU
 * https://star-write-dream.com/
 *
 * 以下に定める条件に従い、本プラグインファイル（以下「ソフトウェア」）の
 * 購入者に対し、ソフトウェアを変更し、
 * 購入者の制作する作品（以下、制作物）に組み込むことを許可します。
 * 制作物の内容および公開形式に制約はありません。
 *
 * ソフトウェア単体で掲載、頒布、共有することはできません。
 * 上記の著作権表示および本許諾表示は変更できず、削除もできません。
 * 別途、制作物の重要な箇所にソフトウェアの著作権表示をする必要はありません。
 *
 * ソフトウェアは「現状のまま」で、明示であるか暗黙であるかを問わず、
 * 何らの保証もなく提供されます。ここでいう保証とは、商品性、
 * 特定の目的への適合性、および権利非侵害についての保証も含みますが、
 * それに限定されるものではありません。作者または著作権者は、契約行為、
 * 不法行為、またはそれ以外であろうと、ソフトウェアに起因または関連し、
 * あるいはソフトウェアの使用またはその他の扱いによって生じる一切の請求、
 * 損害、その他の義務について何らの責任も負わないものとします。
 * --------------------------
 *
 * @param models
 * @type struct<VrmModel>[]
 * @text VRMリスト
 * @desc VRMリストを登録します。
 * @default []
 *
 * @param motions
 * @type struct<Motion>[]
 * @text VRMAリスト
 * @desc VRMAリストを登録します。
 * @default []
 *
 * @param positions
 * @type struct<Position>[]
 * @text ポジションリスト
 * @desc ポジションリストを登録します。
 * @default ["{\"keyName\":\"center\",\"position\":\"0,-0.8,0\"}","{\"keyName\":\"right\",\"position\":\"0.9,-0.8,0\"}","{\"keyName\":\"left\",\"position\":\"-0.9,-0.8,0\"}","{\"keyName\":\"near_center\",\"position\":\"0,-1.3,1.8\"}","{\"keyName\":\"near_right\",\"position\":\"0.4,-1.3,1.8\"}","{\"keyName\":\"near_left\",\"position\":\"-0.4,-1.3,1.8\"}"]
 *
 * @param directions
 * @type struct<ModelRotation>[]
 * @text 向きリスト
 * @desc 向きのリストを登録します。
 * @default ["{\"keyName\":\"default\",\"y\":\"0\"}","{\"keyName\":\"right\",\"y\":\"45\"}","{\"keyName\":\"left\",\"y\":\"-45\"}"]
 *
 * @param cameras
 * @type struct<Camera>[]
 * @text カメラリスト
 * @desc カメラリストを登録します。
 * @default ["{\"keyName\":\"default\",\"position\":\"0,0,3\",\"rotation\":\"0,0,0\"}","{\"keyName\":\"lookDown\",\"position\":\"0.44,1.26,0.49\",\"rotation\":\"-58.75,26.03,35.87\"}"]
 *
 * @param devModeSW
 * @type switch
 * @text 開発モードスイッチ
 * @desc 指定のスイッチがONの間、開発モードとなります。
 * @default 0
 *
 * @param useSave
 * @type boolean
 * @text セーブする
 * @desc ON:表示可能モデルとカメラの情報をセーブします。
 * @default true
 *
 * @param directionalLightIntensity
 * @type string
 * @text 平行光の強さ
 * @desc VRMモデルに当てるDirectionalLightの強さです。大きいほど明るくなります。目安:0.6～1.2
 * @default 0.8
 *
 * @param ambientLightIntensity
 * @type string
 * @text 環境光の強さ
 * @desc 全体を均一に照らすAmbientLightの強さです。影を柔らかくしたい場合に上げます。目安:0.15～0.35
 * @default 0.25
 *
 * @param lightPosition
 * @type string
 * @text 平行光の向き
 * @desc DirectionalLightの位置をx,y,zで指定します。例:1.0,1.0,1.0
 * @default 1.0,1.0,1.0
 *
 * @param externalConfigFile
 * @type string
 * @text 外部設定JSON
 * @desc VRM/VRMA/ポジション/向き/カメラ/表情エイリアスを外部JSONから追加・上書きします。空欄で無効。
 * @default js/plugins/SunD_VRM_Config/SunD_VRM_Config.json
 *
 * @command showVRM
 * @text モデルの表示
 * @desc ロードされているモデルを表示します。
 *
 * @arg modelKey
 * @type string
 * @text モデル
 * @desc 表示したいモデルを指定します。複数指定可
 * @default
 *
 * @command hideVRM
 * @text モデルを隠す
 * @desc モデルを隠します。
 *
 * @arg modelKey
 * @type string
 * @text モデル
 * @desc 隠したいモデルを指定します。複数指定可
 * @default
 *
 * @command setPosition
 * @text 位置変更
 * @desc モデルの位置を変更します。
 *
 * @arg modelKey
 * @type string
 * @text モデル
 * @desc 位置を変更するモデルを指定します。複数指定可
 * @default
 *
 * @arg position
 * @type string
 * @text 位置
 * @desc パラメータで登録したキーを指定します。x,y,zで指定した場合、現行値に加算します。
 * @default
 *
 * @arg frame
 * @type string
 * @text フレーム
 * @desc 指定したフレーム数を使って移動します。
 * @default 1
 *
 * @command registerPosition
 * @text ポジション登録/上書き
 * @desc 実行中にポジションキーを登録または上書きします。Command Toolで作った位置を、外部JSON未適用でもイベント内で確実に使うための補助コマンドです。
 *
 * @arg keyName
 * @type string
 * @text ポジションキー
 * @desc 登録するキー名です。例: naka
 * @default preview_pos
 *
 * @arg position
 * @type string
 * @text 位置
 * @desc x,y,zで指定します。例: 0,-0.8,0
 * @default 0,-0.8,0
 *
 * @command registerDirection
 * @text 向き登録/上書き
 * @desc 実行中に向きキーを登録または上書きします。
 *
 * @arg keyName
 * @type string
 * @text 向きキー
 * @desc 登録するキー名です。例: front
 * @default preview_direction
 *
 * @arg rotationY
 * @type string
 * @text Y回転
 * @desc Y回転を度数で指定します。例: 0
 * @default 0
 *
 * @command registerCamera
 * @text カメラ登録/上書き
 * @desc 実行中にカメラキーを登録または上書きします。
 *
 * @arg keyName
 * @type string
 * @text カメラキー
 * @desc 登録するキー名です。例: closeup
 * @default preview_camera
 *
 * @arg position
 * @type string
 * @text カメラ位置
 * @desc x,y,zで指定します。例: 0,0,3
 * @default 0,0,3
 *
 * @arg rotation
 * @type string
 * @text カメラ回転
 * @desc x,y,zで指定します。単位は度です。例: 0,0,0
 * @default 0,0,0
 *
 * @command setDirection
 * @text 向き変更
 * @desc ロードしたモデルの向きを変更します。
 *
 * @arg modelKey
 * @type string
 * @text モデル
 * @desc 位置を変更するモデルを指定します。複数指定可
 * @default
 *
 * @arg modelRotation
 * @type string
 * @text 向き
 * @desc キーを指定します。-180から180の数値で指定した場合、現在値に加算します。「camera」でカメラを向きます。
 * @default
 *
 * @arg frame
 * @type string
 * @text フレーム
 * @desc 指定したフレーム数を使って移動します。
 * @default 1
 *
 * @command setCamera
 * @text カメラ変更
 * @desc カメラの設定を変更します。
 *
 * @arg cameraKey
 * @type string
 * @text カメラ名
 * @desc カメラのキーを指定します。
 * @default
 *
 * @command moveCamera
 * @text カメラ移動
 * @desc 現在のカメラ位置から、指定した位置・回転へ移動します。
 *
 * @arg cameraKey
 * @type string
 * @text 登録カメラ名
 * @desc パラメータ「カメラリスト」のキーを指定します。空欄の場合は下の位置・回転を直接使用します。
 * @default
 *
 * @arg position
 * @type string
 * @text 移動先ポジション
 * @desc x,y,zで指定します。登録カメラ名がある場合でも、入力するとこちらを優先します。
 * @default
 *
 * @arg rotation
 * @type string
 * @text 移動先回転
 * @desc x,y,zで指定します。単位は度。注視移動では無視されます。空欄の場合は現在値を維持します。
 * @default
 *
 * @arg frame
 * @type number
 * @text フレーム
 * @desc 移動に使うフレーム数です。瞬間移動では無視されます。
 * @default 60
 * @min 1
 *
 * @arg moveMode
 * @type select
 * @text 移動方法
 * @desc カメラの移動方法を指定します。
 * @default linear
 * @option 指定位置・回転へ直線移動
 * @value linear
 * @option オブジェクトを注視しながら移動
 * @value lookAt
 * @option 瞬間移動
 * @value instant
 * @option 暗転して瞬間移動
 * @value fadeInstant
 *
 * @arg lookAtModelKey
 * @type string
 * @text 注視モデル
 * @desc 注視移動時に見るモデルのキーを指定します。
 * @default
 *
 * @arg lookAtAdjustY
 * @type string
 * @text 注視Y調整
 * @desc 注視位置のY調整値です。モデルの足元ではなく顔付近を見る場合に使います。
 * @default 0.8
 *
 * @arg fadeFrames
 * @type number
 * @text 暗転フレーム
 * @desc 暗転して瞬間移動を使う場合の、暗転・復帰それぞれのフレーム数です。
 * @default 15
 * @min 1
 *
 * @command debugSetCamera
 * @text 開発用カメラ直接指定
 * @desc デバッグ用にカメラの位置・回転を直接指定します。回転は度数法XYZです。注視モデルを指定した場合、回転は無視されます。
 *
 * @arg position
 * @type string
 * @text カメラ位置
 * @desc x,y,zで指定します。空欄なら現在位置を維持します。
 * @default
 *
 * @arg rotation
 * @type string
 * @text カメラ回転
 * @desc x,y,zで指定します。単位は度。空欄なら現在回転を維持します。
 * @default
 *
 * @arg lookAtModelKey
 * @type string
 * @text 注視モデル
 * @desc 指定すると、そのモデルを向きます。この場合、カメラ回転は無視されます。
 * @default
 *
 * @arg lookAtAdjustY
 * @type string
 * @text 注視Y調整
 * @desc 注視モデルを指定した場合のY調整値です。
 * @default 0.8
 *
 * @arg outputLog
 * @type boolean
 * @text コンソール出力
 * @desc ONなら設定後のカメラ位置・回転をコンソールへ出します。
 * @default true
 *
 * @command cameraLookAt
 * @text カメラをモデルに向ける
 * @desc カメラの方向を指定したモデルに向けます。
 *
 * @arg modelKey
 * @type string
 * @text モデル
 * @desc モデルのキーを指定します。
 * @default
 *
 * @arg adjustY
 * @type string
 * @text Y調整
 * @desc Yの調整値を指定します。
 * @default 0.8
 *
 * @command freeCameraControl
 * @text 通常カメラ操作
 * @desc 開発モード用のフリーカメラ操作を、開発モードスイッチOFFの通常時にも有効/無効にします。
 *
 * @arg enabled
 * @type boolean
 * @text 有効化
 * @desc ON:通常時でもカメラ操作できます。OFF:通常時のカメラ操作を止めます。
 * @default true
 *
 * @arg showHud
 * @type boolean
 * @text HUD表示
 * @desc ON:通常カメラ操作中も開発HUDを表示します。
 * @default false
 *
 * @arg blockPlayerMove
 * @type boolean
 * @text プレイヤー移動を止める
 * @desc ON:通常カメラ操作中はプレイヤー移動を止めます。カメラ操作とマップクリックの競合防止用です。
 * @default true
 *
 * @command setVRMLight
 * @text VRMライト設定
 * @desc VRM表示用のライト強度とライト方向を変更します。
 *
 * @arg directionalLightIntensity
 * @type string
 * @text 平行光の強さ
 * @desc DirectionalLightの強さです。空欄なら変更しません。\V[数字]対応。目安:0.6～1.2
 * @default 0.8
 *
 * @arg directionalLightIntensityVariableId
 * @type variable
 * @text 平行光の強さ変数
 * @desc 0なら通常の値を使います。指定した変数の数値を優先します。
 * @default 0
 *
 * @arg ambientLightIntensity
 * @type string
 * @text 環境光の強さ
 * @desc AmbientLightの強さです。空欄なら変更しません。\V[数字]対応。目安:0.15～0.35
 * @default 0.25
 *
 * @arg ambientLightIntensityVariableId
 * @type variable
 * @text 環境光の強さ変数
 * @desc 0なら通常の値を使います。指定した変数の数値を優先します。
 * @default 0
 *
 * @arg lightPosition
 * @type string
 * @text 平行光の向き
 * @desc DirectionalLightの位置をx,y,zで指定します。空欄なら変更しません。例:1.0,1.0,1.0
 * @default 1.0,1.0,1.0
 *
 * @arg outputLog
 * @type boolean
 * @text コンソール出力
 * @desc ONなら変更後のライト設定をコンソールへ出します。
 * @default true
 *
 * @command autoBlink
 * @text オートまばたき
 * @desc 自動でまばたきするかどうかを設定します。
 *
 * @arg modelKey
 * @type string
 * @text モデル
 * @desc モデルをキーで指定します。複数指定可
 * @default
 *
 * @arg enabled
 * @type boolean
 * @text 有効化
 * @desc ON:自動でまばたきします。別の表情を設定したい場合はOFFにしてください。
 * @default false
 *
 * @command lookCamera
 * @text カメラ目線
 * @desc カメラ目線にするかどうかを設定します。
 *
 * @arg modelKey
 * @type string
 * @text モデル
 * @desc モデルをキーで指定します。複数指定可
 * @default
 *
 * @arg enabled
 * @type boolean
 * @text 有効化
 * @desc ON:カメラ目線にします。
 * @default false
 *
 *
 * @command setExpression
 * @text 表情設定
 * @desc 表情を設定します。
 *
 * @arg modelKey
 * @type string
 * @text モデル
 * @desc モデルをキーで指定します。複数指定可。\V[数字] の変数展開にも対応します。
 * @default
 *
 * @arg modelKeyVariableId
 * @type variable
 * @text モデルキー変数
 * @desc 0なら通常のモデル指定を使います。指定した変数に hero / hero,enemy / all などのモデルキーが入っている場合はそちらを優先します。
 * @default 0
 *
 * @arg expression
 * @type select
 * @text 表情
 * @desc 表情を選択します。
 * @default neutral
 *
 * @option ニュートラル
 * @value neutral
 * @option 怒り
 * @value angry
 * @option ハッピー
 * @value happy
 * @option リラックス
 * @value relaxed
 * @option 悲しみ
 * @value sad
 * @option おどろき
 * @value surprised
 * @option イキ顔
 * @value ero1 
 * @option テスト用
 * @value Test01 
 * @option --------
 * @option 目線：上
 * @value lookUp
 * @option 目線：下
 * @value lookDown
 * @option 目線：左
 * @value lookLeft
 * @option 目線：右
 * @value lookRight
 * @option 目線：リセット
 * @value lookReset
 * @option --------
 * @option まばたき
 * @value blink
 * @option 左ウインク
 * @value blinkLeft
 * @option 右ウインク
 * @value blinkRight
 * @option --------
 * @option 口：ア
 * @value aa
 * @option 口：イ
 * @value ih
 * @option 口：ウ
 * @value ou
 * @option 口：エ
 * @value ee
 * @option 口：オ
 * @value oh
 * @option 口：リセット
 * @value mouthReset
 *
 * @arg expressionVariableId
 * @type variable
 * @text 表情キー変数
 * @desc 0なら通常の表情指定を使います。指定した変数に happy / blink などの表情キーが入っている場合はそちらを優先します。
 * @default 0
 *
 * @arg value
 * @type string
 * @text 強さ
 * @desc 表情の強さを指定します。
 * @default 100
 *
 * @arg blinkMode
 * @type select
 * @text まばたき
 * @desc この表情指定後のまばたきを強制指定します。ON/OFFは表情固定より優先されます。
 * @default keep
 * @option 変更なし
 * @value keep
 * @option ON
 * @value on
 * @option OFF
 * @value off
 *
 * @command setExpressionByKey
 * @text 表情キー設定
 * @desc 表情キーを文字列で直接指定して表情を設定します。外部JSONの表情エイリアスにも対応します。
 *
 * @arg modelKey
 * @type string
 * @text モデル
 * @desc モデルをキーで指定します。複数指定可。\V[数字] の変数展開にも対応します。
 * @default
 *
 * @arg modelKeyVariableId
 * @type variable
 * @text モデルキー変数
 * @desc 0なら通常のモデル指定を使います。指定した変数に hero / hero,enemy / all などのモデルキーが入っている場合はそちらを優先します。
 * @default 0
 *
 * @arg expressionKey
 * @type string
 * @text 表情キー
 * @desc happy / blink / aa / 独自キー / 外部JSONの表情エイリアスを指定します。
 * @default
 *
 * @arg expressionKeyVariableId
 * @type variable
 * @text 表情キー変数
 * @desc 0なら通常の表情キーを使います。指定した変数に happy / blink などの表情キーが入っている場合はそちらを優先します。
 * @default 0
 *
 * @arg value
 * @type string
 * @text 強さ
 * @desc 0～100で指定します。\V[数字] の変数展開にも対応します。
 * @default 100
 *
 * @arg valueVariableId
 * @type variable
 * @text 強さ変数
 * @desc 0なら通常の値指定を使います。指定した変数の数値を優先します。
 * @default 0
 *
 * @arg blinkMode
 * @type select
 * @text まばたき
 * @desc この表情指定後のまばたきを強制指定します。ON/OFFは表情固定より優先されます。
 * @default keep
 * @option 変更なし
 * @value keep
 * @option ON
 * @value on
 * @option OFF
 * @value off
 *
 * @command setExpressionValue
 * @text Expression値設定
 * @desc 指定したExpressionキーの値だけを直接設定します。
 *
 * @arg modelKey
 * @type string
 * @text モデル
 * @desc モデルをキーで指定します。複数指定可。\V[数字] の変数展開にも対応します。
 * @default
 *
 * @arg modelKeyVariableId
 * @type variable
 * @text モデルキー変数
 * @desc 0なら通常のモデル指定を使います。指定した変数に hero / hero,enemy / all などのモデルキーが入っている場合はそちらを優先します。
 * @default 0
 *
 * @arg expressionKey
 * @type string
 * @text Expressionキー
 * @desc 設定したいExpressionキーを指定します。例: happy / blink / aa / 独自キー
 * @default
 *
 * @arg expressionKeyVariableId
 * @type variable
 * @text Expressionキー変数
 * @desc 0なら通常のキー指定を使います。指定した変数に happy / blink / aa などのキーが入っている場合はそちらを優先します。
 * @default 0
 *
 * @arg value
 * @type string
 * @text 値
 * @desc 0～100で指定します。\V[数字] の変数展開にも対応します。
 * @default 100
 *
 * @arg valueVariableId
 * @type variable
 * @text 値変数
 * @desc 0なら通常の値指定を使います。指定した変数の数値を優先します。
 * @default 0
 *
 * @arg resetOther
 * @type boolean
 * @text 他の表情をリセット
 * @desc ONなら設定前に全Expression値を0にします。OFFなら指定キーだけ変更します。
 * @default false
 *
 * @arg warnIfMissing
 * @type boolean
 * @text 存在しないキーを警告
 * @desc ONなら指定キーが見つからない場合にコンソールへ警告します。
 * @default true
 *
 * @arg blinkMode
 * @type select
 * @text まばたき
 * @desc この表情指定後のまばたきを強制指定します。ON/OFFは表情固定より優先されます。
 * @default keep
 * @option 変更なし
 * @value keep
 * @option ON
 * @value on
 * @option OFF
 * @value off
 *
 * @command disabledExpression
 * @text 表情機能の無効化
 * @desc プラグインによる表情設定を無効化します。(VRMAに表情が設定されている場合に使用)
 * 
 * @arg modelKey
 * @type string
 * @text モデル
 * @desc モデルをキーで指定します。複数指定可
 * @default
 * 
 * @arg disabled
 * @text 無効化する
 * @type boolean
 * @desc ON:プラグインによる表情設定を無効化 OFF:解除
 * @default off
 *
 * @command startMotion
 * @text モーションスタート
 * @desc モーションをスタートします。
 *
 * @arg modelKey
 * @type string
 * @text モデル
 * @desc モデルをキーで指定します。複数指定可
 * @default
 *
 * @arg motionKey
 * @type string
 * @text モーション
 * @desc VRMAをキーで指定します。
 * @default
 *
 * @arg loop
 * @type select
 * @text ループ
 * @desc ループを設定します。
 * @default enabled
 *
 * @option ループする
 * @value enabled
 * @option ループしない
 * @value disabled
 * @option ピンポンループする
 * @value ping-pong
 *
 * @arg speed
 * @type string
 * @text 速度
 * @desc 再生速度を指定します。0で一時停止、100で等倍再生、-100で逆再生
 * @default 100
 *
 * @arg fadeFrames
 * @type number
 * @text 補完フレーム
 * @desc 0より大きい場合、前のモーションからこのフレーム数で補完しながら切り替えます。0で即切り替え。
 * @default 12
 * @min 0
 *
 * @arg nextMotionKey
 * @type string
 * @text 次のモーションキー
 * @desc ループしない場合にのみ使用されます。モーション完了後、このモーションが速度1でループ再生されます。
 * @default
 *
 * @command motionSpeed
 * @text モーションの再生速度
 * @desc 実行中のモーションの再生速度を変更します。
 *
 * @arg modelKey
 * @type string
 * @text モデル
 * @desc モデルをキーで指定します。
 * @default
 *
 * @arg speed
 * @type string
 * @text 速度
 * @desc 再生速度を指定します。0で一時停止、100で等倍再生、-100で逆再生
 * @default 100
 *
 * @command autoMouth
 * @text 口パク
 * @desc 文章の表示でモデルの口を動かします。
 *
 * @arg modelKey
 * @type string
 * @text モデル
 * @desc モデルをキーで指定します。複数指定可。空欄でリセット。
 * @default
 *
 * @command dispose
 * @text モデルの破棄
 * @desc モデルを破棄します。
 *
 * @arg modelKey
 * @type string
 * @text モデル
 * @desc モデルをキーで指定します。複数指定可
 * @default
 *
 * @command loadSkipList
 * @text ロードスキップリストの編集
 * @desc ロードスキップリストを変更します。
 *
 * @arg mode
 * @type select
 * @text モード
 * @desc リストに追加するか、削除するかを指定します。
 * @default add
 *
 * @option 追加
 * @value add
 * @option 削除
 * @value remove
 *
 * @arg modelKey
 * @type string
 * @text モデル
 * @desc モデルをキーで指定します。複数指定可
 * @default
 *
 */

/*~struct~VrmModel:
 *
 * @param keyName
 * @type string
 * @text キー
 * @desc モデルの名前を指定。編集画面ではこの名前を使用します。「all」は使用不可。
 * @default
 *
 * @param fileName
 * @type string
 * @text VRM
 * @desc vrmフォルダ内のVRMを指定    vrm/goblin.vrm -> goblin    vrm/enemy/goblin.vrm -> enemy/goblin
 * @default
 *
 * @param preLoad
 * @type boolean
 * @text 必ずロード
 * @desc マップ開始時に必ず読み込みます。
 * @default true
 *
 */

/*~struct~Motion:
 *
 * @param keyName
 * @type string
 * @text キー
 * @desc アニメーションの名前を指定。編集画面ではこの名前を使用します。
 * @default
 *
 * @param fileName
 * @type string
 * @text VRMA
 * @desc vrm/vrma内のVRMAを指定    vrm/vrma/dance.vrma -> dance    vrm/vrma/enemy/dance.vrma -> enemy/dance
 * @default
 *
 */
/*~struct~Position:
 *
 * @param keyName
 * @type string
 * @text キー
 * @desc ポジションの名前を指定。編集画面ではこの名前を使用します。
 * @default
 *
 * @param position
 * @type string
 * @text ポジション
 * @desc ポジションをx,y,zで指定
 * @default 0,0,0
 *
 */
/*~struct~ModelRotation:
 *
 * @param keyName
 * @type string
 * @text キー
 * @desc 向きの名前を指定。編集画面ではこの名前を使用します。「camera」はシステム専用のため不可。
 * @default
 *
 * @param rotationY
 * @type number
 * @text 回転
 * @desc 回転Yを-180から180で指定
 * @default 0
 * @max 180
 * @min -180
 *
 */
/*~struct~Camera:
 *
 * @param keyName
 * @type string
 * @text キー
 * @desc カメラの名前を指定。編集画面ではこの名前を使用します。
 * @default
 *
 * @param position
 * @type string
 * @text ポジション
 * @desc ポジションをx,y,zで指定
 * @default 0,0,0
 *
 * @param rotation
 * @type string
 * @text 回転
 * @desc 回転をx,y,zで指定
 * @default 0,0,0
 *
 */

/*
■変更履歴
・v1.0.1-db-safe-vrma-idle
  存在しないVRMAを起動時に読み込もうとした場合、ローカル環境では事前にファイル存在チェックしてスキップするようにした。
  setupVRM()のidle固定再生を、idleがロード済みの場合のみ実行するよう安全化。
・v1.0.1-db-external-config-json
  プラグインパラメータ「外部設定JSON」を追加。VRM/VRMA/ポジション/向き/カメラ/表情エイリアスを外部JSONから追加・上書き可能にした。
  コマンド「表情キー設定」を追加。表情キーを文字列で直接指定でき、外部JSONの表情エイリアスにも対応。
・v1.0.1-db-normal-camera-control-orbit-no-snap
  左ドラッグのモデル中心周回で、開始時およびドラッグ開始直後にlookAt()で向きを吸わせず、現在のカメラ位置・向きを基準にそのまま周回移動するよう修正。
・v1.0.1-db-normal-camera-control-orbit-start-fix
  左ドラッグ開始時にカメラ位置・向きを変更しないよう修正。現在座標を基準に、ドラッグ量が出た後だけターゲット周回移動する。
・v1.0.1-db-normal-camera-control-lookonly
  コマンド「通常カメラ操作」を追加。開発モード用カメラ操作を通常時にも有効化できるようにした。
  左ドラッグ時はカメラ座標を変更せず、対象モデルの方向を見るだけに変更。
・v1.0.1-db-light-control
  VRMライト設定用のプラグインパラメータとコマンド「VRMライト設定」を追加。
・v1.0.1-db-blendshape-value-command
  コマンド「Expression値設定」を追加。指定したExpressionキーの値を直接設定可能にした。
・v1.0.1-db-expression-model-variable
  表情設定コマンドのモデル指定を変数指定に対応。
・v1.0.1-db-expression-variable-debug-camera
  表情設定コマンドに表情キー変数を追加。開発用カメラ直接指定コマンドとコンソール用関数を追加。
・v1.0.1-db-camera-move-command-fix-rotation
  カメラ移動の回転指定をクォータニオン補間へ変更。デバッグ表示/コピー用の回転値をコマンド入力と同じXYZ表現に変更。
・v1.0.1-db-camera-move-command
  コマンド「カメラ移動」を追加。直線移動、注視移動、瞬間移動、暗転瞬間移動に対応。
・v1.0.1-db-free-camera-middle-pan-right-rotate
  開発モード中、中央ドラッグで平行移動、右ドラッグでカメラ回転できるよう調整。
・v1.0.1-db-free-camera-pan
  開発モード中の中央ボタンドラッグで、画面平面方向へカメラを平行移動する機能を追加。
・v1.0.1-db-free-camera-orbit-target
  開発モード中の左ドラッグを対象モデル中心の周回回転に変更。
・v1.0.1-db-runtime-register-position-sync
  Command Toolで作成した位置/向き/カメラは外部JSONで管理する方針に変更。
  registerPosition/registerDirection/registerCamera は互換用として残すが、通常のイベントコピーでは使用しない。
  setPosition/setDirection/setCameraで未登録キーを指定した場合、外部JSON未反映の可能性をログ出力。
・v1.0.1-db-free-camera-coordinate-unify
  カメラ座標をフリーカメラ基準に統一。
  camera.position / camera quaternion を唯一の正とし、OrbitControls.update() による target 基準の再補正を停止。
  プラグインコマンド、開発HUD、Ctrl+PgUp/PgDnコピー、セーブ/ロードの回転値をXYZ度数表現に統一。
・v1.0.1-db-free-camera
  開発モード中のカメラ操作をOrbitControls依存から直接操作へ変更。
・v1.0.1
  コマンド「表情機能の無効化」を追加。
・v1.0.0
  公開
*/

if (!SUND_MODS) {
    // SunD_VRM_MODで設定
    var SUND_MODS = {
        THREE: undefined,
        GLTFLoader: undefined,
        OrbitControls: undefined,
        THREE_VRM: undefined,
        THREE_VRM_Animation: undefined,
    };
}

// メインデータ
var $sundVRMs = new Map();

(() => {
    "use strict";
    const script = document.currentScript;
    const params = PluginManagerEx.createParameter(script);

    // -----------------
    // SUND_VRM

    class SUND_VRM {
        static _params = {
            vrmMap: new Map(),
            vrmaMap: new Map(),
            positionMap: new Map(),
            directionMap: new Map(),
            cameraMap: new Map(),
            expressionAliasMap: new Map(),
            loadModels: new Set(),
            devModeSW: params.devModeSW,
            directionalLightIntensity: 0.8,
            ambientLightIntensity: 0.25,
            lightPosition: { x: 1.0, y: 1.0, z: 1.0 },
        };

        static _renderer;
        static _scene;
        static _camera;
        static _light;
        static _ambientLight;
        static _animations = new Map();
        static _missingVrmaKeys = new Set();
        static _threeSprite;
        static _controls;
        static _devHud;        
        static _cameraMove = {
            active: false,
            mode: "linear",
            totalFrames: 0,
            remainingFrames: 0,
            startPosition: null,
            goalPosition: null,
            startRotation: null,
            goalRotation: null,
            startQuaternion: null,
            goalQuaternion: null,
            lookAtModelKey: "",
            lookAtAdjustY: 0.8,
            fade: null,
        };
        static _visibleAnyModel = false;
        static _AXIS_X = { x: 1, y: 0, z: 0 };
        static _AXIS_Y = { x: 0, y: 1, z: 0 };
        static _AXIS_Z = { x: 0, y: 0, z: 1 };
        static _dev = {
            touchX: null,
            touchY: null,
            cameraDragging: false,
            cameraLastX: 0,
            cameraLastY: 0,
            cameraOrbitDragging: false,
            cameraOrbitLastX: 0,
            cameraOrbitLastY: 0,
            cameraOrbitTargetKey: "",
            cameraMiddlePressed: false,
            cameraMiddleDragging: false,
            cameraMiddleLastX: 0,
            cameraMiddleLastY: 0,
            cameraMiddleX: 0,
            cameraMiddleY: 0,
            cameraRightPressed: false,
            cameraRightDragging: false,
            cameraRightLastX: 0,
            cameraRightLastY: 0,
            cameraRightX: 0,
            cameraRightY: 0,
            cameraMouseListenerReady: false,
        };
        static _autoMouth = { targets: [], duration: 0 };
        static _readyState = "";

        static #loader;
        static get loader() {
            return this.#loader;
        }

        static #moduleLoaded = false;
        static get moduleLoaded() {
            return this.#moduleLoaded;
        }

        static #clock;
        static get clock() {
            return this.#clock;
        }

        static #deltaTime = 0;
        static get deltaTime() {
            return this.#deltaTime;
        }

        // SunD_VRM_MODが実行する
        static setupMOD() {
            const loader = new SUND_MODS.GLTFLoader();
            this.#loader = loader;
            loader.register((parser) => {
                return new SUND_MODS.THREE_VRM.VRMLoaderPlugin(parser);
            });

            loader.register((parser) => {
                return new SUND_MODS.THREE_VRM_Animation.VRMAnimationLoaderPlugin(parser);
            });

            this._params.vrmaMap.forEach((value, key) => {
                this.loadVRMA(key, value);
            });

            // まだシステム設定の読み取り前
            const w = 816;
            const h = 624;

            const three = SUND_MODS.THREE;
            const scene = new three.Scene();
            this._scene = scene;

        const renderer = new three.WebGLRenderer({
            alpha: true,
            antialias: true,
            powerPreference: "high-performance"
        });

        // 高DPI対応。重すぎるのを防ぐため上限は2
        renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
        renderer.setSize(w, h, false);

        // 色空間
        if ("outputColorSpace" in renderer && "SRGBColorSpace" in three) {
            renderer.outputColorSpace = three.SRGBColorSpace;
        } else if ("outputEncoding" in renderer && "sRGBEncoding" in three) {
            renderer.outputEncoding = three.sRGBEncoding;
        }

        renderer.domElement.style.zIndex = 0;
        renderer.domElement.style.position = "absolute";
        document.body.appendChild(renderer.domElement);
        this._renderer = renderer;
            renderer.domElement.style.zIndex = 0;
            renderer.domElement.style.position = "absolute";
            document.body.appendChild(renderer.domElement);
            this._renderer = renderer;

            const camera = new three.PerspectiveCamera(45, w / h, 0.03, 100);
            camera.position.set(0, 0, 3);
            this._camera = camera;
            scene.add(camera);

            const controls = new SUND_MODS.OrbitControls(camera, renderer.domElement);
            controls.enabled = false;
            // この関数は独自に追加したもの。listenToKeyEvents()のマウス版
            controls.listenToMouseEvents(document.body);
            this._controls = controls;

            const ambientLight = new three.AmbientLight(0xffffff, this._params.ambientLightIntensity);
            scene.add(ambientLight);
            this._ambientLight = ambientLight;

            const light = new three.DirectionalLight(0xffffff, this._params.directionalLightIntensity);
            light.position.set(
                this._params.lightPosition.x,
                this._params.lightPosition.y,
                this._params.lightPosition.z
            );
            scene.add(light);
            this._light = light;
            this.applyVRMLightSettings();

            const clock = new three.Clock();
            this.#deltaTime = clock.getDelta();
            this.#clock = clock;

            this.#moduleLoaded = true;
            Graphics._updateThreeElements();
        }

        static loadVRM(keyName, fileName) {
            this.loader.load(
                "./vrm/" + fileName + ".vrm",
                (gltf) => {
                    this.setupVRM(keyName, gltf);
                },
                (progress) => { },
                (error) => {
                    // ゲーム公開形式によってリトライ検討が必要
                    console.error(error);
                }
            );
        }

        static disableFirstPersonHeadHide(vrm) {
            if (!vrm || !vrm.scene) return;

            const removeList = [];

            // 生成済みの headless / erase メッシュを除去対象として収集
            vrm.scene.traverse((node) => {
                if (!node) return;

                if (node.name) {
                    if (node.name.startsWith("_headless_") || node.name.endsWith("(erase)")) {
                        removeList.push(node);
                    }
                }
            });

            // first person 注釈を全部 both 扱いに戻す
            if (vrm.firstPerson && Array.isArray(vrm.firstPerson.meshAnnotations)) {
                vrm.firstPerson.meshAnnotations.forEach((annotation) => {
                    annotation.type = "both";

                    if (Array.isArray(annotation.meshes)) {
                        annotation.meshes.forEach((mesh) => {
                            if (!mesh) return;
                            mesh.layers.set(0);
                            mesh.traverse((child) => {
                                if (child && child.layers) {
                                    child.layers.set(0);
                                }
                            });
                        });
                    }
                });
            }

            // 念のため、VRM全体を通常レイヤーへ戻す
            vrm.scene.traverse((node) => {
                if (node && node.layers) {
                    node.layers.set(0);
                }
            });

            // headless 系を削除
            removeList.forEach((node) => {
                if (node.parent) {
                    node.parent.remove(node);
                }
            });
        }


        static setupVRM(keyName, gltf) {
            const obj = $sundVRMs.get(keyName);
            const scene = this._scene;
            const vrm = gltf.userData.vrm;

            // 近距離で顔や服が飛ぶ対策
            vrm.scene.traverse((node) => {
                if (!node) return;
                if (node.isMesh || node.isSkinnedMesh) {
                    node.frustumCulled = false;
                }
            });

            // 表示状態で配置。isReadyの過程で非表示にする
            scene.add(vrm.scene);

            const proxy = new SUND_MODS.THREE_VRM_Animation.VRMLookAtQuaternionProxy(vrm.lookAt);
            proxy.name = "VRMLookAtQuaternionProxy";
            vrm.scene.add(proxy);

            // デフォルトでやや下げる
            vrm.scene.position.y -= 0.8;

            obj._gltf = gltf;
            obj._vrm = vrm;
            obj._mixer = new SUND_MODS.THREE.AnimationMixer(vrm.scene);
            obj._needsTrialRender = true;
            obj._loaded = true;

            // 以前は必ず idle を再生していたが、idle.vrma が未登録/未配置の場合に混乱しやすいため、
            // ロード済みのときだけ初期モーションとして再生する。
            if (SUND_VRM._animations.has("idle")) {
                obj.startMotion({ motionKey: "idle", nextMotionKey: "", loop: "enabled", speed: 1 });
            }
        }

        static canUseLocalFs() {
            try {
                return !!(Utils && Utils.isNwjs && Utils.isNwjs() && typeof require === "function" && typeof process === "object");
            } catch (_) {
                return false;
            }
        }

        static localResourceExists(relativeUrl) {
            if (!this.canUseLocalFs()) return true;
            try {
                const fs = require("fs");
                const path = require("path");
                const clean = String(relativeUrl || "").replace(/^\.\//, "").replace(/[?#].*$/, "");
                const fullPath = path.join(process.cwd(), clean);
                return fs.existsSync(fullPath);
            } catch (_) {
                // 存在確認に失敗した場合は従来通りloaderへ任せる
                return true;
            }
        }

        static loadVRMA(keyName, fileName) {
            const key = "" + keyName;
            const file = "" + fileName;
            if (!file) {
                this._missingVrmaKeys.add(key);
                console.warn(`[SunD_VRM] VRMA fileName is empty. Skip loading: key=${key}`);
                return;
            }
            const url = "./vrm/vrma/" + file + ".vrma";
            if (!this.localResourceExists(url)) {
                this._missingVrmaKeys.add(key);
                console.warn(`[SunD_VRM] VRMA file not found. Skip loading: key=${key}, path=${url}`);
                return;
            }
            this.loader.load(
                url,
                (gltf) => {
                    this.setupVRMA(key, gltf);
                },
                (progress) => { },
                (error) => {
                    this._missingVrmaKeys.add(key);
                    console.warn(`[SunD_VRM] VRMA load failed: key=${key}, path=${url}`);
                    console.error(error);
                }
            );
        }

        static setupVRMA(keyName, gltf) {
            const vrmAnimations = gltf.userData.vrmAnimations;
            if (!vrmAnimations || !vrmAnimations[0]) return;
            this._animations.set("" + keyName, vrmAnimations[0]);
        }

        static setActionLoop(strLoop, action) {
            switch (strLoop) {
                case "enabled":
                    action.setLoop(SUND_MODS.THREE.LoopRepeat);
                    break;
                case "ping-pong":
                    action.setLoop(SUND_MODS.THREE.LoopPingPong);
                    break;
                case "disabled":
                    action.setLoop(SUND_MODS.THREE.LoopOnce);
                    break;
                default:
                    action.setLoop(SUND_MODS.THREE.LoopRepeat);
            }
        }

        static fadeFramesToSeconds(frames) {
            const value = Number(frames || 0);
            if (!isFinite(value) || value <= 0) return 0;
            return value / 60;
        }

        static dispose(keyName) {
            const obj = $sundVRMs.get(keyName);
            if (!obj) return;

            $sundVRMs.delete(keyName);

            // 念のため
            obj._animationActions.clear();
            obj._mixer._initMemoryManager();
            obj._mixer = null;

            // geometry,skeleton,material,texture
            const vrm = obj._vrm;
            const scene = vrm.scene;
            obj._vrm = null;
            SUND_MODS.THREE_VRM.VRMUtils.deepDispose(scene);

            // ImageBitmap,texture
            const cache = obj._gltf.parser.sourceCache;
            for (let key in cache) {
                cache[key].then(texture => {
                    if (texture.image && texture.image.close) {
                        texture.image.close();
                    }
                    texture.dispose();
                });
            }
            obj._gltf = null;

            // 絶縁
            scene.removeFromParent();
        }

         static isDevMode() {
            return !!($gameSwitches && $gameSwitches.value(this._params.devModeSW) && this._visibleAnyModel);
        }

        static defaultFreeCameraControlData() {
            return {
                enabled: false,
                showHud: false,
                blockPlayerMove: true,
            };
        }

        static freeCameraControlData() {
            if (!$gameSystem) return this.defaultFreeCameraControlData();
            if (!$gameSystem._sundVRMFreeCameraControl) {
                $gameSystem._sundVRMFreeCameraControl = this.defaultFreeCameraControlData();
            }
            const data = $gameSystem._sundVRMFreeCameraControl;
            if (data.showHud === undefined) data.showHud = false;
            if (data.blockPlayerMove === undefined) data.blockPlayerMove = true;
            return data;
        }

        static commandBoolean(value, defaultValue = false) {
            if (value === undefined || value === null || value === "") return defaultValue;
            if (value === true || value === false) return value;
            const text = this.stringTrim(value).toLowerCase();
            if (["true", "on", "1", "yes"].includes(text)) return true;
            if (["false", "off", "0", "no"].includes(text)) return false;
            return defaultValue;
        }

        static setFreeCameraControl(args = {}) {
            const data = this.freeCameraControlData();
            data.enabled = this.commandBoolean(args.enabled, true);
            data.showHud = this.commandBoolean(args.showHud, false);
            data.blockPlayerMove = this.commandBoolean(args.blockPlayerMove, true);

            if (!data.enabled) {
                this.resetDevFreeCameraInput();
                if (!this.isDevMode()) {
                    this.hideDevHud();
                }
            }
        }

        static isNormalFreeCameraControl() {
            const data = this.freeCameraControlData();
            return !!(data.enabled && this._visibleAnyModel);
        }

        static isCameraControlMode() {
            return !!(this.isDevMode() || this.isNormalFreeCameraControl());
        }

        static shouldShowCameraHud() {
            if (this.isDevMode()) return true;
            const data = this.freeCameraControlData();
            return !!(this.isNormalFreeCameraControl() && data.showHud);
        }

        static shouldBlockPlayerMoveByCameraControl() {
            if (this.isDevMode()) return true;
            const data = this.freeCameraControlData();
            return !!(this.isNormalFreeCameraControl() && data.blockPlayerMove);
        }

        static dontMovePlayer() {
            return this.shouldBlockPlayerMoveByCameraControl();
        }

        static isMouseHoverBoneDevMode() {
            try {
                return !!(
                    $gameSystem &&
                    typeof $gameSystem.sundVrmMouseHoverBoneDevMode === "function" &&
                    $gameSystem.sundVrmMouseHoverBoneDevMode()
                );
            } catch (e) {
                return false;
            }
        }

        static ensureDevHud() {
            if (this._devHud) return;

            const div = document.createElement("div");
            div.id = "SUND_VRM_DEV_HUD";
            div.style.position = "absolute";
            div.style.right = "8px";
            div.style.bottom = "8px";
            div.style.zIndex = "999998";
            div.style.pointerEvents = "none";
            div.style.whiteSpace = "pre";
            div.style.fontFamily = "monospace";
            div.style.fontSize = "16px";
            div.style.lineHeight = "1.35";
            div.style.color = "#ffffff";
            div.style.background = "rgba(0,0,0,0.65)";
            div.style.padding = "6px 8px";
            div.style.border = "1px solid rgba(255,255,255,0.25)";
            div.style.borderRadius = "4px";
            div.style.display = "none";
            document.body.appendChild(div);
            this._devHud = div;
        }

        static hideDevHud() {
            if (this._devHud) {
                this._devHud.style.display = "none";
            }
        }

        static updateDevHud() {
            this.ensureDevHud();
            if (!this._devHud) return;

            const visible = this.shouldShowCameraHud();
            this._devHud.style.display = visible ? "block" : "none";
            if (!visible || !this._camera) return;

            const cam = this._camera;
            const pos = cam.position;
            const displayRot = this.makeCameraDisplayDegreesObject();
            const rotX = this.devNum(displayRot.x);
            const rotY = this.devNum(displayRot.y);
            const rotZ = this.devNum(displayRot.z);
            const target = this._controls && this._controls.target ? this._controls.target : null;
            const usingOrbit = !!(this._controls && this._controls.enabled);
            const hoverDev = this.isMouseHoverBoneDevMode();
            const orbitInfo = this.getDevOrbitTargetInfo(false);

            const lines = [
                `[SunD_VRM DevHUD]`,
                `camera position : ${this.devNum(pos.x)}, ${this.devNum(pos.y)}, ${this.devNum(pos.z)}`,
                `camera rotation : ${rotX}, ${rotY}, ${rotZ}  (XYZ / command)`,
                `camera target   : ${target ? this.devNum(target.x) : "-"}, ${target ? this.devNum(target.y) : "-"}, ${target ? this.devNum(target.z) : "-"}`,
                `orbit model     : ${orbitInfo ? orbitInfo.key : "-"}`,
                `fov/aspect      : ${this.devNum(cam.fov)} / ${this.devNum(cam.aspect)}`,
                `near/far        : ${this.devNum(cam.near)} / ${this.devNum(cam.far)}`,
                `light           : dir ${this.devNum(this._params.directionalLightIntensity)} / amb ${this.devNum(this._params.ambientLightIntensity)}`,
                `free camera     : ${usingOrbit ? "ORBIT" : "DIRECT"}`,
                `MouseHover F7   : ${hoverDev ? "ON" : "OFF"}`,
                `visible models  : ${this._visibleAnyModel ? "YES" : "NO"}`,
                `Left drag : rotate view without moving position`,
                `Right drag : rotate camera`,
                `Middle drag : pan camera`,
                `Arrow keys : move forward/back/left/right`,
                `PgUp/PgDn : move camera up/down`,
                `Wheel : move forward/back`,
                `Shift + input : move/rotate model`,
                `Ctrl+PgUp : copy position`,
                `Ctrl+PgDn : copy rotation`
            ];
            this._devHud.textContent = lines.join("\n");
        }

        static isLoadSkipModel(keyName) {
            return $gameParty._sundVRM.loadSkipModels.includes(keyName);
        }


        static allLoaded() {
            return !Array.from($sundVRMs.values()).some((el) => !el._loaded);
        }

        static isReady() {
            if (!this.moduleLoaded) return false;

            switch (this._readyState) {
                case "start":
                    this.mapLoadVRM();
                    this._readyState = "loading";
                    return false;
                case "loading":
                    if (this.allLoaded()) {
                        this._readyState = "trialRender";
                    }
                    return false;
                case "trialRender":
                    //初回レンダリングに時間がかかるのでやっておく
                    this._renderer.render(this._scene, this._camera);
                    $sundVRMs.forEach((el) => {
                        if (el._needsTrialRender) {
                            el._needsTrialRender = false;
                            el.hide();
                        }
                    });
                    this._readyState = "restore";
                    return false;
                case "restore":
                    $sundVRMs.forEach((el) => {
                        el.restoreContinueData();
                    });
                    this._readyState = "finished";
                    return false;
                case "finished":
                    return true;
                default:
                    return true;
            }
        }

        static mapLoadVRM() {
            const loadSet = new Set();
            const data = $gameParty._sundVRM;
            // 必ずロード
            this._params.loadModels.forEach((keyName) => {
                loadSet.add(keyName);
            });
            // マップ指定
            if (!DataManager.isEventTest() && $dataMap.meta["Load_VRM"]) {
                const keys = this.modelKeyToArray($dataMap.meta["Load_VRM"]);
                keys.forEach((key) => {
                    loadSet.add(key);
                });
            }
            // 保存データ
            if (this._afterContinue) {
                data.modelSaveData.forEach((el) => {
                    loadSet.add(el.keyName);
                });

                this.restoreCameraData();
            }

            // 読み込み
            loadSet.forEach((keyName) => {
                if (!this.isLoadSkipModel(keyName)) {
                    const obj = this.create(keyName);
                    if (this._afterContinue) {
                        const continueData = data.modelSaveData.find((el) => el.keyName === keyName);
                        obj._continueData = continueData;
                    }
                }
            });
            this._afterContinue = false;
        }

        static create(keyName) {
            if ($sundVRMs.has(keyName)) {
                return $sundVRMs.get(keyName);
            }
            const fileName = this._params.vrmMap.get(keyName);
            const obj = new this(keyName);
            $sundVRMs.set(keyName, obj);
            this.loadVRM(keyName, fileName);
            return obj;
        }

        static hasVisibleStage() {
            try {
                return !!(
                    window.SUND_VRM_GLTFStage &&
                    typeof window.SUND_VRM_GLTFStage.hasVisibleStage === "function" &&
                    window.SUND_VRM_GLTFStage.hasVisibleStage()
                );
            } catch (_) {
                return false;
            }
        }

        static isHoverDebugRenderActive() {
            try {
                return !!(
                    window.SUND_VRM_MouseHoverBone &&
                    typeof window.SUND_VRM_MouseHoverBone.isDebugRenderActive === "function" &&
                    window.SUND_VRM_MouseHoverBone.isDebugRenderActive()
                );
            } catch (_) {
                return false;
            }
        }

        static needsThreeRender() {
            return !!(
                this._visibleAnyModel ||
                this.hasVisibleStage() ||
                this.isHoverDebugRenderActive() ||
                this.isCameraControlMode() ||
                this.isCameraMoveActive()
            );
        }

        static deactivateThreeDebug() {
            if (this._controls) {
                this._controls.enabled = false;
            }
            this.resetDevFreeCameraInput();
            this.hideDevHud();
        }

        static updateMap() {
            this.updateMapVRM();
            this.#deltaTime = this.clock.getDelta();
            this.updateCameraMove();

            if (this.isCameraControlMode() && !this.isCameraMoveActive()) {
                this.updateDevCamera();
                this.updateDevCameraInformation();
            } else {
                this.deactivateThreeDebug();
            }

            if (!this.needsThreeRender()) {
                this.clearThreeSprite();
                return;
            }

            this._renderer.render(this._scene, this._camera);
            this.drawThreeSprite();

            if (this.shouldShowCameraHud()) {
                this.updateDevHud();
            } else {
                this.hideDevHud();
            }
        }

        static updateMapVRM() {
            let visible = false;
            $sundVRMs.forEach((el) => {
                if (!visible && el._vrm && el.visible()) {
                    visible = true;
                }
                el.update();
            });
            this._visibleAnyModel = visible;
        }

        static isCameraMoveActive() {
            const m = this._cameraMove;
            return !!(m && (m.active || (m.fade && m.fade.active)));
        }

        static clearCameraMove() {
            const m = this._cameraMove;
            if (!m) return;
            m.active = false;
            m.mode = "linear";
            m.totalFrames = 0;
            m.remainingFrames = 0;
            m.startPosition = null;
            m.goalPosition = null;
            m.startRotation = null;
            m.goalRotation = null;
            m.startQuaternion = null;
            m.goalQuaternion = null;
            m.lookAtModelKey = "";
            m.lookAtAdjustY = 0.8;
            m.fade = null;
        }

        static parseXYZ(str) {
            const text = this.stringTrim(str);
            if (!text) return null;
            const arr = text.split(",").map((el) => Number(this.stringTrim(el)));
            if (arr.length !== 3) return null;
            if (arr.some((value) => !Number.isFinite(value))) return null;
            return this.makeObjectXYZ(arr[0], arr[1], arr[2]);
        }

        static cloneXYZ(obj) {
            if (!obj) return null;
            return this.makeObjectXYZ(Number(obj.x || 0), Number(obj.y || 0), Number(obj.z || 0));
        }

        static positiveNumber(value, defaultValue = 1) {
            const n = Number(value);
            if (!Number.isFinite(n)) return defaultValue;
            return Math.max(1, n);
        }

        static normalizeCameraMoveMode(mode) {
            switch (this.stringTrim(mode)) {
                case "lookAt":
                case "linear":
                case "instant":
                case "fadeInstant":
                    return this.stringTrim(mode);
                default:
                    return "linear";
            }
        }

        static resolveCameraMoveTarget(args) {
            const cam = this._camera;
            if (!cam) return null;

            let position = null;
            let rotationDeg = null;
            const cameraKey = this.stringTrim(args.cameraKey);
            if (cameraKey) {
                const camData = this._params.cameraMap.get(cameraKey);
                if (!camData) return null;
                position = this.cloneXYZ(camData.position);
                rotationDeg = this.cloneXYZ(camData.rotation);
            }

            const directPos = this.parseXYZ(args.position);
            if (directPos) {
                position = directPos;
            }

            const directRot = this.parseXYZ(args.rotation);
            if (directRot) {
                rotationDeg = directRot;
            }

            if (!position) return null;
            if (!rotationDeg) {
                rotationDeg = this.makeCameraDisplayDegreesObject();
            }

            return {
                position: position,
                rotationDeg: rotationDeg,
            };
        }

        static getCameraLookAtTarget(modelKey, adjustY) {
            const three = SUND_MODS.THREE;
            if (!three) return null;
            const obj = $sundVRMs.get(this.stringTrim(modelKey));
            if (!obj || !obj._vrm || !obj._vrm.scene) return null;
            const p = obj._vrm.scene.position.clone();
            p.y += Number.isFinite(Number(adjustY)) ? Number(adjustY) : 0.8;
            return p;
        }

        static applyCameraMoveTarget(target, mode = "linear", lookAtModelKey = "", lookAtAdjustY = 0.8) {
            const cam = this._camera;
            if (!cam || !target) return;
            cam.position.set(target.position.x, target.position.y, target.position.z);
            this.ensureDevCameraRotationOrder();

            let syncTarget = null;
            if (mode === "lookAt") {
                syncTarget = this.getCameraLookAtTarget(lookAtModelKey, lookAtAdjustY);
                if (syncTarget) {
                    cam.lookAt(syncTarget);
                    this.applyCameraQuaternion(cam.quaternion.clone());
                }
            } else {
                const q = this.makeCameraQuaternionFromDegrees(target.rotationDeg);
                this.applyCameraQuaternion(q);
            }
            cam.updateMatrixWorld(true);
            this.syncCameraControls(syncTarget);
        }

        static makeDebugCameraText() {
            const cam = this._camera;
            if (!cam) return "[SUND_VRM camera] camera is not ready";

            const pos = cam.position;
            const rot = this.makeCameraDisplayDegreesObject();
            return [
                "[SUND_VRM camera]",
                `position: ${this.devNum(pos.x)},${this.devNum(pos.y)},${this.devNum(pos.z)}`,
                `rotation: ${this.devNum(rot.x)},${this.devNum(rot.y)},${this.devNum(rot.z)}`,
                `console : SUND_VRM.debugCamera(\"${this.devNum(pos.x)},${this.devNum(pos.y)},${this.devNum(pos.z)}\", \"${this.devNum(rot.x)},${this.devNum(rot.y)},${this.devNum(rot.z)}\")`
            ].join("\n");
        }

        static logDebugCamera() {
            if (!Utils.isOptionValid("test")) return;
            console.log(this.makeDebugCameraText());
        }

        static debugCamera(position = null, rotation = null, lookAtModelKey = "", lookAtAdjustY = 0.8) {
            if (position === null && rotation === null && !this.stringTrim(lookAtModelKey)) {
                this.logDebugCamera();
                return true;
            }
            return this.debugSetCamera(position, rotation, lookAtModelKey, lookAtAdjustY, true);
        }

        static debugSetCamera(position = "", rotation = "", lookAtModelKey = "", lookAtAdjustY = 0.8, outputLog = true) {
            const cam = this._camera;
            if (!cam) return false;

            const pos = this.parseXYZ(position);
            const rot = this.parseXYZ(rotation);
            const lookKey = this.stringTrim(lookAtModelKey);
            const adjustY = Number.isFinite(Number(lookAtAdjustY)) ? Number(lookAtAdjustY) : 0.8;
            if (!pos && !rot && !lookKey) {
                if (outputLog) this.logDebugCamera();
                return true;
            }

            this.clearCameraMove();
            this.resetDevFreeCameraInput();

            if (pos) {
                cam.position.set(pos.x, pos.y, pos.z);
            }

            let syncTarget = null;
            if (lookKey) {
                syncTarget = this.getCameraLookAtTarget(lookKey, adjustY);
                if (syncTarget) {
                    cam.lookAt(syncTarget);
                    this.ensureDevCameraRotationOrder();
                }
            } else if (rot) {
                const q = this.makeCameraQuaternionFromDegrees(rot);
                this.applyCameraQuaternion(q);
            }

            cam.updateMatrixWorld(true);
            this.syncCameraControls(syncTarget);
            if (outputLog) this.logDebugCamera();
            return true;
        }

        static debugSetCameraPosition(position) {
            return this.debugSetCamera(position, "", "", 0.8, true);
        }

        static debugSetCameraRotation(rotation) {
            return this.debugSetCamera("", rotation, "", 0.8, true);
        }

        static startCameraMove(args) {
            const cam = this._camera;
            const three = SUND_MODS.THREE;
            if (!cam || !three) return;

            const target = this.resolveCameraMoveTarget(args);
            if (!target) return;

            const mode = this.normalizeCameraMoveMode(args.moveMode);
            const frames = this.positiveNumber(args.frame, 60);
            const lookAtModelKey = this.stringTrim(args.lookAtModelKey);
            const lookAtAdjustY = Number.isFinite(Number(args.lookAtAdjustY)) ? Number(args.lookAtAdjustY) : 0.8;
            const fadeFrames = this.positiveNumber(args.fadeFrames, 15);

            this.clearCameraMove();
            this.resetDevFreeCameraInput();

            if (mode === "instant") {
                this.applyCameraMoveTarget(target, mode, lookAtModelKey, lookAtAdjustY);
                return;
            }

            if (mode === "fadeInstant") {
                const m = this._cameraMove;
                m.fade = {
                    active: true,
                    phase: "out",
                    duration: fadeFrames,
                    remaining: fadeFrames,
                    target: target,
                    mode: mode,
                    lookAtModelKey: lookAtModelKey,
                    lookAtAdjustY: lookAtAdjustY,
                };
                if ($gameScreen && typeof $gameScreen.startFadeOut === "function") {
                    $gameScreen.startFadeOut(fadeFrames);
                }
                return;
            }

            this.ensureDevCameraRotationOrder();

            const m = this._cameraMove;
            const startRotDeg = this.makeCameraDisplayDegreesObject();
            m.active = true;
            m.mode = mode;
            m.totalFrames = frames;
            m.remainingFrames = frames;
            m.startPosition = cam.position.clone();
            m.goalPosition = new three.Vector3(target.position.x, target.position.y, target.position.z);
            m.startRotation = this.makeObjectXYZ(startRotDeg.x, startRotDeg.y, startRotDeg.z);
            m.goalRotation = this.makeObjectXYZ(target.rotationDeg.x, target.rotationDeg.y, target.rotationDeg.z);
            m.startQuaternion = cam.quaternion.clone();
            m.goalQuaternion = this.makeCameraQuaternionFromDegrees(target.rotationDeg);
            m.lookAtModelKey = lookAtModelKey;
            m.lookAtAdjustY = lookAtAdjustY;

            if (mode === "lookAt") {
                const lookTarget = this.getCameraLookAtTarget(lookAtModelKey, lookAtAdjustY);
                if (lookTarget) {
                    cam.lookAt(lookTarget);
                    this.applyCameraQuaternion(cam.quaternion.clone());
                    this.syncCameraControls(lookTarget);
                }
            }
        }

        static updateCameraFadeInstant() {
            const m = this._cameraMove;
            const fade = m ? m.fade : null;
            if (!fade || !fade.active) return false;

            fade.remaining--;
            if (fade.remaining > 0) return true;

            if (fade.phase === "out") {
                this.applyCameraMoveTarget(fade.target, fade.mode, fade.lookAtModelKey, fade.lookAtAdjustY);
                fade.phase = "in";
                fade.remaining = fade.duration;
                if ($gameScreen && typeof $gameScreen.startFadeIn === "function") {
                    $gameScreen.startFadeIn(fade.duration);
                }
                return true;
            }

            fade.active = false;
            this.clearCameraMove();
            return false;
        }

        static updateCameraMove() {
            const m = this._cameraMove;
            const cam = this._camera;
            if (!m || !cam) return;

            if (m.fade && m.fade.active) {
                this.updateCameraFadeInstant();
                return;
            }
            if (!m.active) return;

            const total = Math.max(1, Number(m.totalFrames || 1));
            const elapsed = total - Math.max(0, Number(m.remainingFrames || 0)) + 1;
            const t = Math.max(0, Math.min(1, elapsed / total));

            if (m.startPosition && m.goalPosition) {
                cam.position.copy(m.startPosition).lerp(m.goalPosition, t);
            }

            let syncTarget = null;
            if (m.mode === "lookAt") {
                syncTarget = this.getCameraLookAtTarget(m.lookAtModelKey, m.lookAtAdjustY);
                if (syncTarget) {
                    cam.lookAt(syncTarget);
                    this.applyCameraQuaternion(cam.quaternion.clone());
                }
            } else if (m.startQuaternion && m.goalQuaternion) {
                const q = m.startQuaternion.clone();
                q.slerp(m.goalQuaternion, t);
                this.applyCameraQuaternion(q);
            }

            cam.updateMatrixWorld(true);
            this.syncCameraControls(syncTarget);

            m.remainingFrames--;
            if (m.remainingFrames <= 0) {
                this.clearCameraMove();
            }
        }

        static resetDevFreeCameraInput() {
            this.resetDevFreeCameraOrbitInput();
            this.resetDevFreeCameraRotationInput();
            this.resetDevFreeCameraMiddleInput();
            this.resetDevFreeCameraRightInput();
        }

        static resetDevFreeCameraOrbitInput() {
            const dev = this._dev;
            if (!dev) return;
            dev.cameraOrbitDragging = false;
            dev.cameraOrbitLastX = 0;
            dev.cameraOrbitLastY = 0;
        }

        static resetDevFreeCameraRotationInput() {
            const dev = this._dev;
            if (!dev) return;
            dev.cameraDragging = false;
            dev.cameraLastX = 0;
            dev.cameraLastY = 0;
        }

        static resetDevFreeCameraMiddleInput() {
            const dev = this._dev;
            if (!dev) return;
            dev.cameraMiddlePressed = false;
            dev.cameraMiddleDragging = false;
            dev.cameraMiddleLastX = 0;
            dev.cameraMiddleLastY = 0;
            dev.cameraMiddleX = 0;
            dev.cameraMiddleY = 0;
        }

        static resetDevFreeCameraRightInput() {
            const dev = this._dev;
            if (!dev) return;
            dev.cameraRightPressed = false;
            dev.cameraRightDragging = false;
            dev.cameraRightLastX = 0;
            dev.cameraRightLastY = 0;
            dev.cameraRightX = 0;
            dev.cameraRightY = 0;
        }

        static ensureDevFreeCameraMouseListeners() {
            const dev = this._dev;
            if (!dev || dev.cameraMouseListenerReady) return;
            dev.cameraMouseListenerReady = true;

            const getX = (event) => {
                return typeof event.clientX === "number" ? event.clientX : event.pageX;
            };
            const getY = (event) => {
                return typeof event.clientY === "number" ? event.clientY : event.pageY;
            };
            const shouldHandleFreeCameraMouse = () => {
                try {
                    return !!(
                        this.isCameraControlMode() &&
                        !Input.isPressed("shift") &&
                        !this.isMouseHoverBoneDevMode()
                    );
                } catch (_) {
                    return false;
                }
            };
            const stopCameraMouse = (event) => {
                if (event.cancelable) {
                    event.preventDefault();
                }
                if (typeof event.stopImmediatePropagation === "function") {
                    event.stopImmediatePropagation();
                } else if (typeof event.stopPropagation === "function") {
                    event.stopPropagation();
                }
            };

            document.addEventListener("mousedown", (event) => {
                if (!shouldHandleFreeCameraMouse()) return;

                if (event.button === 1) {
                    stopCameraMouse(event);
                    dev.cameraMiddlePressed = true;
                    dev.cameraMiddleDragging = false;
                    dev.cameraMiddleX = getX(event);
                    dev.cameraMiddleY = getY(event);
                    dev.cameraMiddleLastX = dev.cameraMiddleX;
                    dev.cameraMiddleLastY = dev.cameraMiddleY;
                } else if (event.button === 2) {
                    stopCameraMouse(event);
                    dev.cameraRightPressed = true;
                    dev.cameraRightDragging = false;
                    dev.cameraRightX = getX(event);
                    dev.cameraRightY = getY(event);
                    dev.cameraRightLastX = dev.cameraRightX;
                    dev.cameraRightLastY = dev.cameraRightY;
                }
            }, true);

            document.addEventListener("mousemove", (event) => {
                if (dev.cameraMiddlePressed) {
                    if ((event.buttons & 4) === 0) {
                        this.resetDevFreeCameraMiddleInput();
                    } else {
                        stopCameraMouse(event);
                        dev.cameraMiddleX = getX(event);
                        dev.cameraMiddleY = getY(event);
                    }
                }

                if (dev.cameraRightPressed) {
                    if ((event.buttons & 2) === 0) {
                        this.resetDevFreeCameraRightInput();
                    } else {
                        stopCameraMouse(event);
                        dev.cameraRightX = getX(event);
                        dev.cameraRightY = getY(event);
                    }
                }
            }, true);

            document.addEventListener("mouseup", (event) => {
                if (event.button === 1) {
                    if (shouldHandleFreeCameraMouse()) {
                        stopCameraMouse(event);
                    }
                    this.resetDevFreeCameraMiddleInput();
                } else if (event.button === 2) {
                    if (shouldHandleFreeCameraMouse()) {
                        stopCameraMouse(event);
                    }
                    this.resetDevFreeCameraRightInput();
                }
            }, true);

            document.addEventListener("auxclick", (event) => {
                if (event.button !== 1 && event.button !== 2) return;
                if (!shouldHandleFreeCameraMouse()) return;
                stopCameraMouse(event);
            }, true);

            document.addEventListener("contextmenu", (event) => {
                if (!shouldHandleFreeCameraMouse()) return;
                if (!dev.cameraRightPressed && event.button !== 2) return;
                stopCameraMouse(event);
            }, true);

            window.addEventListener("blur", () => {
                this.resetDevFreeCameraMiddleInput();
                this.resetDevFreeCameraRightInput();
            });
        }

        static ensureDevCameraRotationOrder() {
            const cam = this._camera;
            if (!cam || !cam.rotation) return;
            if (cam.rotation.order !== "YXZ" && typeof cam.rotation.reorder === "function") {
                cam.rotation.reorder("YXZ");
            } else if (cam.rotation.order !== "YXZ") {
                cam.rotation.order = "YXZ";
            }
        }

        static updateDevCamera() {
            if (this._controls) {
                // OrbitControlsはターゲット中心の操作なので、原点付近や一定距離で移動が詰まることがある。
                // 開発モードのカメラは直接操作にして、注視点や距離制限に引っ張られないようにする。
                this._controls.enabled = false;
            }
            if (!this.isCameraControlMode() || !this._camera || !SUND_MODS.THREE) {
                this.resetDevFreeCameraInput();
                return;
            }
            if (Input.isPressed("shift") || this.isMouseHoverBoneDevMode()) {
                // Shift中はモデル操作を優先。MouseHoverBoneの開発モード中もカメラ操作は止める。
                this.resetDevFreeCameraInput();
                return;
            }

            this.ensureDevCameraRotationOrder();
            this.ensureDevFreeCameraMouseListeners();

            const isMiddlePanning = this.updateDevFreeCameraPanByMiddleMouse();
            if (isMiddlePanning) {
                this.resetDevFreeCameraOrbitInput();
                this.resetDevFreeCameraRotationInput();
            } else {
                const isOrbiting = this.updateDevOrbitCameraByLeftMouse();
                if (isOrbiting) {
                    this.resetDevFreeCameraRotationInput();
                } else {
                    this.updateDevFreeCameraRotation();
                }
            }
            this.updateDevFreeCameraMove();
        }

        static updateDevFreeCameraPanByMiddleMouse() {
            const cam = this._camera;
            const dev = this._dev;
            const three = SUND_MODS.THREE;
            if (!cam || !dev || !three) return false;
            if (!dev.cameraMiddlePressed) {
                dev.cameraMiddleDragging = false;
                return false;
            }

            const x = dev.cameraMiddleX;
            const y = dev.cameraMiddleY;
            if (!dev.cameraMiddleDragging) {
                dev.cameraMiddleDragging = true;
                dev.cameraMiddleLastX = x;
                dev.cameraMiddleLastY = y;
                return true;
            }

            const dx = x - dev.cameraMiddleLastX;
            const dy = y - dev.cameraMiddleLastY;
            dev.cameraMiddleLastX = x;
            dev.cameraMiddleLastY = y;
            if (dx === 0 && dy === 0) return true;

            cam.updateMatrixWorld(true);

            const right = new three.Vector3();
            const screenUp = new three.Vector3();
            right.setFromMatrixColumn(cam.matrixWorld, 0).normalize();
            screenUp.setFromMatrixColumn(cam.matrixWorld, 1).normalize();

            // 中央ボタンでドラッグした方向へ、カメラを画面平面に沿って移動する。
            const panSpeed = 0.005;
            const move = new three.Vector3(0, 0, 0);
            move.addScaledVector(right, dx * panSpeed);
            move.addScaledVector(screenUp, -dy * panSpeed);

            if (move.lengthSq() > 0) {
                cam.position.add(move);
                cam.updateMatrixWorld(true);
            }
            return true;
        }

        static getVisibleDevModelEntries() {
            const entries = [];
            $sundVRMs.forEach((obj, key) => {
                if (obj && obj._vrm && obj.visible && obj.visible()) {
                    entries.push({ key: String(key), obj });
                }
            });
            return entries;
        }

        static getDevModelCenter(obj) {
            const three = SUND_MODS.THREE;
            const center = new three.Vector3(0, 0, 0);
            if (!obj || !obj._vrm || !obj._vrm.scene) return center;

            const scene = obj._vrm.scene;
            try {
                const box = new three.Box3().setFromObject(scene);
                if (
                    Number.isFinite(box.min.x) && Number.isFinite(box.min.y) && Number.isFinite(box.min.z) &&
                    Number.isFinite(box.max.x) && Number.isFinite(box.max.y) && Number.isFinite(box.max.z)
                ) {
                    box.getCenter(center);
                    return center;
                }
            } catch (_) { }

            if (typeof scene.getWorldPosition === "function") {
                scene.getWorldPosition(center);
            } else {
                center.copy(scene.position);
            }
            center.y += 1.0;
            return center;
        }

        static chooseDevOrbitTargetEntry(entries) {
            if (!entries || entries.length === 0) return null;
            const cam = this._camera;
            const three = SUND_MODS.THREE;
            if (!cam || !three) return entries[0];

            cam.updateMatrixWorld(true);
            const forward = new three.Vector3();
            cam.getWorldDirection(forward);
            forward.normalize();

            let best = entries[0];
            let bestScore = Infinity;
            entries.forEach((entry) => {
                const center = this.getDevModelCenter(entry.obj);
                const toTarget = center.clone().sub(cam.position);
                const distance = Math.max(0.0001, toTarget.length());
                const directionScore = 1 - Math.max(-1, Math.min(1, toTarget.clone().normalize().dot(forward)));
                let screenScore = 0;
                try {
                    const projected = center.clone().project(cam);
                    if (Number.isFinite(projected.x) && Number.isFinite(projected.y) && Number.isFinite(projected.z)) {
                        screenScore = projected.x * projected.x + projected.y * projected.y;
                    }
                } catch (_) { }
                const score = screenScore + directionScore * 0.5 + distance * 0.001;
                if (score < bestScore) {
                    best = entry;
                    bestScore = score;
                }
            });
            return best;
        }

        static getDevOrbitTargetInfo(preferLocked = true) {
            const dev = this._dev;
            const entries = this.getVisibleDevModelEntries();
            if (!dev || entries.length === 0) {
                if (dev) dev.cameraOrbitTargetKey = "";
                return null;
            }

            let entry = null;
            if (preferLocked && dev.cameraOrbitTargetKey) {
                entry = entries.find((item) => item.key === dev.cameraOrbitTargetKey) || null;
            }
            if (!entry) {
                entry = this.chooseDevOrbitTargetEntry(entries);
            }
            if (!entry) {
                dev.cameraOrbitTargetKey = "";
                return null;
            }

            dev.cameraOrbitTargetKey = entry.key;
            return {
                key: entry.key,
                obj: entry.obj,
                position: this.getDevModelCenter(entry.obj),
            };
        }

        static updateDevOrbitCameraByLeftMouse() {
            const cam = this._camera;
            const dev = this._dev;
            const three = SUND_MODS.THREE;
            if (!cam || !dev || !three) return false;

            // TouchInput.isPressed() は基本的に左クリック/タッチ用。
            // 左ドラッグ中だけ、対象モデルを中心にカメラを周回させる。
            // 重要：押し始めの瞬間には camera.position / rotation を変更しない。
            // 現在のカメラ座標を基準にして、実際にドラッグ量が出た時だけ周回移動する。
            if (!TouchInput.isPressed()) {
                this.resetDevFreeCameraOrbitInput();
                return false;
            }

            const targetInfo = this.getDevOrbitTargetInfo(true);
            if (!targetInfo) {
                this.resetDevFreeCameraOrbitInput();
                return false;
            }

            const x = TouchInput._x;
            const y = TouchInput._y;
            if (!dev.cameraOrbitDragging) {
                dev.cameraOrbitDragging = true;
                dev.cameraOrbitLastX = x;
                dev.cameraOrbitLastY = y;

                // ここで lookAt() や cam.position.copy() を行うと、クリック開始時にカメラが飛んで見える。
                // 初回は入力状態の初期化だけにして、現在座標・現在向きを完全に維持する。
                return true;
            }

            const dx = x - dev.cameraOrbitLastX;
            const dy = y - dev.cameraOrbitLastY;
            dev.cameraOrbitLastX = x;
            dev.cameraOrbitLastY = y;
            if (dx === 0 && dy === 0) return true;

            const target = targetInfo.position;
            const offset = cam.position.clone().sub(target);
            if (offset.lengthSq() <= 0.000001) {
                // ターゲットと完全に同座標だと周回半径を作れないため、
                // 現在の視線方向の反対側に最小距離だけ置く。
                const back = new three.Vector3(0, 0, 1);
                back.applyQuaternion(cam.quaternion);
                offset.copy(back.multiplyScalar(0.1));
            }

            const sensitivity = 0.0035;
            const yawAngle = -dx * sensitivity;
            const pitchAngle = -dy * sensitivity;

            cam.updateMatrixWorld(true);

            // 重要：ここでは cam.lookAt(target) を使わない。
            // lookAt() を使うと、ドラッグ開始直後にカメラの向きがモデル中心へ吸われ、
            // 「向きが瞬間変更された」ように見える。
            // そのため、現在のカメラ姿勢をそのままワールド回転で動かす。
            const yawAxis = new three.Vector3(0, 1, 0);
            const yawQ = new three.Quaternion().setFromAxisAngle(yawAxis, yawAngle);

            const rightAxis = new three.Vector3();
            rightAxis.setFromMatrixColumn(cam.matrixWorld, 0).normalize();
            rightAxis.applyQuaternion(yawQ).normalize();
            const pitchQ = new three.Quaternion().setFromAxisAngle(rightAxis, pitchAngle);

            const deltaQ = pitchQ.clone().multiply(yawQ);
            offset.applyQuaternion(deltaQ);

            cam.position.copy(target).add(offset);
            const nextQ = cam.quaternion.clone().premultiply(deltaQ).normalize();
            this.applyCameraQuaternion(nextQ);
            this.syncCameraControls();
            cam.updateMatrixWorld(true);
            return true;
        }

        static updateDevFreeCameraRotation() {
            const cam = this._camera;
            const dev = this._dev;
            if (!cam || !dev) return;

            let x = 0;
            let y = 0;
            let active = false;

            // 右クリックドラッグは、カメラの現在位置を固定した自由回転として扱う。
            if (dev.cameraRightPressed) {
                x = dev.cameraRightX;
                y = dev.cameraRightY;
                active = true;
            }

            if (!active) {
                this.resetDevFreeCameraRotationInput();
                return;
            }

            if (!dev.cameraDragging) {
                dev.cameraDragging = true;
                dev.cameraLastX = x;
                dev.cameraLastY = y;
                return;
            }

            const dx = x - dev.cameraLastX;
            const dy = y - dev.cameraLastY;
            dev.cameraLastX = x;
            dev.cameraLastY = y;
            if (dx === 0 && dy === 0) return;

            const util = SUND_MODS.THREE.MathUtils;
            const sensitivity = 0.0035;
            cam.rotation.y -= dx * sensitivity;
            cam.rotation.x -= dy * sensitivity;

            // 真上・真下付近で反転しないよう、ほぼ垂直までに制限する。
            const maxPitch = util.degToRad(89.5);
            cam.rotation.x = Math.max(-maxPitch, Math.min(maxPitch, cam.rotation.x));
            // 内部Eulerは右ドラッグ操作の安定性のためrollを0に保つ。
            // HUD/コピー/コマンド用のZ値は makeCameraDisplayDegreesObject() でXYZ表現へ変換して表示する。
            cam.rotation.z = 0;
            cam.updateMatrixWorld(true);
        }

        static updateDevFreeCameraMove() {
            const cam = this._camera;
            const three = SUND_MODS.THREE;
            if (!cam || !three) return;

            const move = new three.Vector3(0, 0, 0);
            const forward = new three.Vector3();
            const right = new three.Vector3();
            const up = new three.Vector3(0, 1, 0);
            cam.getWorldDirection(forward);
            forward.normalize();
            right.crossVectors(forward, cam.up).normalize();

            const frameScale = Math.max(0.25, Math.min(3, (SUND_VRM.deltaTime || (1 / 60)) * 60));
            const amount = 0.08 * frameScale;

            if (Input.isPressed("up")) move.addScaledVector(forward, amount);
            if (Input.isPressed("down")) move.addScaledVector(forward, -amount);
            if (Input.isPressed("left")) move.addScaledVector(right, -amount);
            if (Input.isPressed("right")) move.addScaledVector(right, amount);

            // Ctrl+PgUp/PgDnはコピー操作に使うため、Ctrl中は上下移動しない。
            if (!Input.isPressed("control")) {
                if (Input.isPressed("pageup")) move.addScaledVector(up, amount);
                if (Input.isPressed("pagedown")) move.addScaledVector(up, -amount);
            }

            if (TouchInput.wheelY !== 0) {
                const wheelAmount = amount * Math.max(1, Math.min(6, Math.abs(TouchInput.wheelY) / 100));
                move.addScaledVector(forward, TouchInput.wheelY < 0 ? wheelAmount : -wheelAmount);
            }

            if (move.lengthSq() > 0) {
                cam.position.add(move);
                cam.updateMatrixWorld(true);
            }
        }

        static updateDevCameraInformation() {
            if (!this.isCameraControlMode()) return;
            if (!Input.isPressed("control")) return;

            const cam = this._camera;
            if (Input.isTriggered("pageup")) {
                try {
                    this.copyClipboard(this.devNum(cam.position.x) + "," + this.devNum(cam.position.y) + "," + this.devNum(cam.position.z));
                } catch { }
                //console.log(`==== [camera] ====`);
                //console.log(`position: x:${this.devNum(cam.position.x)}, y:${this.devNum(cam.position.y)}, z:${this.devNum(cam.position.z)}`);
            } else if (Input.isTriggered("pagedown")) {
                const r = this.makeCameraDisplayDegreesObject();
                try {
                    this.copyClipboard(this.devNum(r.x) + "," + this.devNum(r.y) + "," + this.devNum(r.z));
                } catch { }
                //console.log(`==== [camera] ====`);
                //console.log(`rotation: x:${this.devNum(rX)}, y:${this.devNum(rY)}, z:${this.devNum(rZ)}`);
            }
        }

        static copyClipboard(str) {
            if (!Utils.isOptionValid('test')) return;
            navigator.clipboard.writeText(str);
        }

        static clearThreeSprite() {
            if (!this._threeSprite) return;

            const sprite = this._threeSprite;
            if (sprite.visible) {
                if (sprite.bitmap) {
                    sprite.bitmap.clear();
                }
                sprite.visible = false;
            }
        }

        static drawThreeSprite() {
            // threeのcanvasは背面に隠されている。bltコピー
            if (!this._threeSprite) return;

            const sprite = this._threeSprite;
            const bitmap = sprite.bitmap;
            if (!bitmap) return;

            sprite.visible = true;
            bitmap.clear();
            const w = Graphics.width;
            const h = Graphics.height;
            bitmap.blt({ _canvas: this._renderer.domElement }, 0, 0, w, h, 0, 0);
        }

        static updateAutoMouth() {
            if (this._autoMouth.duration <= 0 || this._autoMouth.targets.length === 0) return;
            const m = this._autoMouth;

            const duration = --m.duration;
            const isRandom = duration % 4 === 0 && duration > 0;
            const isReset = duration <= 0;

            m.targets.forEach((el) => {
                const obj = $sundVRMs.get(el);
                if (obj) {
                    if (isRandom) {
                        obj.setRandomMouth();
                    } else if (isReset) {
                        obj.resetMouth();
                    }
                }
            });
        }

        static stopAutoMouth() {
            const m = this._autoMouth;
            m.duration = 0;
            const targets = [...m.targets];
            targets.forEach((el) => {
                const obj = $sundVRMs.get(el);
                if (obj) {
                    obj.resetMouth();
                }
            });
        }

        static setSaveData() {
            if (!params.useSave) return;

            const saveArr = [];
            $sundVRMs.forEach((el) => {
                const scene = el._vrm.scene;
                const m = el._motion;
                const obj = {
                    keyName: el._keyName,
                    position: this.makeObjectXYZ(),
                    rotation: this.makeObjectXYZ(),
                    visible: scene.visible,
                    motion: {
                        current: { name: m.current.name, loop: m.current.loop, speed: m.current.speed, fadeFrames: m.current.fadeFrames },
                        next: { name: m.next.name, loop: m.next.loop, speed: m.next.speed, fadeFrames: m.next.fadeFrames },
                        state: m.state,
                    },
                };
                this.assignmentXYZ(obj.position, scene.position);
                this.assignmentXYZ(obj.rotation, scene.rotation);
                saveArr.push(obj);
            });
            $gameParty._sundVRM.modelSaveData = saveArr;

            // カメラはここから完全に「フリーカメラ座標」を正とする。
            // position : three.js camera.position のワールド座標
            // rotation : プラグインコマンド / HUD / コピー値と同じ XYZ 度数表現
            // 旧版は rotation に内部Eulerラジアンを保存していたため、coordinateMode で新旧を判別する。
            const cameraData = $gameParty._sundVRM.cameraSaveData || {};
            const camera = SUND_VRM._camera;
            const rotationDeg = this.makeCameraDisplayDegreesObject();
            cameraData.coordinateMode = "free";
            cameraData.position = this.makeObjectXYZ(camera.position.x, camera.position.y, camera.position.z);
            cameraData.rotation = this.makeObjectXYZ(rotationDeg.x, rotationDeg.y, rotationDeg.z);
            cameraData.rotationDeg = this.makeObjectXYZ(rotationDeg.x, rotationDeg.y, rotationDeg.z);
            $gameParty._sundVRM.cameraSaveData = cameraData;
        }

        static makeCameraForwardTarget(distance = 1) {
            const cam = this._camera;
            const three = SUND_MODS.THREE;
            if (!cam || !three) return null;

            const target = new three.Vector3(0, 0, -1);
            target.applyQuaternion(cam.quaternion);
            target.multiplyScalar(Math.max(0.001, Number(distance || 1)));
            target.add(cam.position);
            return target;
        }

        static syncCameraControls(target = null) {
            const cam = this._camera;
            const controls = this._controls;
            const three = SUND_MODS.THREE;
            if (!cam || !controls || !three) return;

            // 重要：フリーカメラでは OrbitControls を座標の正にしない。
            // controls.update() は target 基準で camera を再計算し、直接指定した position / quaternion を
            // 別基準へ引き戻す原因になるため、ここでは target の同期だけを行う。
            controls.enabled = false;

            let nextTarget = null;
            if (target && typeof target.clone === "function") {
                nextTarget = target.clone();
            } else {
                nextTarget = this.makeCameraForwardTarget(1);
            }

            if (nextTarget && controls.target && typeof controls.target.copy === "function") {
                controls.target.copy(nextTarget);
            }
            if (typeof controls.saveState === "function") {
                controls.saveState();
            }
        }

        static restoreCameraData() {
            this.clearCameraMove();
            const data = $gameParty._sundVRM.cameraSaveData;
            const cam = SUND_VRM._camera;
            if (!data || !cam) return;

            if (data.position) {
                SUND_VRM.assignmentXYZ(cam.position, data.position);
            }

            // 新形式：rotation / rotationDeg は、プラグインコマンドと同じ XYZ 度数表現。
            // 旧形式：coordinateMode が無い場合は、従来どおり内部Eulerラジアンとして読む。
            const isFreeMode = data.coordinateMode === "free" || !!data.rotationDeg;
            if (isFreeMode) {
                const rot = data.rotationDeg || data.rotation || this.makeObjectXYZ();
                const q = this.makeCameraQuaternionFromDegrees(rot);
                this.applyCameraQuaternion(q);
            } else if (data.rotation) {
                const rot = data.rotation;
                this.ensureDevCameraRotationOrder();
                cam.rotation.set(Number(rot.x || 0), Number(rot.y || 0), Number(rot.z || 0));
                cam.updateMatrixWorld(true);
            }

            this.syncCameraControls();
        }

        static allHide() {
            $sundVRMs.forEach((el) => {
                el.hide();
            });
        }
        static allShow() {
            $sundVRMs.forEach((el) => {
                el.show();
            });
        }

        static makeObjectXYZ(x = 0, y = 0, z = 0) {
            return { x: x, y: y, z: z };
        }

        static assignmentXYZ(to, from) {
            to.x = from.x;
            to.y = from.y;
            to.z = from.z;
        }

        static stringTrim(key) {
            return ("" + key).trim();
        }

        static convertVariableEscapeText(value) {
            let text = this.stringTrim(value);
            if (!text) return "";
            text = text.replace(/\\\\[Vv]\[(\d+)\]/g, (_match, variableId) => {
                return this.variableValueText(variableId);
            });
            text = text.replace(/\\[Vv]\[(\d+)\]/g, (_match, variableId) => {
                return this.variableValueText(variableId);
            });
            return text;
        }

        static variableValueText(variableId) {
            const id = Number(variableId || 0);
            if (!Number.isFinite(id) || id <= 0 || !$gameVariables) return "";
            const value = $gameVariables.value(id);
            if (value === undefined || value === null) return "";
            return this.stringTrim(value);
        }

        static resolveExpressionKey(expression, variableId) {
            const id = Number(variableId || 0);
            if (Number.isFinite(id) && id > 0) {
                const fromVariable = this.convertVariableEscapeText(this.variableValueText(id));
                if (fromVariable) return this.resolveExpressionAlias(fromVariable);
            }
            return this.resolveExpressionAlias(this.convertVariableEscapeText(expression));
        }

        static resolveNumberValue(value, variableId) {
            const id = Number(variableId || 0);
            let text = "";
            if (Number.isFinite(id) && id > 0) {
                text = this.convertVariableEscapeText(this.variableValueText(id));
            }
            if (!text) {
                text = this.convertVariableEscapeText(value);
            }
            const number = Number(text);
            return Number.isFinite(number) ? number : NaN;
        }

        static clampNumber(value, min, max) {
            const number = Number(value);
            if (!Number.isFinite(number)) return min;
            return Math.max(min, Math.min(max, number));
        }

        static boolValue(value, defaultValue = false) {
            if (value === undefined || value === null || value === "") return defaultValue;
            if (value === true || value === false) return value;
            const text = this.stringTrim(value).toLowerCase();
            if (text === "true" || text === "on" || text === "1") return true;
            if (text === "false" || text === "off" || text === "0") return false;
            return defaultValue;
        }

        static resolveOptionalNumberValue(value, variableId) {
            const id = Number(variableId || 0);
            if (Number.isFinite(id) && id > 0) {
                const fromVariable = this.resolveNumberValue("", id);
                return Number.isFinite(fromVariable) ? fromVariable : null;
            }
            const text = this.convertVariableEscapeText(value);
            if (text === "") return null;
            const number = Number(text);
            return Number.isFinite(number) ? number : null;
        }

        static lightIntensityValue(value) {
            const number = Number(value);
            if (!Number.isFinite(number)) return null;
            return this.clampNumber(number, 0, 10);
        }

        static resolveInitialLightNumber(value, defaultValue) {
            const number = this.resolveOptionalNumberValue(value, 0);
            if (number === null) return defaultValue;
            return this.lightIntensityValue(number);
        }

        static resolveInitialLightPosition(value) {
            const position = this.parseXYZ(value);
            return position || this.makeObjectXYZ(1.0, 1.0, 1.0);
        }

        static warnExternalConfig(message, error = null) {
            try {
                if (Utils && Utils.isOptionValid && Utils.isOptionValid("test")) {
                    if (error) {
                        console.warn(`[SunD_VRM] ${message}`, error);
                    } else {
                        console.warn(`[SunD_VRM] ${message}`);
                    }
                }
            } catch (_) { }
        }

        static normalizeExternalConfigPath(fileName) {
            const text = this.stringTrim(fileName);
            if (!text) return "";
            return text.replace(/\\/g, "/").replace(/^\/+/, "");
        }

        static loadExternalConfigFile(fileName) {
            const url = this.normalizeExternalConfigPath(fileName);
            if (!url) return null;

            try {
                const xhr = new XMLHttpRequest();
                xhr.open("GET", url, false);
                if (xhr.overrideMimeType) {
                    xhr.overrideMimeType("application/json");
                }
                xhr.send();

                const okStatus = xhr.status === 0 || (xhr.status >= 200 && xhr.status < 400);
                if (!okStatus || !xhr.responseText) {
                    this.warnExternalConfig(`外部設定JSONを読み込めませんでした: ${url}`);
                    return null;
                }

                return JSON.parse(xhr.responseText);
            } catch (e) {
                this.warnExternalConfig(`外部設定JSONの読み込み/解析に失敗しました: ${url}`, e);
                return null;
            }
        }

        static applyExternalConfigFile(fileName) {
            const config = this.loadExternalConfigFile(fileName);
            if (config) {
                this.applyExternalConfig(config);
            }
        }

        static configArray(config, names) {
            for (const name of names) {
                const value = config ? config[name] : null;
                if (value === undefined || value === null) continue;
                if (Array.isArray(value)) return value;
                if (typeof value === "object") {
                    return Object.keys(value).map((key) => {
                        const item = value[key];
                        if (item !== null && typeof item === "object" && !Array.isArray(item)) {
                            return Object.assign({ keyName: key }, item);
                        }
                        return { keyName: key, value: item };
                    });
                }
            }
            return [];
        }

        static configText(value) {
            if (Array.isArray(value)) return value.join(",");
            return this.stringTrim(value);
        }

        static configXYZ(value) {
            if (Array.isArray(value) && value.length >= 3) {
                const x = Number(value[0]);
                const y = Number(value[1]);
                const z = Number(value[2]);
                if ([x, y, z].every(Number.isFinite)) {
                    return this.makeObjectXYZ(x, y, z);
                }
                return null;
            }
            if (value && typeof value === "object") {
                const x = Number(value.x);
                const y = Number(value.y);
                const z = Number(value.z);
                if ([x, y, z].every(Number.isFinite)) {
                    return this.makeObjectXYZ(x, y, z);
                }
            }
            return this.parseXYZ(this.configText(value));
        }

        static configKey(item) {
            return this.stringTrim(item && (item.keyName || item.key || item.name || item.id));
        }

        static applyExternalConfig(config) {
            const root = (config && (config.SunD_VRM || config.sundVrm || config.sund_vrm)) || config;
            if (!root || typeof root !== "object") return;

            this.applyExternalModels(this.configArray(root, ["models", "vrms", "vrmList"]));
            this.applyExternalMotions(this.configArray(root, ["motions", "vrmas", "vrmaList"]));
            this.applyExternalPositions(this.configArray(root, ["positions", "positionList"]));
            this.applyExternalDirections(this.configArray(root, ["directions", "directionList", "rotations"]));
            this.applyExternalCameras(this.configArray(root, ["cameras", "cameraList"]));
            this.applyExternalExpressionAliases(this.configArray(root, ["expressions", "expressionAliases", "expressionList"]));
        }

        static applyExternalModels(list) {
            list.forEach((item) => {
                if (!item) return;
                const key = this.configKey(item);
                const fileName = this.stringTrim(item.fileName || item.file || item.path || item.vrm || item.value);
                if (!key || !fileName) return;

                this._params.vrmMap.set(key, fileName);

                if (item.preLoad !== undefined || item.preload !== undefined || item.load !== undefined) {
                    const preLoad = this.boolValue(
                        item.preLoad !== undefined ? item.preLoad : (item.preload !== undefined ? item.preload : item.load),
                        true
                    );
                    if (preLoad) {
                        this._params.loadModels.add(key);
                    } else {
                        this._params.loadModels.delete(key);
                    }
                }
            });
        }

        static applyExternalMotions(list) {
            list.forEach((item) => {
                if (!item) return;
                const key = this.configKey(item);
                const fileName = this.stringTrim(item.fileName || item.file || item.path || item.vrma || item.motion || item.value);
                if (!key || !fileName) return;
                this._params.vrmaMap.set(key, fileName);
            });
        }

        static applyExternalPositions(list) {
            list.forEach((item) => {
                if (!item) return;
                const key = this.configKey(item);
                const value = item.position !== undefined ? item.position : item.value;
                const pos = this.configXYZ(value !== undefined ? value : item);
                if (!key || !pos) return;
                this._params.positionMap.set(key, pos);
            });
        }

        static applyExternalDirections(list) {
            list.forEach((item) => {
                if (!item) return;
                const key = this.configKey(item);
                const raw = item.rotationY !== undefined ? item.rotationY
                    : (item.y !== undefined ? item.y
                    : (item.rotation !== undefined ? item.rotation : item.value));
                const value = Number(raw);
                if (!key || !Number.isFinite(value)) return;
                this._params.directionMap.set(key, value);
            });
        }

        static applyExternalCameras(list) {
            list.forEach((item) => {
                if (!item) return;
                const key = this.configKey(item);
                const position = this.configXYZ(item.position);
                const rotation = this.configXYZ(item.rotation);
                if (!key || !position || !rotation) return;
                this._params.cameraMap.set(key, { position, rotation });
            });
        }

        static registerRuntimePosition(keyName, position) {
            const key = this.stringTrim(keyName);
            const pos = this.configXYZ(position);
            if (!key || !pos) {
                this.warnExternalConfig(`ポジション登録に失敗しました: key=${keyName}, position=${position}`);
                return false;
            }
            this._params.positionMap.set(key, pos);
            return true;
        }

        static registerRuntimeDirection(keyName, rotationY) {
            const key = this.stringTrim(keyName);
            const value = Number(rotationY);
            if (!key || !Number.isFinite(value)) {
                this.warnExternalConfig(`向き登録に失敗しました: key=${keyName}, rotationY=${rotationY}`);
                return false;
            }
            this._params.directionMap.set(key, value);
            return true;
        }

        static registerRuntimeCamera(keyName, position, rotation) {
            const key = this.stringTrim(keyName);
            const pos = this.configXYZ(position);
            const rot = this.configXYZ(rotation);
            if (!key || !pos || !rot) {
                this.warnExternalConfig(`カメラ登録に失敗しました: key=${keyName}, position=${position}, rotation=${rotation}`);
                return false;
            }
            this._params.cameraMap.set(key, { position: pos, rotation: rot });
            return true;
        }

        static warnMissingPositionKey(key) {
            this.warnExternalConfig(`ポジションキーが未登録です: ${key}。Command Tool側で作成した位置が外部JSONに保存され、SunD_VRM.jsから読み込まれているか確認してください。`);
        }

        static warnMissingDirectionKey(key) {
            this.warnExternalConfig(`向きキーが未登録です: ${key}。Command Tool側で作成した向きが外部JSONに保存され、SunD_VRM.jsから読み込まれているか確認してください。`);
        }

        static warnMissingCameraKey(key) {
            this.warnExternalConfig(`カメラキーが未登録です: ${key}。Command Tool側で作成したカメラが外部JSONに保存され、SunD_VRM.jsから読み込まれているか確認してください。`);
        }

        static applyExternalExpressionAliases(list) {
            list.forEach((item) => {
                if (item === null || item === undefined) return;

                if (typeof item === "string") {
                    const key = this.stringTrim(item);
                    if (key) this._params.expressionAliasMap.set(key, key);
                    return;
                }

                const key = this.configKey(item);
                const expressionKey = this.stringTrim(
                    item.expressionKey || item.expression || item.target || item.keyValue || item.value || key
                );
                if (!key || !expressionKey) return;
                this._params.expressionAliasMap.set(key, expressionKey);
            });
        }

        static resolveExpressionAlias(expression) {
            const key = this.stringTrim(expression);
            if (!key) return "";
            const alias = this._params.expressionAliasMap.get(key);
            return this.stringTrim(alias || key);
        }

        static applyVRMLightSettings() {
            const lightPosition = this._params.lightPosition || this.makeObjectXYZ(1.0, 1.0, 1.0);

            if (this._light) {
                this._light.intensity = this._params.directionalLightIntensity;
                this._light.position.set(lightPosition.x, lightPosition.y, lightPosition.z);
                this._light.updateMatrixWorld(true);
            }

            if (this._ambientLight) {
                this._ambientLight.intensity = this._params.ambientLightIntensity;
                this._ambientLight.updateMatrixWorld(true);
            }
        }

        static setVRMLight(args) {
            const dirRaw = this.resolveOptionalNumberValue(args.directionalLightIntensity, args.directionalLightIntensityVariableId);
            const ambRaw = this.resolveOptionalNumberValue(args.ambientLightIntensity, args.ambientLightIntensityVariableId);
            const lightPosition = this.parseXYZ(this.convertVariableEscapeText(args.lightPosition));

            if (dirRaw !== null) {
                const dir = this.lightIntensityValue(dirRaw);
                if (dir !== null) this._params.directionalLightIntensity = dir;
            }

            if (ambRaw !== null) {
                const amb = this.lightIntensityValue(ambRaw);
                if (amb !== null) this._params.ambientLightIntensity = amb;
            }

            if (lightPosition) {
                this._params.lightPosition = lightPosition;
            }

            this.applyVRMLightSettings();

            if (this.boolValue(args.outputLog, false) && Utils.isOptionValid("test")) {
                const p = this._params.lightPosition;
                console.log(
                    `[SUND_VRM light] directional=${this._params.directionalLightIntensity}, ambient=${this._params.ambientLightIntensity}, position=${this.devNum(p.x)},${this.devNum(p.y)},${this.devNum(p.z)}`
                );
            }
        }

        static resolveModelKeys(modelKey, variableId) {
            const id = Number(variableId || 0);
            let text = "";
            if (Number.isFinite(id) && id > 0) {
                text = this.convertVariableEscapeText(this.variableValueText(id));
            }
            if (!text) {
                text = this.convertVariableEscapeText(modelKey);
            }
            if (!text) return [];
            return this.modelKeyToArray(text);
        }

        static devNum(value) {
            return Math.round(value * 100) / 100;
        }

        static rotationWork180(value) {
            if (value > 180) {
                return -180 + (value - 180);
            } else if (value < -180) {
                return 180 + (value + 180);
            }
            return value;
        }

        static getRotationDegY(rotation) {
            const util = SUND_MODS.THREE.MathUtils;
            if (rotation.x <= -3.14) {
                if (rotation.y >= 0) {
                    return 180 - util.radToDeg(rotation.y);
                } else {
                    return -180 - util.radToDeg(rotation.y);
                }
            }
            return util.radToDeg(rotation.y);
        }

        static makeDegreesObject(radiansObj) {
            const obj = Object.assign({}, radiansObj);
            const util = SUND_MODS.THREE.MathUtils;
            obj.x = util.radToDeg(obj.x);
            obj.y = util.radToDeg(obj.y);
            obj.z = util.radToDeg(obj.z);
            return obj;
        }

        static makeRadiansObject(degreesObj) {
            const obj = Object.assign({}, degreesObj);
            const util = SUND_MODS.THREE.MathUtils;
            obj.x = util.degToRad(obj.x);
            obj.y = util.degToRad(obj.y);
            obj.z = util.degToRad(obj.z);
            return obj;
        }

        static makeCameraDisplayDegreesObject() {
            const three = SUND_MODS.THREE;
            const cam = this._camera;
            if (!three || !cam) return this.makeObjectXYZ(0, 0, 0);

            const util = three.MathUtils;
            const euler = new three.Euler();
            // プラグインコマンドの入力値・開発HUD・Ctrl+PgDnのコピー値はXYZ表現に統一する。
            // 内部の自由視点操作はYXZで扱うため、cam.rotation.zが0でも見た目の姿勢をXYZへ変換するとZ値が出る。
            euler.setFromQuaternion(cam.quaternion, "XYZ");
            return this.makeObjectXYZ(
                util.radToDeg(euler.x),
                util.radToDeg(euler.y),
                util.radToDeg(euler.z)
            );
        }

        static makeCameraQuaternionFromDegrees(degreesObj) {
            const three = SUND_MODS.THREE;
            if (!three) return null;

            const util = three.MathUtils;
            const euler = new three.Euler(
                util.degToRad(Number(degreesObj.x || 0)),
                util.degToRad(Number(degreesObj.y || 0)),
                util.degToRad(Number(degreesObj.z || 0)),
                "XYZ"
            );
            const q = new three.Quaternion();
            q.setFromEuler(euler);
            return q;
        }

        static applyCameraQuaternion(quaternion) {
            const cam = this._camera;
            if (!cam || !quaternion) return;

            cam.quaternion.copy(quaternion);
            // 右ドラッグ等の内部計算はYXZが安定するため、内部EulerだけはYXZへ同期しておく。
            if (cam.rotation && typeof cam.rotation.setFromQuaternion === "function") {
                cam.rotation.setFromQuaternion(cam.quaternion, "YXZ");
            }
            cam.updateMatrixWorld(true);
        }

        static modelKeyToArray(str) {
            const strKey = this.stringTrim(str);
            if (strKey.toLowerCase() === "all") {
                return Array.from(this._params.vrmMap.keys());
            } else {
                return strKey.split(",").map((el) => el.trim());
            }
        }

        static getRandomInt(min, max) {
            min = Math.ceil(min);
            max = Math.floor(max + 1);
            return Math.floor(Math.random() * (max - min) + min);
        }

        static getAngleToTarget(me, target, isRadians = true) {
            // 平面で2点間の角度を得るために以前作成した関数。謎の90は0を北とするためだったはず。
            const l = 1;
            const dist = Math.sqrt(Math.pow(me.x - target.x, 2) + Math.pow(me.z - target.z, 2));

            const goalX = (-l * me.x + (dist + l) * target.x) / dist;
            const goalY = (-l * me.z + (dist + l) * target.z) / dist;

            if (isRadians) {
                const value = 90 * (Math.PI / 180);
                return -Math.atan2(goalY - me.z, goalX - me.x) + value;
            } else {
                return -Math.atan2(goalY - me.z, goalX - me.x) * (180 / Math.PI) + 90;
            }
        }

        // ---------------
        // instance

        constructor(keyName) {
            this.initialize(keyName);
        }

        initialize(keyName) {
            this._keyName = keyName;
            this._loaded = false;
            this._needsDispose = false;
            this._disposed = false;
            this._needsTrialRender = true;
            this._vrm;
            this._mixer;
            this._lookCamera = true;
            this._animationActions = new Map();
            this._rotationDegY = 0;
            this._continueData;
            this._autoBlink = { enabled: true, nextBlink: 300, interval: 0, value: 0 };
            this._nextPosition = {
                changeValue: { x: 0, y: 0, z: 0 },
                duration: 0,
            };
            this._nextDirection = {
                changeValue: { x: 0, y: 0, z: 0 },
                duration: 0,
            };
            this._motion = {
                current: { name: "idle", loop: "enabled", speed: 1, fadeFrames: 0 },
                next: { name: "", loop: "enabled", speed: 1, fadeFrames: 0 },
                state: "",
            };
            this._motionBlend = {
                active: false,
                toKey: "",
                fromKeys: [],
                durationFrames: 0,
                remainingFrames: 0,
            };
            this._dev = { touchX: null, touchY: null };
            this._disabledPluginExpression = false;
            // 手動表情固定：表情コマンドで設定した表情を、モーション再生・切替後も維持する。
            // VRMAにExpression/BlendShape系トラックが含まれている場合でも、毎フレーム最後に再適用する。
            // blinkMode: keep=従来通り表情固定を優先 / on=まばたきを表情固定より優先 / off=まばたきを常に0へ固定
            this._manualExpressionLock = { enabled: false, values: {}, blinkMode: "keep" };
        }

        update() {
            if (this._disposed) return;
            if (!this._vrm) return;

            const vrm = this._vrm;
            const visible = this.visible();

            this.updateMove(vrm);
            this.updateDirection(vrm);

            if (visible) {
                this.updateLookAt(vrm);
                this.updateMotion(vrm);
                this.applyManualExpressionLock("update");
                this.updateBlink(vrm);
                this.applyManualBlinkPolicy("update");
                this.updateDev(vrm);
                vrm.update(SUND_VRM.deltaTime);
            }

            this.updateDispose(vrm);
        }

        updateMove(vrm) {
            if (this._nextPosition.duration <= 0) return;
            const n = this._nextPosition;
            n.duration--;
            const pos = vrm.scene.position;
            pos.x += n.changeValue.x;
            pos.y += n.changeValue.y;
            pos.z += n.changeValue.z;
        }

        updateDirection(vrm) {
            if (this._nextDirection.duration <= 0) return;
            const n = this._nextDirection;
            n.duration--;

            this._rotationDegY = SUND_VRM.rotationWork180(this._rotationDegY + n.changeValue.y);
            vrm.scene.setRotationFromAxisAngle(SUND_VRM._AXIS_Y, SUND_MODS.THREE.MathUtils.degToRad(this._rotationDegY));
        }

        updateLookAt(vrm) {
            if (!this._lookCamera) return;

            vrm.lookAt.lookAt(SUND_VRM._camera.position);
        }

        updateMotion(vrm) {
            if (!this.isMotionPlay() || !this._mixer) return;

            this.updateMotionBlend();
            this._mixer.update(SUND_VRM.deltaTime);

            const currentKey = this._motion.current.name;
            const currentAction = currentKey ? this._animationActions.get(currentKey) : null;
            const isCurrentRunning = !!(currentAction && currentAction.isRunning());
            const isBlending = !!(this._motionBlend && this._motionBlend.active);

            if (isCurrentRunning || isBlending) {
                this._motion.state = "play";
            } else {
                this._motion.state = "pause";
                if (this._motion.next.name !== "") {
                    this.startMotion({
                        motionKey: this._motion.next.name,
                        nextMotionKey: "",
                        loop: this._motion.next.loop || "enabled",
                        speed: this._motion.next.speed || 1,
                        fadeFrames: this._motion.next.fadeFrames || this._motion.current.fadeFrames || 0,
                    });
                }
            }
        }

        updateMotionBlend() {
            const blend = this._motionBlend;
            if (!blend || !blend.active) return;

            const total = Math.max(1, Number(blend.durationFrames || 1));
            const remain = Math.max(0, Number(blend.remainingFrames || 0));
            const progress = 1 - (remain / total);
            const toAction = this._animationActions.get(blend.toKey);
            if (toAction) {
                toAction.enabled = true;
                toAction.setEffectiveWeight(progress);
            }

            blend.fromKeys.forEach((key) => {
                const action = this._animationActions.get(key);
                if (action) {
                    action.enabled = true;
                    action.setEffectiveWeight(1 - progress);
                }
            });

            if (blend.remainingFrames > 0) {
                blend.remainingFrames--;
            }

            if (blend.remainingFrames <= 0) {
                if (toAction) {
                    toAction.enabled = true;
                    toAction.setEffectiveWeight(1);
                }
                blend.fromKeys.forEach((key) => {
                    const action = this._animationActions.get(key);
                    if (action) {
                        action.stop();
                    }
                });
                this._motionBlend.active = false;
                this._motionBlend.toKey = "";
                this._motionBlend.fromKeys = [];
                this._motionBlend.durationFrames = 0;
                this._motionBlend.remainingFrames = 0;
            }
        }

        manualBlinkMode() {
            const lock = this._manualExpressionLock || {};
            const mode = SUND_VRM.stringTrim(lock.blinkMode || "keep").toLowerCase();
            return (mode === "on" || mode === "off") ? mode : "keep";
        }

        blinkExpressionNames() {
            const manager = this._vrm && this._vrm.expressionManager;
            const arr = manager && manager.blinkExpressionNames;
            return Array.isArray(arr) && arr.length ? arr : ["blink", "blinkLeft", "blinkRight"];
        }

        updateBlink(vrm) {
            if (this._disabledPluginExpression) return;
            const blinkMode = this.manualBlinkMode();
            if (blinkMode === "off") return;
            const forcedOn = blinkMode === "on";
            if (!forcedOn && (this.hasManualExpressionLock() || !this._autoBlink.enabled)) return;

            const b = this._autoBlink;
            b.interval++;
            if (b.interval >= b.nextBlink) {
                vrm.expressionManager.setValue("blink", 1);
                b.nextBlink = SUND_VRM.getRandomInt(180, 300);
                b.interval = 0;
            } else if (b.interval > 4) {
                this.resetBlink(vrm, true);
            }
        }

        resetBlink(vrm, force = false) {
            if (this._disabledPluginExpression) return;
            if (!force && this.hasManualExpressionLock() && this.manualBlinkMode() !== "off") return;
            this.blinkExpressionNames().forEach((key) => {
                if (vrm && vrm.expressionManager && typeof vrm.expressionManager.setValue === "function") {
                    vrm.expressionManager.setValue(key, 0);
                } else {
                    this.setExpressionWeightRaw(key, 0);
                }
            });
        }

        applyManualBlinkPolicy(reason = "") {
            if (this._disabledPluginExpression || !this._vrm) return;
            if (this.manualBlinkMode() === "off") {
                this.resetBlink(this._vrm, true);
            }
        }

        updateDev(vrm) {
            if (!SUND_VRM.isDevMode()) return;
            if (!this.visible()) return;
            if (Input.isPressed("shift")) {
                this.updateDevVRM(vrm);
            }
        }

        updateDevVRM(vrm) {
            this.updateDevVRMPosition(vrm);
            this.updateDevVRMRotation(vrm);
            this.updateDevVRMInformation(vrm);
        }

        updateDevVRMPosition(vrm) {
            const position = vrm.scene.position;
            const moveAmount = 0.1;

            if (Input.isPressed("up")) {
                position.y += moveAmount;
            } else if (Input.isPressed("down")) {
                position.y -= moveAmount;
            } else if (Input.isPressed("left")) {
                position.x -= moveAmount;
            } else if (Input.isPressed("right")) {
                position.x += moveAmount;
            } else if (TouchInput.wheelY > 0) {
                position.z += moveAmount;
            } else if (TouchInput.wheelY < 0) {
                position.z -= moveAmount;
            }
        }

        updateDevVRMRotation(vrm) {
            const dev = SUND_VRM._dev;
            if (TouchInput.isMoved()) {
                dev.touchX = TouchInput._triggerX;
                const moveX = TouchInput._x - dev.touchX;
                const value = moveX > 0 ? 5 : -5;
                const curY = this._rotationDegY;
                const d = SUND_VRM.rotationWork180(curY + value);
                this._rotationDegY = d;
                vrm.scene.setRotationFromAxisAngle(SUND_VRM._AXIS_Y, SUND_MODS.THREE.MathUtils.degToRad(d));

                dev.touchX = TouchInput._x;
            } else {
                dev.touchX = 0;
            }
        }

        updateDevVRMInformation(vrm) {
            const scene = vrm.scene;
            if (Input.isTriggered("pageup")) {
                try {
                    SUND_VRM.copyClipboard(SUND_VRM.devNum(scene.position.x) + "," + SUND_VRM.devNum(scene.position.y) + "," + SUND_VRM.devNum(scene.position.z));
                } catch { }
                //console.log(`==== [${this._keyName}] ====`);
                //console.log(`position: x:${SUND_VRM.devNum(scene.position.x)}, y:${SUND_VRM.devNum(scene.position.y)}, z:${SUND_VRM.devNum(scene.position.z)}`);
            } else if (Input.isTriggered("pagedown")) {
                try {
                    SUND_VRM.copyClipboard(this._rotationDegY);
                } catch { }
                //console.log(`==== [${this._keyName}] ====`);
                //console.log(`rotation: y:${this._rotationDegY}`);
            }
        }

        restoreContinueData() {
            if (!this._continueData) return;
            const scene = this._vrm.scene;
            const data = this._continueData;
            SUND_VRM.assignmentXYZ(scene.position, data.position);
            const rot = data.rotation;
            scene.rotateX(rot.x);
            scene.rotateY(rot.y);
            scene.rotateZ(rot.z);
            const m = data.motion;
            const c = m.current;
            this.startMotion({ motionKey: c.name, nextMotionKey: m.next.name, loop: c.loop, speed: c.speed, fadeFrames: c.fadeFrames || 0 });
            if (data.visible) {
                this.show();
            }
            this._continueData = null;
        }

        updateDispose(vrm) {
            if (!this._needsDispose) return;
            this.hide();
            vrm.update(SUND_VRM.deltaTime);
            SUND_VRM.dispose(this._keyName);
            this._disposed = true;
        }

        setRandomMouth() {
            if (this._disabledPluginExpression || this.hasManualExpressionLock()) return;

            const vrm = this._vrm;
            const mouthArr = vrm.expressionManager.mouthExpressionNames;
            for (key in vrm.expressionManager._expressionMap) {
                if (mouthArr.includes(key)) {
                    vrm.expressionManager._expressionMap[key].weight = 0;
                }
            }
            let i = SUND_VRM.getRandomInt(0, 4);
            let w = SUND_VRM.getRandomInt(4, 7) / 10;
            vrm.expressionManager._expressionMap[mouthArr[i]].weight = w;
        }

        resetMouth() {
            if (this._disabledPluginExpression || this.hasManualExpressionLock()) return;

            const vrm = this._vrm;
            const mouthArr = vrm.expressionManager.mouthExpressionNames;
            for (key in vrm.expressionManager._expressionMap) {
                if (mouthArr.includes(key)) {
                    vrm.expressionManager._expressionMap[key].weight = 0;
                }
            }
        }

        setLookAt(name, value) {
            const lookAt = this._vrm.lookAt;
            const pos = this._vrm.scene.position.clone();
            pos.y += 1;
            pos.z += 1;
            const change = 5 * value;
            switch (name) {
                case "lookReset":
                    lookAt.reset();
                    return;
                case "lookUp":
                    pos.y += change;
                    break;
                case "lookDown":
                    pos.y -= change;
                    break;
                case "lookLeft":
                    pos.x += change;
                    break;
                case "lookRight":
                    pos.x -= change;
                    break;
            }
            lookAt.lookAt(pos);
            return;
        }

        hasManualExpressionLock() {
            return !!(this._manualExpressionLock && this._manualExpressionLock.enabled);
        }

        expressionMapKeys() {
            const manager = this._vrm && this._vrm.expressionManager;
            const map = manager && manager._expressionMap;
            if (!map) return [];
            if (typeof map.keys === "function") {
                return Array.from(map.keys());
            }
            return Object.keys(map);
        }

        expressionMapItem(key) {
            const manager = this._vrm && this._vrm.expressionManager;
            const map = manager && manager._expressionMap;
            if (!map) return null;
            if (typeof map.get === "function") return map.get(key);
            return map[key];
        }

        expressionWeight(key) {
            const manager = this._vrm && this._vrm.expressionManager;
            if (!manager) return 0;
            if (typeof manager.getValue === "function") {
                const value = Number(manager.getValue(key));
                if (Number.isFinite(value)) return value;
            }
            const item = this.expressionMapItem(key);
            const weight = Number(item && item.weight);
            return Number.isFinite(weight) ? weight : 0;
        }

        setExpressionWeightRaw(key, value) {
            const manager = this._vrm && this._vrm.expressionManager;
            if (!manager || !key) return false;
            const weight = SUND_VRM.clampNumber(value, 0, 1);
            if (typeof manager.setValue === "function") {
                manager.setValue(key, weight);
                return true;
            }
            const item = this.expressionMapItem(key);
            if (item) {
                item.weight = weight;
                return true;
            }
            return false;
        }

        normalizeBlinkMode(mode) {
            const text = SUND_VRM.stringTrim(mode || "keep").toLowerCase();
            if (text === "on" || text === "true" || text === "1") return "on";
            if (text === "off" || text === "false" || text === "0") return "off";
            return "keep";
        }

        captureManualExpressionLock(reason = "", blinkMode = "keep") {
            const manager = this._vrm && this._vrm.expressionManager;
            if (this._disabledPluginExpression || !manager) return;
            const mode = this.normalizeBlinkMode(blinkMode);
            const values = {};
            this.expressionMapKeys().forEach((key) => {
                values[key] = SUND_VRM.clampNumber(this.expressionWeight(key), 0, 1);
            });
            this._manualExpressionLock = {
                enabled: true,
                reason: String(reason || "manual"),
                values: values,
                blinkMode: mode,
            };
            if (mode === "off") {
                this.resetBlink(this._vrm, true);
            }
        }

        clearManualExpressionLock() {
            this._manualExpressionLock = { enabled: false, values: {}, blinkMode: "keep" };
        }

        applyManualExpressionLock(reason = "") {
            if (this._disabledPluginExpression || !this.hasManualExpressionLock()) return;
            const lock = this._manualExpressionLock;
            const values = lock && lock.values;
            if (!values) return;
            const blinkMode = this.manualBlinkMode();
            const blinkNames = this.blinkExpressionNames();
            Object.keys(values).forEach((key) => {
                if ((blinkMode === "on" || blinkMode === "off") && blinkNames.includes(key)) return;
                this.setExpressionWeightRaw(key, values[key]);
            });
        }

        setExpression(name, value, blinkMode = "keep") {
            if (this._disabledPluginExpression) return;

            const vrm = this._vrm;
            if (name === "lookReset" || vrm.expressionManager.lookAtExpressionNames.includes(name)) {
                this.setLookAt(name, value);
                return;
            }

            const mouthArr = this._vrm.expressionManager.mouthExpressionNames;
            const blinkArr = this._vrm.expressionManager.blinkExpressionNames;
            if (mouthArr.includes(name)) {
                for (key in this._vrm.expressionManager._expressionMap) {
                    if (mouthArr.includes(key)) {
                        this._vrm.expressionManager._expressionMap[key].weight = 0;
                    }
                }
            } else if (blinkArr.includes(name)) {
                for (key in this._vrm.expressionManager._expressionMap) {
                    if (blinkArr.includes(key)) {
                        this._vrm.expressionManager._expressionMap[key].weight = 0;
                    }
                }
            } else {
                for (key in this._vrm.expressionManager._expressionMap) {
                    this._vrm.expressionManager._expressionMap[key].weight = 0;
                }
            }
            this._vrm.expressionManager.setValue(name, value);
            this.captureManualExpressionLock("setExpression:" + name, blinkMode);
            this.applyManualExpressionLock("setExpression");
            this.applyManualBlinkPolicy("setExpression");
        }

        hasExpressionKey(name) {
            const manager = this._vrm && this._vrm.expressionManager;
            if (!manager) return false;
            const map = manager._expressionMap;
            if (!map) return true;
            if (typeof map.has === "function") {
                return map.has(name);
            }
            return Object.prototype.hasOwnProperty.call(map, name);
        }

        resetExpressionWeights() {
            const manager = this._vrm && this._vrm.expressionManager;
            if (!manager || !manager._expressionMap) return;
            const map = manager._expressionMap;
            if (typeof map.forEach === "function") {
                map.forEach((expression) => {
                    if (expression) expression.weight = 0;
                });
                return;
            }
            for (const key in map) {
                if (map[key]) map[key].weight = 0;
            }
        }

        setExpressionValue(name, value, resetOther = false, warnIfMissing = true, blinkMode = "keep") {
            if (this._disabledPluginExpression) return false;
            const manager = this._vrm && this._vrm.expressionManager;
            if (!manager) return false;

            const keyName = SUND_VRM.stringTrim(name);
            if (!keyName) return false;

            if (!this.hasExpressionKey(keyName)) {
                if (warnIfMissing && Utils.isOptionValid("test")) {
                    console.warn(`[SunD_VRM] Expression key not found. model=${this._keyName}, key=${keyName}`);
                }
                return false;
            }

            if (resetOther) {
                this.resetExpressionWeights();
            }

            const weight = SUND_VRM.clampNumber(value, 0, 1);
            manager.setValue(keyName, weight);
            this.captureManualExpressionLock("setExpressionValue:" + keyName, blinkMode);
            this.applyManualExpressionLock("setExpressionValue");
            this.applyManualBlinkPolicy("setExpressionValue");
            return true;
        }

        resetPluginExpression(){
            this.clearManualExpressionLock();
            const vrm = this._vrm;
            vrm.lookAt.reset();

            const map = vrm.expressionManager._expressionMap;
            for (key in map) {
                map[key].weight = 0;
            }
        }

        visible() {
            return this._vrm.scene.visible;
        }

        isMotionPlay() {
            return this.visible() && this._motion.state === "play";
        }

        show() {
            if (!this._vrm) return;
            this._vrm.scene.visible = true;
        }

        hide() {
            if (!this._vrm) return;
            this._vrm.scene.visible = false;
        }

        motionSpeedChange(props) {
            const vrm = this._vrm;
            if (!vrm) return;
            const motionKey = this._motion.current.name;
            const action = this._animationActions.get(motionKey);
            if (!action) return;

            const motion = this._motion;
            const speed = props.speed;
            motion.current.speed = speed;
            action.timeScale = speed;
            if (props.speed === 0) {
                motion.state = "pause";
                this._mixer.update(SUND_VRM.deltaTime);
            } else {
                motion.state = "play";
            }
            this.applyManualExpressionLock("motionSpeedChange");
        }

        startMotion(props) {
            const vrm = this._vrm;
            const motionKey = "" + props.motionKey;
            const vrma = SUND_VRM._animations.get(motionKey);
            if (!vrm || !vrma) {
                if (motionKey && SUND_VRM._missingVrmaKeys && SUND_VRM._missingVrmaKeys.has(motionKey)) {
                    console.warn(`[SunD_VRM] startMotion skipped because VRMA is missing: ${motionKey}`);
                }
                return;
            }

            let action = this._animationActions.get(motionKey);
            if (!action) {
                const clip = SUND_MODS.THREE_VRM_Animation.createVRMAnimationClip(vrma, vrm);
                action = this._mixer.clipAction(clip);
                this._animationActions.set(motionKey, action);
            }

            const motion = this._motion;
            const previousCurrentKey = motion.current.name;
            const previousActions = [];
            this._animationActions.forEach((value, key) => {
                if (key !== motionKey && value && (value.isRunning() || value.enabled)) {
                    previousActions.push({ key, action: value });
                }
            });

            motion.current.name = motionKey;
            const loop = props.loop;
            motion.current.loop = loop;
            const fadeFrames = Math.max(0, Number(props.fadeFrames || 0));
            motion.current.fadeFrames = fadeFrames;

            SUND_VRM.setActionLoop(loop, action);
            if (loop === "disabled") {
                motion.next.name = "" + props.nextMotionKey;
                motion.next.loop = "enabled";
                motion.next.speed = 1;
                motion.next.fadeFrames = fadeFrames;
                action.clampWhenFinished = true;
            } else {
                motion.next.name = "";
                motion.next.loop = "enabled";
                motion.next.speed = 1;
                motion.next.fadeFrames = 0;
                action.clampWhenFinished = false;
            }

            action.reset();
            action.enabled = true;
            action.paused = false;
            action.stopFading();

            const speed = Number(props.speed);
            motion.current.speed = speed;
            action.timeScale = speed;

            const useBlend = fadeFrames > 0 && previousActions.length > 0 && previousCurrentKey !== motionKey;
            if (useBlend) {
                action.setEffectiveWeight(0);
                action.play();

                previousActions.forEach(({ action }) => {
                    action.enabled = true;
                    action.paused = false;
                    action.stopFading();
                    action.setEffectiveWeight(1);
                });

                this._motionBlend.active = true;
                this._motionBlend.toKey = motionKey;
                this._motionBlend.fromKeys = previousActions.map((entry) => entry.key);
                this._motionBlend.durationFrames = fadeFrames;
                this._motionBlend.remainingFrames = fadeFrames;
            } else {
                action.setEffectiveWeight(1);
                action.play();
                this._animationActions.forEach((value, key) => {
                    if (key !== motionKey) {
                        value.stop();
                    }
                });
                this._motionBlend.active = false;
                this._motionBlend.toKey = "";
                this._motionBlend.fromKeys = [];
                this._motionBlend.durationFrames = 0;
                this._motionBlend.remainingFrames = 0;
            }

            if (speed === 0) {
                motion.state = "pause";
                this._mixer.update(SUND_VRM.deltaTime);
            } else {
                motion.state = "play";
            }
            this.applyManualExpressionLock("startMotion");
        }
    }
    window.SUND_VRM = SUND_VRM;

    // -----------------
    // パラメータ整形してSUND_VRMへ

    SUND_VRM._params.directionalLightIntensity = SUND_VRM.resolveInitialLightNumber(params.directionalLightIntensity, 0.8);
    SUND_VRM._params.ambientLightIntensity = SUND_VRM.resolveInitialLightNumber(params.ambientLightIntensity, 0.25);
    SUND_VRM._params.lightPosition = SUND_VRM.resolveInitialLightPosition(params.lightPosition);

    params.models.forEach((el) => {
        SUND_VRM._params.vrmMap.set("" + el.keyName, el.fileName);
        if (el.preLoad) {
            SUND_VRM._params.loadModels.add(el.keyName);
        }
    });

    params.motions.forEach((el) => SUND_VRM._params.vrmaMap.set("" + el.keyName, el.fileName));

    params.positions.forEach((el) => {
        const posArr = el.position.split(",").map(Number);
        const pos = SUND_VRM.makeObjectXYZ(posArr[0], posArr[1], posArr[2]);
        SUND_VRM._params.positionMap.set("" + el.keyName, pos);
    });

    params.directions.forEach((el) => {
        SUND_VRM._params.directionMap.set("" + el.keyName, Number(el.rotationY));
    });

    params.cameras.forEach((el) => {
        const posArr = el.position.split(",").map(Number);
        const pos = SUND_VRM.makeObjectXYZ(posArr[0], posArr[1], posArr[2]);
        const rotArr = el.rotation.split(",").map(Number);
        const rot = SUND_VRM.makeObjectXYZ(rotArr[0], rotArr[1], rotArr[2]);
        SUND_VRM._params.cameraMap.set("" + el.keyName, { position: pos, rotation: rot });
    });

    // 外部設定JSONはプラグインパラメータの後に読み込む。
    // 同じキーがある場合、外部設定側で追加・上書きされる。
    SUND_VRM.applyExternalConfigFile(params.externalConfigFile);

    // -----------------
    // プラグインコマンド

    PluginManagerEx.registerCommand(script, "showVRM", function (args) {
        const keys = SUND_VRM.modelKeyToArray(args.modelKey);
        keys.forEach((key) => {
            const obj = $sundVRMs.get(key);
            if (obj) {
                obj.show();
            }
        });
    });

    PluginManagerEx.registerCommand(script, "hideVRM", function (args) {
        const keys = SUND_VRM.modelKeyToArray(args.modelKey);
        keys.forEach((key) => {
            const obj = $sundVRMs.get(key);
            if (obj) {
                obj.hide();
            }
        });
    });

    PluginManagerEx.registerCommand(script, "registerPosition", function (args) {
        SUND_VRM.registerRuntimePosition(args.keyName, args.position);
    });

    PluginManagerEx.registerCommand(script, "registerDirection", function (args) {
        SUND_VRM.registerRuntimeDirection(args.keyName, args.rotationY);
    });

    PluginManagerEx.registerCommand(script, "registerCamera", function (args) {
        SUND_VRM.registerRuntimeCamera(args.keyName, args.position, args.rotation);
    });

    PluginManagerEx.registerCommand(script, "setPosition", function (args) {
        if (isNaN(args.frame)) return;
        const keys = SUND_VRM.modelKeyToArray(args.modelKey);
        const duration = args.frame <= 0 ? 1 : args.frame;

        let pos;
        let addMode = false;
        const argPos = SUND_VRM.stringTrim(args.position);
        if (argPos.split(",").length === 3) {
            const arr = argPos.split(",").map(Number);
            pos = { x: arr[0], y: arr[1], z: arr[2] };
            addMode = true;
        } else {
            pos = SUND_VRM._params.positionMap.get(argPos);
            if (!pos && argPos) SUND_VRM.warnMissingPositionKey(argPos);
        }
        if (!pos) return;

        keys.forEach((key) => {
            const obj = $sundVRMs.get(key);
            if (obj) {
                const curPos = obj._vrm.scene.position;
                const addPos = SUND_VRM.makeObjectXYZ();
                if (addMode) {
                    addPos.x = pos.x + curPos.x;
                    addPos.y = pos.y + curPos.y;
                    addPos.z = pos.z + curPos.z;
                }

                const next = obj._nextPosition;
                next.changeValue.x = (pos.x + addPos.x - curPos.x) / duration;
                next.changeValue.y = (pos.y + addPos.y - curPos.y) / duration;
                next.changeValue.z = (pos.z + addPos.z - curPos.z) / duration;
                next.duration = duration;
            }
        });
    });

    PluginManagerEx.registerCommand(script, "setDirection", function (args) {
        if (isNaN(args.frame)) return;
        const keys = SUND_VRM.modelKeyToArray(args.modelKey);
        const paramRot = SUND_VRM.stringTrim(args.modelRotation);
        const duration = args.frame <= 0 ? 1 : args.frame;
        let rot;
        let addMode = false;
        let cameraMode = false;

        if (paramRot === "camera") {
            cameraMode = true;
        } else if (!isNaN(paramRot)) {
            rot = { x: 0, y: Number(paramRot), z: 0 };
            addMode = true;
        } else {
            const value = SUND_VRM._params.directionMap.get(paramRot);
            if (value == null) {
                if (paramRot) SUND_VRM.warnMissingDirectionKey(paramRot);
                return;
            }
            rot = { x: 0, y: value, z: 0 };
        }
        // rotはdegree

        keys.forEach((key) => {
            const obj = $sundVRMs.get(key);
            if (obj) {
                const next = obj._nextDirection;
                const curRot = obj._vrm.scene.rotation;
                if (addMode) {
                    next.changeValue.y = rot.y / duration;
                } else {
                    const curY = Math.round(SUND_VRM.getRotationDegY(curRot));

                    let goalY = 0;
                    if (cameraMode) {
                        goalY = SUND_VRM.rotationWork180(Math.round(SUND_VRM.getAngleToTarget(obj._vrm.scene.position, SUND_VRM._camera.position, false)));
                    } else {
                        goalY = Math.round(rot.y);
                    }

                    if (isNaN(curY) || isNaN(goalY)) return;
                    if (curY === goalY) return;

                    obj._rotationDegY = curY;

                    // より近い方向で回転
                    let right = 0;
                    let left = 0;
                    const cur = curY < 0 ? 360 + curY : curY;
                    const goal = goalY < 0 ? 360 + goalY : goalY;
                    if (cur <= goal) {
                        right = goal - cur;
                        left = cur + 360 - goal;
                    } else {
                        right = 360 - cur + goal;
                        left = cur - goal;
                    }
                    if (right <= left) {
                        next.changeValue.y = right / duration;
                    } else {
                        next.changeValue.y = -(left / duration);
                    }
                }
                next.duration = duration;
            }
        });
    });

    PluginManagerEx.registerCommand(script, "setCamera", function (args) {
        const camKey = SUND_VRM.stringTrim(args.cameraKey);
        const camData = SUND_VRM._params.cameraMap.get(camKey);
        if (!camData) {
            if (camKey) SUND_VRM.warnMissingCameraKey(camKey);
            return;
        }

        SUND_VRM.clearCameraMove();
        SUND_VRM.applyCameraMoveTarget({
            position: camData.position,
            rotationDeg: camData.rotation
        }, "linear");
    });

    PluginManagerEx.registerCommand(script, "moveCamera", function (args) {
        SUND_VRM.startCameraMove(args);
    });

    PluginManagerEx.registerCommand(script, "debugSetCamera", function (args) {
        const outputLog = args.outputLog !== false && String(args.outputLog) !== "false";
        SUND_VRM.debugSetCamera(args.position, args.rotation, args.lookAtModelKey, args.lookAtAdjustY, outputLog);
    });

    PluginManagerEx.registerCommand(script, "cameraLookAt", function (args) {
        if (isNaN(args.adjustY)) return;
        const obj = $sundVRMs.get(SUND_VRM.stringTrim(args.modelKey));
        if (obj) {
            SUND_VRM.clearCameraMove();
            const p = obj._vrm.scene.position.clone();
            p.y += Number(args.adjustY);
            SUND_VRM._camera.lookAt(p);
            SUND_VRM.applyCameraQuaternion(SUND_VRM._camera.quaternion.clone());
            SUND_VRM.syncCameraControls(p);
        }
    });

    PluginManagerEx.registerCommand(script, "freeCameraControl", function (args) {
        SUND_VRM.setFreeCameraControl(args);
    });

    PluginManagerEx.registerCommand(script, "setVRMLight", function (args) {
        SUND_VRM.setVRMLight(args);
    });

    PluginManagerEx.registerCommand(script, "disabledExpression", function (args) {
        const keys = SUND_VRM.modelKeyToArray(args.modelKey);

        if (args.disabled){
            keys.forEach((key) => {
                const obj = $sundVRMs.get(key);
                const index = SUND_VRM._autoMouth.targets.indexOf(key);
                SUND_VRM._autoMouth.targets.splice(index,1);
                if (obj){
                    obj.resetPluginExpression();
                    obj.clearManualExpressionLock();
                    obj._disabledPluginExpression = true;
                }
            });
        } else {
            keys.forEach((key) => {
                const obj = $sundVRMs.get(key);
                if (obj){
                    obj._disabledPluginExpression = false;
                }
            });
        }

    });

    PluginManagerEx.registerCommand(script, "startMotion", function (args) {
        if (isNaN(args.speed)) return;
        const keys = SUND_VRM.modelKeyToArray(args.modelKey);
        args.speed /= 100;
        args.fadeFrames = isNaN(args.fadeFrames) ? 12 : Math.max(0, Number(args.fadeFrames));

        keys.forEach((key) => {
            const obj = $sundVRMs.get(key);
            if (obj) {
                obj.startMotion(args);
            }
        });
    });

    PluginManagerEx.registerCommand(script, "motionSpeed", function (args) {
        if (isNaN(args.speed)) return;
        const keys = SUND_VRM.modelKeyToArray(args.modelKey);
        args.speed /= 100;

        keys.forEach((key) => {
            const obj = $sundVRMs.get(key);
            if (obj) {
                obj.motionSpeedChange(args);
            }
        });
    });

    PluginManagerEx.registerCommand(script, "dispose", function (args) {
        const keys = SUND_VRM.modelKeyToArray(args.modelKey);
        keys.forEach((key) => {
            const obj = $sundVRMs.get(key);
            if (obj) {
                obj._needsDispose = true;
            }
        });
    });

    PluginManagerEx.registerCommand(script, "loadSkipList", function (args) {
        const keys = SUND_VRM.modelKeyToArray(args.modelKey);
        const mode = args.mode;
        const list = $gameParty._sundVRM.loadSkipModels;
        switch (mode) {
            case "add":
                keys.forEach((key) => {
                    if (!list.includes(key)) {
                        list.push(key);
                    }
                });
                break;
            case "remove":
                keys.forEach((key) => {
                    const index = list.indexOf(key);
                    if (index >= 0) {
                        list.splice(index, 1);
                    }
                });
                break;
        }
    });

    PluginManagerEx.registerCommand(script, "autoMouth", function (args) {
        const keys = SUND_VRM.modelKeyToArray(args.modelKey);
        const m = SUND_VRM._autoMouth;
        m.targets.splice(0);
        keys.forEach((key) => m.targets.push(key));
    });

    PluginManagerEx.registerCommand(script, "autoBlink", function (args) {
        const keys = SUND_VRM.modelKeyToArray(args.modelKey);
        const enabled = args.enabled;

        keys.forEach((key) => {
            const obj = $sundVRMs.get(key);
            if (obj) {
                obj._autoBlink.enabled = enabled;
                if (!enabled) {
                    obj.resetBlink(obj._vrm);
                }
            }
        });
    });

    PluginManagerEx.registerCommand(script, "lookCamera", function (args) {
        const keys = SUND_VRM.modelKeyToArray(args.modelKey);
        const enabled = args.enabled;

        keys.forEach((key) => {
            const obj = $sundVRMs.get(key);
            if (obj) {
                obj._lookCamera = enabled;
            }
        });
    });

    PluginManagerEx.registerCommand(script, "setExpression", function (args) {
        if (isNaN(args.value)) return;
        const keys = SUND_VRM.resolveModelKeys(args.modelKey, args.modelKeyVariableId);
        const expression = SUND_VRM.resolveExpressionKey(args.expression, args.expressionVariableId);
        if (!expression) return;
        const value = args.value / 100;
        const blinkMode = SUND_VRM.stringTrim(args.blinkMode || "keep");
        keys.forEach((key) => {
            const obj = $sundVRMs.get(key);
            if (obj) {
                obj.setExpression(expression, value, blinkMode);
            }
        });
    });

    PluginManagerEx.registerCommand(script, "setExpressionByKey", function (args) {
        const keys = SUND_VRM.resolveModelKeys(args.modelKey, args.modelKeyVariableId);
        const expression = SUND_VRM.resolveExpressionKey(args.expressionKey, args.expressionKeyVariableId);
        if (!expression) return;

        const rawValue = SUND_VRM.resolveNumberValue(args.value, args.valueVariableId);
        if (!Number.isFinite(rawValue)) return;

        const value = SUND_VRM.clampNumber(rawValue, 0, 100) / 100;
        const blinkMode = SUND_VRM.stringTrim(args.blinkMode || "keep");
        keys.forEach((key) => {
            const obj = $sundVRMs.get(key);
            if (obj) {
                obj.setExpression(expression, value, blinkMode);
            }
        });
    });

    PluginManagerEx.registerCommand(script, "setExpressionValue", function (args) {
        const keys = SUND_VRM.resolveModelKeys(args.modelKey, args.modelKeyVariableId);
        const expressionKey = SUND_VRM.resolveExpressionKey(args.expressionKey, args.expressionKeyVariableId);
        if (!expressionKey) return;

        const rawValue = SUND_VRM.resolveNumberValue(args.value, args.valueVariableId);
        if (!Number.isFinite(rawValue)) return;

        const value = SUND_VRM.clampNumber(rawValue, 0, 100) / 100;
        const resetOther = SUND_VRM.boolValue(args.resetOther, false);
        const warnIfMissing = SUND_VRM.boolValue(args.warnIfMissing, true);
        const blinkMode = SUND_VRM.stringTrim(args.blinkMode || "keep");

        keys.forEach((key) => {
            const obj = $sundVRMs.get(key);
            if (obj) {
                obj.setExpressionValue(expressionKey, value, resetOther, warnIfMissing, blinkMode);
            }
        });
    });

    // 互換用: 以前の作業版で保存した「setBlendShapeValue」コマンドが残っていても動くようにする。
    PluginManagerEx.registerCommand(script, "setBlendShapeValue", function (args) {
        const keys = SUND_VRM.resolveModelKeys(args.modelKey, args.modelKeyVariableId);
        const expressionKey = SUND_VRM.resolveExpressionKey(args.expressionKey || args.blendShapeKey, args.expressionKeyVariableId || args.blendShapeKeyVariableId);
        if (!expressionKey) return;

        const rawValue = SUND_VRM.resolveNumberValue(args.value, args.valueVariableId);
        if (!Number.isFinite(rawValue)) return;

        const value = SUND_VRM.clampNumber(rawValue, 0, 100) / 100;
        const resetOther = SUND_VRM.boolValue(args.resetOther, false);
        const warnIfMissing = SUND_VRM.boolValue(args.warnIfMissing, true);
        const blinkMode = SUND_VRM.stringTrim(args.blinkMode || "keep");

        keys.forEach((key) => {
            const obj = $sundVRMs.get(key);
            if (obj) {
                obj.setExpressionValue(expressionKey, value, resetOther, warnIfMissing, blinkMode);
            }
        });
    });

    // ----------------
    // Bitmap

    // nw.js更新時の警告に対応するもの
    Bitmap.prototype._createCanvas = function (width, height) {
        this._canvas = document.createElement("canvas");
        this._context = this._canvas.getContext("2d", { willReadFrequently: true });
        this._canvas.width = width;
        this._canvas.height = height;
        this._createBaseTexture(this._canvas);
    };

    // ------------
    // Graphics

    const _Graphics__createAllElements = Graphics._createAllElements;
    Graphics._createAllElements = function () {
        this._createThreeArea();
        _Graphics__createAllElements.apply(this, arguments);
    };

    Graphics._createThreeArea = function () {
        const sc = document.createElement("script");
        sc.type = "module";
        const url = (() => {
            const start = script.src.indexOf("/js/");
            const end = script.src.indexOf("SunD_VRM.js");
            return script.src.substring(start + 1, end) + "SunD_VRM_MOD.js";
        })();
        sc.src = url;
        sc.async = false;
        sc.defer = true;
        sc._url = url;
        document.body.appendChild(sc);
        this._threeArea = sc;
    };

    const _Graphics__updateAllElements = Graphics._updateAllElements;
    Graphics._updateAllElements = function () {
        _Graphics__updateAllElements.apply(this, arguments);
        this._updateThreeElements();
    };

    Graphics._updateThreeElements = function () {
        if (!SUND_VRM.moduleLoaded) return;

        const width = this._width;
        const height = this._height;
        const renderer = SUND_VRM._renderer;

        renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
        renderer.setSize(width, height, false);

        SUND_VRM._camera.aspect = width / height;
        SUND_VRM._camera.updateProjectionMatrix();

        const canvas = renderer.domElement;
        this._centerElement(canvas);
    };

    // ------------
    // Scene_Map

    const _Scene_Map_update = Scene_Map.prototype.update;
    Scene_Map.prototype.update = function () {
        _Scene_Map_update.apply(this, arguments);
        SUND_VRM.updateMap();
    };

    const _Scene_Map_isReady = Scene_Map.prototype.isReady;
    Scene_Map.prototype.isReady = function () {
        return _Scene_Map_isReady.apply(this, arguments) && SUND_VRM.isReady();
    };

    const _Scene_Map_create = Scene_Map.prototype.create;
    Scene_Map.prototype.create = function () {
        SUND_VRM._readyState = "start";
        _Scene_Map_create.apply(this, arguments);
    };

    const _Scene_Map_stop = Scene_Map.prototype.stop;
    Scene_Map.prototype.stop = function () {
        SUND_VRM.hideDevHud();
        _Scene_Map_stop.apply(this, arguments);
    };

    // ------------
    // Scene_Load

    const _Scene_Load_executeLoad = Scene_Load.prototype.executeLoad;
    Scene_Load.prototype.executeLoad = function (savefileId) {
        // 直接ロード対策
        SUND_VRM.allHide();
        SUND_VRM._afterContinue = params.useSave;
        _Scene_Load_executeLoad.apply(this, arguments);
    };

    // ------------
    // Scene_Save

    const _Scene_Save_executeSave = Scene_Save.prototype.executeSave;
    Scene_Save.prototype.executeSave = function (savefileId) {
        SUND_VRM.setSaveData();
        _Scene_Save_executeSave.apply(this, arguments);
    };

    // ------------
    // Spriteset_Map

    const _Spriteset_Map_createPictures = Spriteset_Map.prototype.createPictures;
    Spriteset_Map.prototype.createPictures = function () {
        _Spriteset_Map_createPictures.apply(this, arguments);
        this.createThreeArea();
    };

    Spriteset_Map.prototype.createThreeArea = function () {
        const sp = new Sprite();
        const w = Graphics.width;
        const h = Graphics.height;
        sp.bitmap = new Bitmap(w, h);
        sp.visible = false;
        this.addChild(sp);
        SUND_VRM._threeSprite = sp;
    };

    // ------------
    // Window_Message

    const _Window_Message_startMessage = Window_Message.prototype.startMessage;
    Window_Message.prototype.startMessage = function () {
        _Window_Message_startMessage.apply(this, arguments);
        SUND_VRM._autoMouth.duration = $gameMessage.allText().length * 4;
    };

    const _Window_Message_update = Window_Message.prototype.update;
    Window_Message.prototype.update = function () {
        SUND_VRM.updateAutoMouth();
        _Window_Message_update.apply(this, arguments);
    };

    const _Window_Message_terminateMessage = Window_Message.prototype.terminateMessage;
    Window_Message.prototype.terminateMessage = function () {
        _Window_Message_terminateMessage.apply(this, arguments);
        SUND_VRM.stopAutoMouth();
    };

    // ------------
    // Game_System

    const _Game_System_initialize = Game_System.prototype.initialize;
    Game_System.prototype.initialize = function () {
        _Game_System_initialize.apply(this, arguments);
        this._sundVRMFreeCameraControl = SUND_VRM.defaultFreeCameraControlData();
    };

    // ------------
    // Game_Party

    const _Game_Party_initialize = Game_Party.prototype.initialize;
    Game_Party.prototype.initialize = function () {
        _Game_Party_initialize.apply(this, arguments);
        this._sundVRM = {
            loadSkipModels: [],
            modelSaveData: [],
            cameraSaveData: {
                coordinateMode: "free",
                position: SUND_VRM.makeObjectXYZ(0, 0, 3),
                rotation: SUND_VRM.makeObjectXYZ(0, 0, 0),
                rotationDeg: SUND_VRM.makeObjectXYZ(0, 0, 0)
            },
        };
    };

    // ------------
    // Game_Player

    const _Game_Player_canMove = Game_Player.prototype.canMove;
    Game_Player.prototype.canMove = function () {
        if (SUND_VRM.dontMovePlayer()) {
            return false;
        }
        return _Game_Player_canMove.apply(this, arguments);
    };

    // ------------
    // Scene_Title

    const _Scene_Title_initialize = Scene_Title.prototype.initialize;
    Scene_Title.prototype.initialize = function () {
        SUND_VRM.allHide();
        _Scene_Title_initialize.apply(this, arguments);
    };
})();



// ------------------------------------------------------------
// DB coordinate consistency debug helper
// プレビュー値とMZ実行中の値を照合するための補助関数です。
// コンソールから SUND_VRM.debugCoordinateState("modelKey", "positionKey", "cameraKey") で実行できます。
(function() {
    if (!window.SUND_VRM) return;
    const formatNum = (value) => {
        const n = Number(value);
        if (!Number.isFinite(n)) return String(value);
        return n.toFixed(6).replace(/\.?0+$/u, "");
    };
    const xyzText = (obj) => {
        if (!obj) return "";
        return [formatNum(obj.x), formatNum(obj.y), formatNum(obj.z)].join(",");
    };
    window.SUND_VRM.debugCoordinateState = function(modelKey = "", positionKey = "", cameraKey = "") {
        const key = String(modelKey || "");
        const posKey = String(positionKey || "");
        const camKey = String(cameraKey || "");
        const obj = window.$sundVRMs && key ? window.$sundVRMs.get(key) : null;
        const scene = obj && obj._vrm && obj._vrm.scene ? obj._vrm.scene : null;
        const camera = this._camera;
        const positionData = posKey && this._params && this._params.positionMap ? this._params.positionMap.get(posKey) : null;
        const cameraData = camKey && this._params && this._params.cameraMap ? this._params.cameraMap.get(camKey) : null;
        const rotation = this.makeCameraDisplayDegreesObject ? this.makeCameraDisplayDegreesObject() : null;

        const summary = {
            modelKey: key,
            modelExists: !!obj,
            loaded: !!(obj && obj._loaded),
            visible: !!(scene && scene.visible),
            runtimeModelPosition: scene ? xyzText(scene.position) : "(not created)",
            positionKey: posKey,
            positionMapValue: positionData ? xyzText(positionData) : "(missing)",
            cameraKey: camKey,
            runtimeCameraPosition: camera ? xyzText(camera.position) : "(no camera)",
            runtimeCameraRotation: rotation ? xyzText(rotation) : "(no rotation method)",
            cameraMapPosition: cameraData && cameraData.position ? xyzText(cameraData.position) : "(missing)",
            cameraMapRotation: cameraData && cameraData.rotation ? xyzText(cameraData.rotation) : "(missing)",
            visibleAnyModel: !!this._visibleAnyModel,
            readyState: this._readyState || "",
            needsThreeRender: this.needsThreeRender ? !!this.needsThreeRender() : "(no method)"
        };

        console.log("[SunD_VRM Coordinate Debug]", summary);
        console.table([summary]);
        return summary;
    };
})();



function dumpVrmMaterials(root) {
    if (!root) {
        console.log("dumpVrmMaterials: root がありません");
        return;
    }

    let meshCount = 0;

    root.traverse(obj => {
        if (!obj || !obj.isMesh) return;
        meshCount++;

        const materials = Array.isArray(obj.material) ? obj.material : [obj.material];

        console.log("----- Mesh -----");
        console.log("name:", obj.name);
        console.log("uuid:", obj.uuid);
        console.log("visible:", obj.visible);
        console.log("renderOrder:", obj.renderOrder);

        materials.forEach((mat, i) => {
            if (!mat) {
                console.log(`material[${i}]: null`);
                return;
            }
            console.log(`material[${i}] name:`, mat.name);
            console.log(`material[${i}] type:`, mat.type);
            console.log(`material[${i}] transparent:`, mat.transparent);
            console.log(`material[${i}] opacity:`, mat.opacity);
            console.log(`material[${i}] alphaTest:`, mat.alphaTest);
            console.log(`material[${i}] depthWrite:`, mat.depthWrite);
            console.log(`material[${i}] depthTest:`, mat.depthTest);
            console.log(`material[${i}] side:`, mat.side);
            console.log(`material[${i}] blending:`, mat.blending);
            console.log(`material[${i}] map:`, !!mat.map);
        });
    });

    console.log("meshCount =", meshCount);
}


function forceOpaqueForTest(root) {
    if (!root) return;

    root.traverse(obj => {
        if (!obj || !obj.isMesh) return;

        const materials = Array.isArray(obj.material) ? obj.material : [obj.material];
        materials.forEach(mat => {
            if (!mat) return;

            mat.transparent = false;
            mat.opacity = 1.0;
            mat.alphaTest = 0;
            mat.depthWrite = true;
            mat.depthTest = true;
            mat.needsUpdate = true;
        });
    });

    console.log("forceOpaqueForTest: applied");
}