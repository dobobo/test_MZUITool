/*:
 * @target MZ
 * @plugindesc 牧場系インベントリ＆ホットバー＆設置イベント基盤 v1.1.1（鞄→ホットバー割当修正/ホットバー選択化） 
 * @author DB + ChatGPT
 *
 * @help
 * 1〜0: ホットバー選択 / Q: 素手 / F: 前に設置 / B: 鞄UIトグル
 * 鞄UIでスロット決定→「ホットバーへ移動/交換」→ホットバーへフォーカスが移動。
 * 矢印でスロットを選んでOK（または 1〜0 を押す）と割当完了。
 *
 * v1.1.1:
 * - 鞄コマンドの数字入力待ちの不具合を修正（Window_Commandのハンドラ仕様に合わせて再設計）
 * - ホットバーをWindow_Selectable化、割当時にカーソルが移動して選べるUIに
 *
 * 【注意】設置物の永続化は未実装（次対応予定）
 *
 * ------------------------------------------------------------
 * ■ パラメータ
 * ------------------------------------------------------------
 *
 * @param BagSlots
 * @text 鞄スロット数
 * @type number
 * @min 1
 * @default 40
 *
 * @param StorageSlots
 * @text 倉庫スロット数
 * @type number
 * @min 1
 * @default 120
 *
 * @param DefaultMaxStackItem
 * @text デフォ最大スタック（アイテム）
 * @type number
 * @min 1
 * @default 99
 *
 * @param DefaultMaxStackWeapon
 * @text デフォ最大スタック（武器）
 * @type number
 * @min 1
 * @default 1
 *
 * @param DefaultMaxStackArmor
 * @text デフォ最大スタック（防具）
 * @type number
 * @min 1
 * @default 1
 *
 * @param EnableNumberHotkeys
 * @text 数字キーで選択を有効
 * @type boolean
 * @on 有効
 * @off 無効
 * @default true
 *
 * @param ToggleEmptyOnRepress
 * @text 同じ数字キー再押しで素手に
 * @type boolean
 * @on 有効
 * @off 無効
 * @default true
 *
 * @param PlaceKey
 * @text 設置キー（英字1文字）
 * @type string
 * @default F
 *
 * @param ClearKey
 * @text 素手キー（英字1文字）
 * @type string
 * @default Q
 *
 * @param BagToggleKey
 * @text 鞄トグルキー（英字1文字）
 * @type string
 * @default B
 *
 * @param HotbarHeight
 * @text ホットバー高さ(px)
 * @type number
 * @min 44
 * @default 64
 * // ※このパラメータは v1.1.1 のホットバーでは直接は使っていません。
 * //   実際の高さは「SLOT（= SlotSize） + PAD*2」で固定計算。
 * //   （歴史的経緯で残しているだけ。必要なら将来ここを参照する実装に変更可能）
 *
 * @param SlotSize
 * @text ホットバーのスロットサイズ(px)
 * @type number
 * @min 32
 * @default 48
 *
 * @param PlacementRules
 * @text 設置ルール
 * @type struct<PlacementRule>[]
 * @default []
 *
 * ------------------------------------------------------------
 * ■ プラグインコマンド
 * ------------------------------------------------------------
 *
 * @command GiveItem
 * @text 開発用：鞄にアイテム付与
 * @arg kind
 * @text 種別
 * @type select
 * @option アイテム @value item
 * @option 武器     @value weapon
 * @option 防具     @value armor
 * @default item
 * @arg id
 * @text データベースID
 * @type number
 * @min 1
 * @default 1
 * @arg amount
 * @text 個数
 * @type number
 * @min 1
 * @default 1
 *
 * @command HotbarAssign
 * @text ホットバー割当
 * @arg slot
 * @text スロット(1-10)
 * @type number
 * @min 1
 * @max 10
 * @default 1
 * @arg kind
 * @text 種別
 * @type select
 * @option アイテム @value item
 * @option 武器     @value weapon
 * @option 防具     @value armor
 * @default item
 * @arg id
 * @text データベースID
 * @type number
 * @min 1
 * @default 1
 *
 * @command HotbarClear
 * @text ホットバー解除
 * @arg slot
 * @text スロット(1-10)
 * @type number
 * @min 1
 * @max 10
 * @default 1
 *
 * @command PlaceHeldItem
 * @text 手持ちを前に設置
 *
 * @command OpenBag
 * @text 鞄UIを開く（トグル）
 *
 * @command OpenStorage
 * @text 倉庫UIを開く（ダミー）
 */

 /*~struct~PlacementRule:
  * @param kind
  * @text 種別
  * @type select
  * @option アイテム @value item
  * @option 武器     @value weapon
  * @option 防具     @value armor
  * @default item
  *
  * @param id
  * @text データベースID
  * @type number
  * @min 1
  * @default 1
  *
  * @param charName
  * @text キャラ画像（置物用）
  * @type file
  * @dir img/characters
  * @default
  *
  * @param charIndex
  * @text キャラインデックス(0-7)
  * @type number
  * @min 0
  * @max 7
  * @default 0
  *
  * @param priority
  * @text 表示優先度
  * @type select
  * @option 下（プレイヤーの下） @value 0
  * @option 通常（同じ）         @value 1
  * @option 上（プレイヤーの上） @value 2
  * @default 1
  *
  * @param onPlaceCE
  * @text 設置直後の共通イベントID(任意)
  * @type common_event
  * @default 0
  *
  * @param onInteractCE
  * @text 触れた時の共通イベントID(任意)
  * @type common_event
  * @default 0
  *
  * @param pickupEnabled
  * @text 拾い戻し可
  * @type boolean
  * @on 可
  * @off 不可
  * @default true
  */

(()=>{
"use strict";
const PLUGIN_NAME="DB_FarmCore_MZ";

//----------------------------------
// Params（プラグインパラメータ取得）
//----------------------------------
// PluginManager.parameters(PLUGIN_NAME) でメタ/エディタ側の値を取り出す。
// pInt/pBool/pStr は型・デフォルトの簡易ラッパ。
const P=PluginManager.parameters(PLUGIN_NAME);
const pInt=(k,d=0)=>Number(P[k]??d);
const pBool=(k,d=false)=>String(P[k]??(d?"true":"false"))==="true";
const pStr=(k,d="")=>String(P[k]??d);

// パラメータの実体（鞄・倉庫の容量や、デフォルトの最大スタック数など）
const BAG_SLOTS=pInt("BagSlots",40);
const STORAGE_SLOTS=pInt("StorageSlots",120);
const DEF_STACK_ITEM=pInt("DefaultMaxStackItem",99);
const DEF_STACK_WEAPON=pInt("DefaultMaxStackWeapon",1);
const DEF_STACK_ARMOR=pInt("DefaultMaxStackArmor",1);

// 入力系パラメータ
const ENABLE_NUM_HOTKEYS=pBool("EnableNumberHotkeys",true);
const TOGGLE_EMPTY=pBool("ToggleEmptyOnRepress",true);
const PLACE_KEY=pStr("PlaceKey","F").toUpperCase();
const CLEAR_KEY=pStr("ClearKey","Q").toUpperCase();
const BAG_TOGGLE=pStr("BagToggleKey","B").toUpperCase();

// デザイン系（HotbarHeight は現在は未使用。SlotSize は実スロットサイズとして使用）
const HOTBAR_H=pInt("HotbarHeight",64);
const HOTBAR_SLOT=pInt("SlotSize",48);

// 鞄UI：1セルの見た目サイズや列数
const BAG_CELL=35;
const BAG_COLS=5;

// 設置ルール（JSON の配列）を安全にパースして内部表現へ落とす
function parsePlacementRules(){
  try{
    return JSON.parse(P["PlacementRules"]||"[]").map(s=>JSON.parse(s)).map(o=>({
      kind:String(o.kind||"item"),
      id:Number(o.id||1),
      charName:String(o.charName||""),
      charIndex:Number(o.charIndex||0),
      priority:Number(o.priority||1),
      onPlaceCE:Number(o.onPlaceCE||0),
      onInteractCE:Number(o.onInteractCE||0),
      pickupEnabled:String(o.pickupEnabled||"true")==="true",
    }));
  }catch(e){console.error(e);return[];}
}
const PLACEMENT_RULES=parsePlacementRules();

// 文字→キーコードの対応表（英数のみ使用）
const KEYCODES={"0":48,"1":49,"2":50,"3":51,"4":52,"5":53,"6":54,"7":55,"8":56,"9":57,
"A":65,"B":66,"C":67,"D":68,"E":69,"F":70,"G":71,"H":72,"I":73,"J":74,"K":75,"L":76,"M":77,"N":78,"O":79,"P":80,"Q":81,"R":82,"S":83,"T":84,"U":85,"V":86,"W":87,"X":88,"Y":89,"Z":90};

//----------------------------------
// Input map（独自アクションを Input.symbol にマップ）
//----------------------------------
if(ENABLE_NUM_HOTKEYS){
  // 数字キー1〜0を "hot1"〜"hot10" としてバインド
  Input.keyMapper[49]="hot1";Input.keyMapper[50]="hot2";Input.keyMapper[51]="hot3";Input.keyMapper[52]="hot4";Input.keyMapper[53]="hot5";
  Input.keyMapper[54]="hot6";Input.keyMapper[55]="hot7";Input.keyMapper[56]="hot8";Input.keyMapper[57]="hot9";Input.keyMapper[48]="hot10";
}
// F/Q/B など任意文字キーを、"hotPlace"/"hotClear"/"bagToggle" に割当
if(KEYCODES[PLACE_KEY]) Input.keyMapper[KEYCODES[PLACE_KEY]]="hotPlace";
if(KEYCODES[CLEAR_KEY]) Input.keyMapper[KEYCODES[CLEAR_KEY]]="hotClear";
if(KEYCODES[BAG_TOGGLE]) Input.keyMapper[KEYCODES[BAG_TOGGLE]]="bagToggle";

//----------------------------------
// Inventory Model（同種スタック対応の簡易インベントリ）
//----------------------------------
class StackSlot{
  // 1スロット＝(種別kind, データIDid, 個数count)
  constructor(kind,id,count){this.kind=kind;this.id=id;this.count=count||0;}
}

class Inventory{
  constructor(cap){
    this.capacity=cap;                                // 最大スロット数
    this.slots=Array.from({length:cap},()=>null);     // 各スロット（null or StackSlot）
  }
  // データベースの参照ヘルパ（種別ごとに $dataXxx を見る）
  dataObj(kind,id){if(kind==="item")return $dataItems[id]; if(kind==="weapon")return $dataWeapons[id]; if(kind==="armor")return $dataArmors[id]; return null;}
  // そのアイテムの最大スタック数（メタ指定 MaxStack が最優先。なければデフォルト）
  maxStackFor(kind,id){
    const o=this.dataObj(kind,id); if(!o)return 99;
    if(o.meta?.MaxStack)return Number(o.meta.MaxStack||1);
    if(kind==="item")return DEF_STACK_ITEM; if(kind==="weapon")return DEF_STACK_WEAPON; if(kind==="armor")return DEF_STACK_ARMOR; return 99;
  }
  // アイコン番号の取得（描画用）
  iconIndex(kind,id){const o=this.dataObj(kind,id); return o?o.iconIndex||0:0;}
  // 鞄全体での合計所持数（ホットバー用の表示に使用）
  totalCount(kind,id){let n=0; for(const s of this.slots){if(s&&s.kind===kind&&s.id===id)n+=s.count;} return n;}
  // 最初の空きスロットを探す
  firstEmptyIndex(){return this.slots.findIndex(s=>!s);}

  // アイテム追加（既存スタックを優先して詰め、余れば新規スロット。戻り値は入り切らなかった個数）
  add(kind,id,amount){
    let remain=amount; const max=this.maxStackFor(kind,id);
    // 既存スタックに詰める
    for(const s of this.slots){
      if(s&&s.kind===kind&&s.id===id&&s.count<max){
        const can=Math.min(remain,max-s.count); s.count+=can; remain-=can; if(remain<=0)return 0;
      }
    }
    // 空き枠に新スタック
    while(remain>0){
      const idx=this.firstEmptyIndex(); if(idx<0)break;
      const put=Math.min(remain,max); this.slots[idx]=new StackSlot(kind,id,put); remain-=put;
    }
    return remain; // 0なら全量入った／>0ならあふれ
  }

  // アイテム削除（複数スタックから順に引く。戻り値は取り切れずに残った個数）
  remove(kind,id,amount){
    let r=amount;
    for(let i=0;i<this.slots.length;i++){
      const s=this.slots[i]; if(!s)continue;
      if(s.kind===kind&&s.id===id&&s.count>0){
        const take=Math.min(r,s.count); s.count-=take; r-=take;
        if(s.count<=0)this.slots[i]=null;
        if(r<=0)return 0;
      }
    }
    return r; // 0なら削除完了／>0なら不足
  }
}

//----------------------------------
// Farm Manager（鞄・倉庫・ホットバーの統括 + 設置）
//----------------------------------
class FarmManager{
  constructor(){
    this.bag=new Inventory(BAG_SLOTS);                 // 鞄
    this.storage=new Inventory(STORAGE_SLOTS);         // 倉庫
    this.hotbar=Array.from({length:10},()=>null);      // ホットバー参照（{kind,id} 参照のみ。実在庫は鞄）
    this.selected=0;                                   // 手に持っている参照（0=素手, 1..10=hotbar index+1）
    this.bagOpen=false;                                // 鞄UI開閉フラグ
    this.assignMode=null;                              // 鞄→ホットバー割当モード ("move"/"swap"/null)
  }
  refreshWindows(){SceneManager._scene?.requestFarmRefresh();}

  // ホットバー参照の設定/解除/選択
  setHotbar(slot1to10,kind,id){const i=Math.max(1,Math.min(10,slot1to10))-1; this.hotbar[i]={kind,id}; this.refreshWindows();}
  clearHotbar(slot1to10){const i=Math.max(1,Math.min(10,slot1to10))-1; this.hotbar[i]=null; this.refreshWindows();}
  selectHotbar(slot1to10){
    // TOGGLE_EMPTY=true のときは同じ数字をもう一度押すと素手（0）に戻る
    const v=Math.max(1,Math.min(10,slot1to10));
    this.selected=(TOGGLE_EMPTY && this.selected===v)?0:v;
    this.refreshWindows();
  }
  setEmptyHand(){this.selected=0; this.refreshWindows();}

  // ホットバー表示用に、参照先アイテムの鞄中合計数を取得
  displayCountAt(i0){const ref=this.hotbar[i0]; if(!ref)return 0; return this.bag.totalCount(ref.kind,ref.id);}
  // 現在手に持っている参照（null=素手）
  heldRef(){if(this.selected===0)return null; return this.hotbar[this.selected-1]||null;}

  // 設置ルールの引き当て（なければデフォルトルールで置く）
  placementRuleFor(k,id){return PLACEMENT_RULES.find(r=>r.kind===k&&r.id===id)||null;}

  // プレイヤー前方のタイル取得
  frontXY(){const d=$gamePlayer.direction(); let dx=0,dy=0; if(d===2)dy=1; if(d===4)dx=-1; if(d===6)dx=1; if(d===8)dy=-1; return [$gamePlayer.x+dx,$gamePlayer.y+dy];}
  // 置ける地形か（マップ内＆イベントが既にない）
  canPlaceAt(x,y){if(!$gameMap.isValid(x,y))return false; if($gameMap.eventsXy(x,y).length>0)return false; return true;}

  // 手持ち（=ホットバー参照）を前に1個設置
  placeHeldInFront(){
    const ref=this.heldRef(); if(!ref){SoundManager.playBuzzer();return false;}
    const have=this.bag.totalCount(ref.kind,ref.id); if(have<=0){SoundManager.playBuzzer();return false;}
    const [x,y]=this.frontXY(); if(!this.canPlaceAt(x,y)){SoundManager.playBuzzer();return false;}
    const rule=this.placementRuleFor(ref.kind,ref.id)||{kind:ref.kind,id:ref.id,charName:"",charIndex:0,priority:1,onPlaceCE:0,onInteractCE:0,pickupEnabled:true};
    this.spawnPlacedEvent(x,y,ref,rule); if(rule.onPlaceCE>0)$gameTemp.reserveCommonEvent(rule.onPlaceCE);
    this.bag.remove(ref.kind,ref.id,1); this.refreshWindows(); SoundManager.playOk(); return true;
  }

  // 置き物の Game_Event を動的生成（現マップにイベント追加）
  spawnPlacedEvent(x,y,ref,rule){
    const eId=($dataMap.events?.length||0);           // 追加ID（配列末尾）
    if(!$dataMap.events)$dataMap.events=[];
    const eventData={
      id:eId,name:"PlacedItem",note:`<PlacedItem:${ref.kind}:${ref.id}>`,x,y,
      pages:[{                                           // 1ページ簡易イベント（決定時に拾い戻し等）
        conditions:{switch1Valid:false,switch2Valid:false,variableValid:false,selfSwitchValid:false,itemValid:false,actorValid:false},
        image:{tileId:0,characterName:String(rule.charName||""),characterIndex:Number(rule.charIndex||0),direction:2,pattern:1,blendMode:0,directionFix:false,opacity:255,tileId2:0},
        moveType:0,moveSpeed:3,moveFrequency:3,moveRoute:{list:[{code:0}],repeat:true,skippable:false,wait:false},
        walkAnime:false,stepAnime:false,directionFix:false,through:false,
        priorityType:Number(rule.priority||1),trigger:0,list:[{code:0,indent:0,parameters:[]}]
      }]
    };
    // データ配列に追加し、Game_Event を生成→配置→リフレッシュ→スプライト作成
    $dataMap.events[eId]=eventData; const ev=new Game_Event($gameMap._mapId,eId);
    $gameMap._events[eId]=ev; ev.locate(x,y); ev.refresh(); SceneManager._scene?._spriteset?.createEvent(ev);
  }

  // 置き物イベントに決定キーで触れた時の処理（拾い戻しやCE呼び出し）
  onPlacedEventAction(gameEvent){
    const m=(gameEvent.event().note||"").match(/<PlacedItem:(item|weapon|armor):(\d+)>/); if(!m)return;
    const kind=m[1], id=Number(m[2]); const rule=this.placementRuleFor(kind,id);
    if(rule?.onInteractCE>0)$gameTemp.reserveCommonEvent(rule.onInteractCE);
    if(!rule||rule.pickupEnabled){
      const remain=this.bag.add(kind,id,1);
      if(remain===0){SoundManager.playOk(); gameEvent.erase();} else {SoundManager.playBuzzer();}
      this.refreshWindows();
    } else {
      SoundManager.playOk();
    }
  }
}

// Game_System に FarmManager を1個ぶら下げ、グローバル getter を用意
const _Game_System_initialize=Game_System.prototype.initialize;
Game_System.prototype.initialize=function(){_Game_System_initialize.call(this); this._farmManager=new FarmManager();};
Object.defineProperty(window,"Farm",{get(){return $gameSystem._farmManager;}});

// 置き物イベントに触れたかを判定して、通常イベント起動か拾い戻しかを分岐
const _Game_Event_start=Game_Event.prototype.start;
Game_Event.prototype.start=function(){const note=this.event().note||""; if(note.includes("<PlacedItem:")){Farm.onPlacedEventAction(this); return;} _Game_Event_start.call(this);};

//----------------------------------
// Hotbar Window (Selectable)  — 1行固定のホットバー
//----------------------------------
// ★注意：Window_Selectable / Window_Base の仕様
//   - contentsHeight() は Window_Base で innerHeight を返す。
//   - innerHeight は Window（rmmz_core）の getter で「height - padding*2」。
//   - したがって、ウィンドウの内部描画領域は「高さから上下パディングを引いた値」。
//   - ここで h = SLOT + PAD*2 とすることで、innerHeight = SLOT になり、
//     1行分（itemHeight = SLOT）ちょうどが収まる設計。
class Window_FarmHotbar extends Window_Selectable {
  initialize(){
    const PAD = 4;                 // 内側パディング（上下に4pxずつ確保）
    const SLOT = HOTBAR_SLOT;      // 1スロットの見た目サイズ（アイコン枠）
    const w = Graphics.width;
    const h = SLOT + PAD * 2;      // ← 内部高さ(innerHeight) = h - PAD*2 = SLOT になる

    this._padOverride = PAD;       // standardPadding() で使うため保持
    super.initialize(new Rectangle(0, Graphics.height - h, w, h)); // 画面下に配置

    this.opacity = 192;            // 半透明
    this.deactivate();             // 通常は非アクティブ（割当モードでアクティブ化）
    this.select(0);                // 0番目を選択状態に（見た目のため）
    this._needRefresh = true;      // 遅延リフレッシュフラグ
    this.refresh();
  }

  // Window_Base#standardPadding を上書き（ここで決めないと innerHeight がズレる）
  standardPadding(){ return this._padOverride ?? 12; }

  // 1行固定の10スロット
  maxCols(){ return 10; }
  maxItems(){ return 10; }
  spacing(){ return 6; }                 // スロット間の水平スペース
  itemWidth(){  return HOTBAR_SLOT; }    // 1スロットの幅
  itemHeight(){ return HOTBAR_SLOT; }    // 1スロットの高さ
  maxRows(){ return 1; }                 // 1行のみ
  isOverflowY(){ return false; }         // 縦スクロールはしない（矢印抑止の意図）

  // スロット帯をウィンドウ内で左右中央寄せするためのXオフセット
  _centerOffsetX(){
    const cols = this.maxCols();
    const totalSlotsW = cols * this.itemWidth() + (cols - 1) * this.spacing(); // スロット列の総幅
    // contentsWidth() = innerWidth（= width - padding*2）
    return Math.max(0, Math.floor((this.contentsWidth() - totalSlotsW) / 2));
  }

  // Window_Selectable のカーソル計算と完全一致させるため、itemRect を自前定義
  itemRect(index){
    const iw = this.itemWidth();
    const ih = this.itemHeight();
    const sp = this.spacing();
    const col = index % this.maxCols();
    const x = this._centerOffsetX() + col * (iw + sp);            // 左右中央寄せ＋等間隔
    const y = Math.floor((this.contentsHeight() - ih) / 2);       // 垂直中央寄せ（innerHeight = SLOT なので概ね0）
    return new Rectangle(x, y, iw, ih);
  }

  // スロット背景を back バッファ（contentsBack）に描くと、前景と分離できる
  drawItemBackground(index){
    const r = this.itemRect(index);
    this.contentsBack.paintOpacity = 64;
    this.contentsBack.fillRect(r.x, r.y, r.width, r.height, "#000000");
    this.contentsBack.paintOpacity = 255;
  }

  // 各スロットにアイコン＋所持数（ホットバー参照の総所持数）を描画
  drawItem(index){
    this.drawItemBackground(index);
    const r = this.itemRect(index);
    const ref = Farm.hotbar[index];

    if (ref){
      // アイコン（RPGツクールの drawIcon は 32×32 を前提）
      // ※SLOT が 48 でも、drawIcon は左上(x+4,y+4)に 32px を描くので余白が出る設計
      this.drawIcon(Farm.bag.iconIndex(ref.kind, ref.id), r.x + 4, r.y + 4);
      this.contents.fontSize = 16;
      this.changeTextColor(ColorManager.normalColor());
      // 右下に合計所持数（鞄の総数）を描く
      this.drawText(String(Farm.displayCountAt(index)), r.x, r.y + r.height - 18, r.width - 4, "right");
    } else {
      // 参照なしスロットは '-' を中央表示（プレースホルダー）
      this.contents.fontSize = 16;
      this.changeTextColor(ColorManager.textColor(8));
      this.drawText("-", r.x, r.y + (r.height - 18) / 2, r.width, "center");
    }
  }

  // 手動リフレッシュ系
  refresh(){ this.contents.clear(); this.contentsBack.clear(); this.drawAllItems(); this._needRefresh = false; }
  requestRefresh(){ this._needRefresh = true; }
  update(){ super.update(); if (this._needRefresh) this.refresh(); }

  // 現在選択中のホットバー番号（1..10）。割当時の数字入力でも利用
  currentHotbarNo(){ return this.index() + 1; }
}

//----------------------------------
// Bag Windows（鞄UI本体）
//----------------------------------
// ※ここは今回の論点（ホットバー）ではありませんが、コード理解のために要点だけ注釈。
class Window_FarmBag extends Window_Selectable {
  initialize(wx, wy) {
    // rows = ceil(容量 / 5列)。fittingHeight(rows) は
    // 「行×itemHeight + window padding*2」を内部的に含めた“ちょうど良い高さ”を返す。
    const rows = Math.ceil(Farm.bag.capacity / BAG_COLS);
    const wh = this.fittingHeight(rows); // ← innerHeight が rows*itemHeight にぴったり
    const ww = BAG_COLS * (BAG_CELL + 4) + this.standardPadding() * 2; // 列幅 + 左右padding
    super.initialize(new Rectangle(wx, wy, ww, wh));
    this.activate();
    this.select(0);
    this.refresh();
  }

  standardPadding() { return 8; } // ウィンドウ内側パディング。innerHeight/innerWidth に効く
  maxCols() { return BAG_COLS; }
  maxItems() { return Farm.bag.capacity; }
  itemWidth() { return BAG_CELL + 4; }   // 1セルの見た目サイズ（背景分も考慮）
  itemHeight() { return BAG_CELL + 4; }
  spacing() { return 4; }

  itemAt(index) { return Farm.bag.slots[index] || null; }

  drawItemBackground(index) {
    const rect = this.itemRect(index);
    this.contentsBack.paintOpacity = 128;
    this.contentsBack.fillRect(rect.x, rect.y, rect.width, rect.height, "#000000");
    this.contentsBack.paintOpacity = 255;
  }

  drawItem(index) {
    this.drawItemBackground(index);
    const slot = this.itemAt(index);
    const rect = this.itemRect(index);
    if (slot) {
      const pad = 2;
      this.drawIcon(Farm.bag.iconIndex(slot.kind, slot.id), rect.x + pad, rect.y + pad);
      this.changeTextColor(ColorManager.normalColor());
      this.contents.fontSize = 16;
      this.drawText(String(slot.count), rect.x, rect.y + rect.height - 18, rect.width - 4, "right");
    } else {
      this.changeTextColor(ColorManager.textColor(8));
      this.contents.fontSize = 16;
      this.drawText("-", rect.x, rect.y + (rect.height - 18) / 2, rect.width, "center");
    }
  }
}

// 鞄のコンテキストメニュー（ホットバーに“移動/交換/やめる”）
class Window_FarmBagCommand extends Window_Command{
  initialize(x,y){ super.initialize(new Rectangle(x,y,200, this.fittingHeight(3))); this._mode=null; }
  makeCommandList(){
    this.addCommand("ホットバーへ移動","move",true);
    this.addCommand("ホットバーと交換","swap",true);
    this.addCommand("やめる","cancel",true);
  }
}

//----------------------------------
// Scene_Map 拡張（UIの生成・入出力ハンドリング）
//----------------------------------
const _Scene_Map_createAllWindows=Scene_Map.prototype.createAllWindows;
Scene_Map.prototype.createAllWindows=function(){
  _Scene_Map_createAllWindows.call(this);

  // ホットバー（下部）
  this._farmHotbar=new Window_FarmHotbar();
  this.addWindow(this._farmHotbar);

  // 鞄UI一式（右側）
  this.createFarmBagWindows();
};

Scene_Map.prototype.createFarmBagWindows=function(){
  // 右側の鞄UIの配置（高さは画面サイズからホットバーの高さを差し引くラフ計算）
  const ww=(BAG_COLS*(BAG_CELL+4)) + 16;
  const wh=Graphics.height - HOTBAR_H - 12;   // ※ここは v1.1.1 現状のまま（将来見直し余地あり）
  const wx=Graphics.width - ww - 8;
  const wy=8;

  this._farmBag=new Window_FarmBag(new Rectangle(wx,wy,ww,wh));
  this._farmBag.visible=false; this._farmBag.deactivate();
  this.addWindow(this._farmBag);

  this._farmBagCmd=new Window_FarmBagCommand(wx-4, wy+12);
  this._farmBagCmd.visible=false; this._farmBagCmd.deactivate();
  this.addWindow(this._farmBagCmd);

  // ハンドラ
  this._farmBag.setHandler("ok", this.onBagOk.bind(this));
  this._farmBag.setHandler("cancel", this.toggleBag.bind(this));

  this._farmBagCmd.setHandler("move",   ()=>this.onBagCommandChosen("move"));
  this._farmBagCmd.setHandler("swap",   ()=>this.onBagCommandChosen("swap"));
  this._farmBagCmd.setHandler("cancel", ()=>this.onBagCommandCancel());

  // ホットバー割当の決定/キャンセル
  this._farmHotbar.setHandler("ok",     this.onHotbarAssignOk.bind(this));
  this._farmHotbar.setHandler("cancel", this.onHotbarAssignCancel.bind(this));
};

// 画面の再描画要求（鞄が開いている場合だけ鞄も更新）
Scene_Map.prototype.requestFarmRefresh=function(){
  this._farmHotbar?.requestRefresh();
  if(this._farmBag?.visible) this._farmBag.refresh();
};

// 鞄UIのトグル（Bキー/プラグインコマンド）
Scene_Map.prototype.toggleBag=function(){
  Farm.bagOpen=!Farm.bagOpen;
  if(Farm.bagOpen){
    this._farmBag.visible=true; this._farmBag.activate(); this._farmBag.select(0);
    this._farmBagCmd.visible=false; this._farmBagCmd.deactivate();
  }else{
    this._farmBag.visible=false; this._farmBag.deactivate();
    this._farmBagCmd.visible=false; this._farmBagCmd.deactivate();
    // 割当モードを抜ける（ホットバーは非アクティブへ）
    Farm.assignMode=null; this._farmHotbar.deactivate();
  }
  SoundManager.playCursor();
};

// 鞄スロット決定→横にコマンドを出す
Scene_Map.prototype.onBagOk=function(){
  const slot=this._farmBag.itemAt(this._farmBag.index());
  if(!slot){ SoundManager.playBuzzer(); this._farmBag.activate(); return; }
  // アイテムの行の位置（itemRect）を基準に、左側へメニューを出す
  const r=this._farmBag.itemRect(this._farmBag.index());
  const x=Math.max(this._farmBag.x - 204, 8);
  const y=this._farmBag.y + r.y;
  this._farmBagCmd.move(x,y,200,this._farmBagCmd.height);
  this._farmBagCmd.visible=true; this._farmBagCmd.activate(); this._farmBagCmd.select(0);
};

// 「移動 or 交換」を選んだ → ホットバーをアクティブにして割当先を選ばせる
Scene_Map.prototype.onBagCommandChosen=function(mode){
  Farm.assignMode=mode; // "move" | "swap"
  this._farmBagCmd.visible=false; this._farmBagCmd.deactivate();

  // ホットバーにフォーカス移動。初期カーソル位置は現在選択中（なければ0）
  this._farmHotbar.activate();
  const initIndex = Math.max(0, Math.min(9, (Farm.selected||1)-1));
  this._farmHotbar.select(initIndex);
};

Scene_Map.prototype.onBagCommandCancel=function(){
  this._farmBagCmd.visible=false; this._farmBagCmd.deactivate();
  this._farmBag.activate();
};

// ホットバーでOK：選択したスロット番号（1..10）に鞄参照を割当
Scene_Map.prototype.onHotbarAssignOk=function(){
  if(!Farm.assignMode){ this.onHotbarAssignCancel(); return; }
  const bagIndex=this._farmBag.index();
  const slot=this._farmBag.itemAt(bagIndex);
  if(!slot){ SoundManager.playBuzzer(); this.onHotbarAssignCancel(); return; }

  const hbNo=this._farmHotbar.currentHotbarNo(); // 1..10
  if(Farm.assignMode==="move"){
    Farm.setHotbar(hbNo, slot.kind, slot.id);
  }else if(Farm.assignMode==="swap"){
    const prev=Farm.hotbar[hbNo-1];
    Farm.setHotbar(hbNo, slot.kind, slot.id);
    // 現仕様：鞄側の中身（スタック/位置）は動かさない。ホットバー参照だけ差し替え。
  }
  SoundManager.playOk();

  // 見た目更新
  this._farmHotbar.requestRefresh();
  if(this._farmBag.visible) this._farmBag.refresh();

  // フォーカスを鞄へ戻す
  Farm.assignMode=null;
  this._farmHotbar.deactivate();
  this._farmBag.activate();
};

Scene_Map.prototype.onHotbarAssignCancel=function(){
  SoundManager.playCancel();
  Farm.assignMode=null;
  this._farmHotbar.deactivate();
  this._farmBag.activate();
};

// 入力更新
const _Scene_Map_update=Scene_Map.prototype.update;
Scene_Map.prototype.update=function(){
  _Scene_Map_update.call(this);

  // Bで鞄トグル
  if(Input.isTriggered("bagToggle")) this.toggleBag();

  // 通常操作（鞄が閉じており、割当モードでもないとき）
  if(!Farm.bagOpen && !Farm.assignMode){
    // 数字キーでホットバー選択（TOGGLE_EMPTY が true だと二度押しで素手）
    if(ENABLE_NUM_HOTKEYS){
      for(let i=1;i<=10;i++){const sym=(i===10)?"hot10":("hot"+i); if(Input.isTriggered(sym)) Farm.selectHotbar(i);}
    }
    // Q：素手、F：前に設置
    if(Input.isTriggered("hotClear")) Farm.setEmptyHand();
    if(Input.isTriggered("hotPlace")) Farm.placeHeldInFront();
  }

  // 割当モード中：数字キーでホットバーのスロットを即決定できるショートカット
  if(Farm.assignMode){
    for(let i=1;i<=10;i++){
      const sym=(i===10)?"hot10":("hot"+i);
      if(Input.isTriggered(sym)){
        this._farmHotbar.select(i-1);
        this.onHotbarAssignOk();
        break;
      }
    }
  }
};

//----------------------------------
// Plugin Commands（イベントコマンドから操作可能に）
//----------------------------------
PluginManager.registerCommand(PLUGIN_NAME,"GiveItem",args=>{
  const kind=String(args.kind||"item"); const id=Number(args.id||1); const n=Number(args.amount||1);
  const left=Farm.bag.add(kind,id,n); if(left>0) console.warn(`[Farm] 鞄に入り切らなかった: ${left}`);
  SceneManager._scene?.requestFarmRefresh();
});
PluginManager.registerCommand(PLUGIN_NAME,"HotbarAssign",args=>{
  const slot=Number(args.slot||1); const kind=String(args.kind||"item"); const id=Number(args.id||1);
  Farm.setHotbar(slot,kind,id);
});
PluginManager.registerCommand(PLUGIN_NAME,"HotbarClear",args=>{
  const slot=Number(args.slot||1); Farm.clearHotbar(slot);
});
PluginManager.registerCommand(PLUGIN_NAME,"PlaceHeldItem",args=>{
  Farm.placeHeldInFront();
});
PluginManager.registerCommand(PLUGIN_NAME,"OpenBag",args=>{
  SceneManager._scene?.toggleBag();
});
PluginManager.registerCommand(PLUGIN_NAME,"OpenStorage",args=>{
  console.log("[Farm] OpenStorage (UIは今はダミー)");
});

})();
