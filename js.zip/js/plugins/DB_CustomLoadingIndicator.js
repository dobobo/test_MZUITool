/*:
 * @target MZ
 * @plugindesc 読み込み中のくるくるを任意画像のコマ送り表示に差し替え、必要に応じてローディングバーも表示します。
 * @author OpenAI
 * @url https://openai.com
 *
 * @help
 * 読み込み中に表示される標準のくるくるを非表示にし、
 * img/system の任意画像を使ったコマ送りアニメーションに置き換えます。
 *
 * 画像は横並びスプライトシートを想定しています。
 * 例:
 * - 300x100 の画像
 * - 1コマ 100x100
 * - フレーム数 3
 *
 * その場合、以下のように設定します。
 * - スピナー画像: 画像ファイル名
 * - 1コマの幅: 100
 * - 1コマの高さ: 100
 * - フレーム数: 3
 *
 * 座標はゲーム画面左上基準です。
 * 画面拡大・縮小時もゲーム画面座標として追従します。
 *
 * ローディングバーはオプションです。
 * - 自動: 取得できる範囲で進捗率を表示。取得できない場合は往復しない流れるバー表示
 * - 進捗: 取得できる範囲で進捗率を表示。取得不可なら不定バーにフォールバック
 * - 不定: 常に流れるバー表示
 *
 * 画像を空欄にした場合は、スピナー画像なしでバーだけ表示できます。
 *
 * プラグインコマンド:
 * - ローディング表示モード変更
 *   custom    : このプラグインの画像とバーを使用します。
 *   blackout  : 黒一色のみ表示します。
 *   default   : RPGツクールMZ標準のくるくる表示に戻します。
 *
 * 追加仕様:
 * - 表示モードが default / blackout の場合でも、
 *   ロード画面(Scene_Load)からセーブデータを読み込んだ時だけは
 *   その読み込み中に限り custom 表示を強制します。
 *   読み込み完了後は、元の表示モード運用へ戻ります。
 *
 * SunD_VRM の読込待ちにも対応しています。
 * Scene_Map.isReady() 内で SunD_VRM.isReady() を待っている間、
 * VRM読込進捗をローディングバーへ合算します。
 *
 * @command setLoadingMode
 * @text ローディング表示モード変更
 * @desc ローディング表示の方式を切り替えます。
 *
 * @arg mode
 * @text 表示モード
 * @type select
 * @default custom
 *
 * @option カスタム表示
 * @value custom
 * @option 黒画面のみ
 * @value blackout
 * @option デフォルト表示
 * @value default
 *
 * @param initialMode
 * @text 初期表示モード
 * @type select
 * @default custom
 *
 * @option カスタム表示
 * @value custom
 * @option 黒画面のみ
 * @value blackout
 * @option デフォルト表示
 * @value default
 *
 * @param spinnerImage
 * @text スピナー画像
 * @type file
 * @dir img/system
 * @default
 * @desc img/system 内の画像を指定します。拡張子 .png は不要です。
 *
 * @param spinnerX
 * @text スピナーX座標
 * @type number
 * @default 360
 * @min -99999
 * @desc ゲーム画面左上基準のX座標です。
 *
 * @param spinnerY
 * @text スピナーY座標
 * @type number
 * @default 240
 * @min -99999
 * @desc ゲーム画面左上基準のY座標です。
 *
 * @param frameWidth
 * @text 1コマの幅
 * @type number
 * @default 100
 * @min 1
 *
 * @param frameHeight
 * @text 1コマの高さ
 * @type number
 * @default 100
 * @min 1
 *
 * @param frameCount
 * @text フレーム数
 * @type number
 * @default 3
 * @min 1
 *
 * @param frameWait
 * @text 1コマの待機フレーム数
 * @type number
 * @default 6
 * @min 1
 * @desc 60fps基準です。6なら約0.1秒ごとに切り替わります。
 *
 * @param zIndex
 * @text 表示優先度(z-index)
 * @type number
 * @default 99
 * @min 1
 *
 * @param smooth
 * @text スムージング
 * @type boolean
 * @on 有効
 * @off 無効
 * @default true
 * @desc 拡大時の補間です。ドット絵なら無効推奨です。
 *
 * @param showBar
 * @text ローディングバーを表示
 * @type boolean
 * @on 表示
 * @off 非表示
 * @default false
 *
 * @param barMode
 * @text バーの表示方式
 * @type select
 * @option 自動
 * @value auto
 * @option 進捗率
 * @value progress
 * @option 不定
 * @value indeterminate
 * @default auto
 *
 * @param barOffsetX
 * @text バー相対X
 * @type number
 * @default 0
 * @min -99999
 * @desc スピナー座標からの相対Xです。
 *
 * @param barOffsetY
 * @text バー相対Y
 * @type number
 * @default 110
 * @min -99999
 * @desc スピナー座標からの相対Yです。
 *
 * @param barWidth
 * @text バー幅
 * @type number
 * @default 180
 * @min 1
 *
 * @param barHeight
 * @text バー高さ
 * @type number
 * @default 12
 * @min 1
 *
 * @param barRadius
 * @text バー角丸
 * @type number
 * @default 6
 * @min 0
 *
 * @param barBackgroundColor
 * @text バー背景色
 * @type string
 * @default rgba(0, 0, 0, 0.45)
 *
 * @param barFillColor
 * @text バー充填色
 * @type string
 * @default rgba(255, 255, 255, 0.95)
 *
 * @param barBorderColor
 * @text バー枠色
 * @type string
 * @default rgba(255, 255, 255, 0.65)
 *
 * @param indeterminateSpeed
 * @text 不定バー速度
 * @type number
 * @default 180
 * @min 1
 * @desc px/秒。
 *
 * @param indeterminateSegmentRate
 * @text 不定バーの長さ割合
 * @type number
 * @default 0.35
 * @decimals 2
 * @min 0.05
 * @max 1.00
 * @desc バー全体に対する不定バーの長さ割合です。
 */

(() => {
    "use strict";

    const pluginName = document.currentScript.src.match(/([^/]+)\.js$/i)[1];
    const params = PluginManager.parameters(pluginName);

    const toNumber = (value, defaultValue) => {
        const number = Number(value);
        return Number.isFinite(number) ? number : defaultValue;
    };

    const toBoolean = (value, defaultValue) => {
        if (value === true || value === "true") return true;
        if (value === false || value === "false") return false;
        return defaultValue;
    };

    const settings = {
        initialMode: String(params.initialMode || "custom").trim().toLowerCase(),
        spinnerImage: String(params.spinnerImage || "").trim(),
        spinnerX: toNumber(params.spinnerX, 360),
        spinnerY: toNumber(params.spinnerY, 240),
        frameWidth: Math.max(1, toNumber(params.frameWidth, 100)),
        frameHeight: Math.max(1, toNumber(params.frameHeight, 100)),
        frameCount: Math.max(1, toNumber(params.frameCount, 3)),
        frameWait: Math.max(1, toNumber(params.frameWait, 6)),
        zIndex: Math.max(1, toNumber(params.zIndex, 99)),
        smooth: toBoolean(params.smooth, true),
        showBar: toBoolean(params.showBar, false),
        barMode: String(params.barMode || "auto"),
        barOffsetX: toNumber(params.barOffsetX, 0),
        barOffsetY: toNumber(params.barOffsetY, 110),
        barWidth: Math.max(1, toNumber(params.barWidth, 180)),
        barHeight: Math.max(1, toNumber(params.barHeight, 12)),
        barRadius: Math.max(0, toNumber(params.barRadius, 6)),
        barBackgroundColor: String(params.barBackgroundColor || "rgba(0, 0, 0, 0.45)"),
        barFillColor: String(params.barFillColor || "rgba(255, 255, 255, 0.95)"),
        barBorderColor: String(params.barBorderColor || "rgba(255, 255, 255, 0.65)"),
        indeterminateSpeed: Math.max(1, toNumber(params.indeterminateSpeed, 180)),
        indeterminateSegmentRate: Math.min(1, Math.max(0.05, toNumber(params.indeterminateSegmentRate, 0.35)))
    };

    const PROGRESS_WEIGHT = {
        whenVrmActive: {
            other: 0.12,
            vrm: 0.88
        }
    };

    const state = {
        spinnerBitmap: null,
        mapLoading: false,
        lastFrameIndex: -1,
        lastUpdateTime: performance.now(),
        pendingMode: null,
        forceCustomDuringCurrentLoading: false,
        vrm: {
            hooked: false,
            active: false,
            totalItems: 0,
            items: new Map()
        }
    };

    function loadSpinnerBitmap() {
        if (!settings.spinnerImage) {
            return null;
        }
        if (!state.spinnerBitmap) {
            state.spinnerBitmap = ImageManager.loadSystem(settings.spinnerImage);
            if (state.spinnerBitmap) {
                state.spinnerBitmap.smooth = settings.smooth;
            }
        }
        return state.spinnerBitmap;
    }

    function loadingRoot() {
        return Graphics._loadingSpinner || null;
    }

    function loadingImageDiv() {
        const root = loadingRoot();
        return root ? root.querySelector("#loadingSpinnerImage") : null;
    }

    function loadingCanvas() {
        const root = loadingRoot();
        return root ? root.querySelector(".db-loading-spinner-canvas") : null;
    }

    function loadingBar() {
        const root = loadingRoot();
        return root ? root.querySelector(".db-loading-bar") : null;
    }

    function loadingBarFill() {
        const root = loadingRoot();
        return root ? root.querySelector(".db-loading-bar-fill") : null;
    }

    function canvasRect() {
        const canvas = Graphics._canvas;
        if (canvas && typeof canvas.getBoundingClientRect === "function") {
            const rect = canvas.getBoundingClientRect();
            return {
                left: Number.isFinite(rect.left) ? rect.left : 0,
                top: Number.isFinite(rect.top) ? rect.top : 0,
                width: Number.isFinite(rect.width) ? rect.width : 0,
                height: Number.isFinite(rect.height) ? rect.height : 0
            };
        }
        const scale = Graphics._realScale || 1;
        return {
            left: canvas ? (canvas.offsetLeft || 0) : 0,
            top: canvas ? (canvas.offsetTop || 0) : 0,
            width: Graphics.width * scale,
            height: Graphics.height * scale
        };
    }

    function normalizeViewportOverflow() {
        const docEl = document.documentElement;
        if (docEl) {
            docEl.style.overflow = "hidden";
        }
        if (document.body) {
            document.body.style.overflow = "hidden";
        }
    }

    function normalizeMode(mode) {
        const value = String(mode || "").trim().toLowerCase();
        if (value === "default" || value === "blackout" || value === "custom") {
            return value;
        }
        return "custom";
    }

    function currentMode() {
        if (state.forceCustomDuringCurrentLoading) {
            return "custom";
        }
        if ($gameSystem && $gameSystem._dbCustomLoadingIndicatorMode) {
            return normalizeMode($gameSystem._dbCustomLoadingIndicatorMode);
        }
        if (state.pendingMode) {
            return normalizeMode(state.pendingMode);
        }
        return normalizeMode(settings.initialMode);
    }

    function isCustomMode() {
        return currentMode() === "custom";
    }

    function isDefaultMode() {
        return currentMode() === "default";
    }

    function isBlackoutMode() {
        return currentMode() === "blackout";
    }

    function setCurrentMode(mode) {
        const normalized = normalizeMode(mode);
        state.pendingMode = normalized;
        if ($gameSystem) {
            $gameSystem._dbCustomLoadingIndicatorMode = normalized;
        }
        refreshCurrentLoadingAppearance();
    }

    function resetVrmTracker() {
        state.vrm.active = false;
        state.vrm.totalItems = 0;
        state.vrm.items.clear();
    }

    function markVrmPendingKeys(keys) {
        resetVrmTracker();
        state.vrm.active = true;
        state.vrm.totalItems = keys.length;
        for (const key of keys) {
            state.vrm.items.set(String(key), { loaded: 0, total: 0, done: false, error: false });
        }
    }

    function ensureVrmTrackerItem(key) {
        const trackerKey = String(key);
        let item = state.vrm.items.get(trackerKey);
        if (!item) {
            item = { loaded: 0, total: 0, done: false, error: false };
            state.vrm.items.set(trackerKey, item);
            state.vrm.totalItems += 1;
            state.vrm.active = true;
        }
        return item;
    }

    function markVrmProgress(key, progressEvent) {
        const item = ensureVrmTrackerItem(key);
        const loaded = Number(progressEvent && progressEvent.loaded || 0);
        const total = Number(progressEvent && progressEvent.total || 0);
        if (Number.isFinite(loaded) && loaded > item.loaded) {
            item.loaded = loaded;
        }
        if (Number.isFinite(total) && total > 0) {
            item.total = total;
            if (item.loaded > total) {
                item.loaded = total;
            }
        }
    }

    function markVrmDone(key, isError) {
        const item = ensureVrmTrackerItem(key);
        item.done = true;
        item.error = !!isError;
        if (!(item.total > 0)) {
            item.total = 1;
        }
        item.loaded = item.total;
    }

    function computeSunDVrmPendingKeys(SUND_VRM) {
        if (!SUND_VRM || !$gameParty || !$gameParty._sundVRM) {
            return [];
        }
        const loadSet = new Set();
        const data = $gameParty._sundVRM;

        if (SUND_VRM._params && SUND_VRM._params.loadModels) {
            SUND_VRM._params.loadModels.forEach(keyName => loadSet.add(keyName));
        }

        if (!DataManager.isEventTest() && window.$dataMap && $dataMap.meta && $dataMap.meta["Load_VRM"]) {
            const keys = SUND_VRM.modelKeyToArray($dataMap.meta["Load_VRM"]);
            keys.forEach(key => loadSet.add(key));
        }

        if (SUND_VRM._afterContinue && Array.isArray(data.modelSaveData)) {
            data.modelSaveData.forEach(el => {
                if (el && el.keyName) {
                    loadSet.add(el.keyName);
                }
            });
        }

        const pending = [];
        loadSet.forEach(keyName => {
            if (SUND_VRM.isLoadSkipModel && SUND_VRM.isLoadSkipModel(keyName)) {
                return;
            }
            const obj = window.$sundVRMs && $sundVRMs.get ? $sundVRMs.get(keyName) : null;
            if (!obj || !obj._loaded) {
                pending.push(keyName);
            }
        });
        return pending;
    }

    function ensureSunDVrmHooks() {
        if (state.vrm.hooked) {
            return;
        }
        const SUND_VRM = window.SUND_VRM;
        if (!SUND_VRM || typeof SUND_VRM.loadVRM !== "function") {
            return;
        }
        state.vrm.hooked = true;

        const _SUND_VRM_mapLoadVRM = SUND_VRM.mapLoadVRM;
        SUND_VRM.mapLoadVRM = function() {
            try {
                markVrmPendingKeys(computeSunDVrmPendingKeys(this));
            } catch (e) {
                resetVrmTracker();
            }
            return _SUND_VRM_mapLoadVRM.apply(this, arguments);
        };

        SUND_VRM.loadVRM = function(keyName, fileName) {
            ensureVrmTrackerItem(keyName);
            this.loader.load(
                "./vrm/" + fileName + ".vrm",
                gltf => {
                    markVrmDone(keyName, false);
                    this.setupVRM(keyName, gltf);
                },
                progress => {
                    markVrmProgress(keyName, progress);
                },
                error => {
                    markVrmDone(keyName, true);
                    console.error(error);
                }
            );
        };
    }

    function vrmProgressRate() {
        ensureSunDVrmHooks();
        const SUND_VRM = window.SUND_VRM;
        if (!SUND_VRM) {
            return null;
        }
        const readyState = String(SUND_VRM._readyState || "");
        const tracker = state.vrm;
        const busy = readyState === "start" || readyState === "loading" || readyState === "trialRender" || readyState === "restore";
        if (!busy && readyState !== "finished" && !tracker.active) {
            return null;
        }

        const itemTotal = Math.max(0, tracker.totalItems);
        let loaded = 0;
        let total = 0;
        tracker.items.forEach(item => {
            if (item.total > 0) {
                total += item.total;
                loaded += Math.max(0, Math.min(item.loaded, item.total));
            } else {
                total += 1;
                loaded += item.done || item.error ? 1 : 0;
            }
        });

        let loadingRate = 0;
        if (total > 0) {
            loadingRate = loaded / total;
        } else if (itemTotal === 0 && busy) {
            loadingRate = 1;
        }
        loadingRate = Math.max(0, Math.min(1, loadingRate));

        switch (readyState) {
            case "start":
                return 0;
            case "loading":
                return loadingRate * 0.9;
            case "trialRender":
                return 0.95;
            case "restore":
                return 0.98;
            case "finished":
                return 1;
            default:
                if (tracker.active) {
                    return loadingRate * 0.9;
                }
                return null;
        }
    }

    function removeCustomChildren(root) {
        if (!root) {
            return;
        }
        const selectors = [
            ".db-loading-spinner-canvas",
            ".db-loading-bar",
            ".db-loading-blackout"
        ];
        selectors.forEach(selector => {
            root.querySelectorAll(selector).forEach(node => node.remove());
        });
    }

    function clearDefaultInlineStyles(root) {
        if (!root) {
            return;
        }
        root.removeAttribute("style");
        const imageDiv = loadingImageDiv();
        if (imageDiv) {
            imageDiv.removeAttribute("style");
        }
    }

    function applyDefaultLoadingAppearance() {
        const root = loadingRoot();
        if (!root) {
            return;
        }
        removeCustomChildren(root);
        clearDefaultInlineStyles(root);
    }

    function applyBlackoutLoadingAppearance() {
        const root = loadingRoot();
        if (!root || !Graphics._canvas) {
            return;
        }
        removeCustomChildren(root);
        setupRootStyle(root);
        const imageDiv = loadingImageDiv();
        if (imageDiv) {
            imageDiv.style.display = "none";
        }
        const rect = canvasRect();
        root.style.left = Math.round(rect.left) + "px";
        root.style.top = Math.round(rect.top) + "px";
        root.style.width = Math.round(rect.width) + "px";
        root.style.height = Math.round(rect.height) + "px";
        root.style.background = "#000000";
    }

    function refreshCurrentLoadingAppearance() {
        const root = loadingRoot();
        if (!root || !document.getElementById("loadingSpinner")) {
            return;
        }
        if (isDefaultMode()) {
            applyDefaultLoadingAppearance();
        } else if (isBlackoutMode()) {
            applyBlackoutLoadingAppearance();
        } else {
            ensureLoadingElements();
            updateScaledLayout();
            drawSpinnerFrame(true);
            updateLoadingBar();
        }
    }

    function setupRootStyle(root) {
        normalizeViewportOverflow();
        root.style.position = "fixed";
        root.style.left = "0px";
        root.style.top = "0px";
        root.style.right = "auto";
        root.style.bottom = "auto";
        root.style.margin = "0";
        root.style.padding = "0";
        root.style.width = "0px";
        root.style.height = "0px";
        root.style.pointerEvents = "none";
        root.style.zIndex = String(settings.zIndex);
        root.style.overflow = "visible";
        root.style.background = "transparent";
        root.style.border = "none";
        root.style.boxShadow = "none";
    }

    function setupImageDivStyle(imageDiv) {
        imageDiv.style.position = "absolute";
        imageDiv.style.left = "0px";
        imageDiv.style.top = "0px";
        imageDiv.style.margin = "0";
        imageDiv.style.padding = "0";
        imageDiv.style.border = "none";
        imageDiv.style.borderRadius = "0";
        imageDiv.style.background = "transparent";
        imageDiv.style.boxShadow = "none";
        imageDiv.style.opacity = "1";
        imageDiv.style.animation = "none";
        imageDiv.style.transform = "none";
        imageDiv.style.overflow = "hidden";
        imageDiv.style.display = settings.spinnerImage ? "block" : "none";
    }

    function ensureCanvasElement(imageDiv) {
        let canvas = imageDiv.querySelector(".db-loading-spinner-canvas");
        if (!canvas) {
            canvas = document.createElement("canvas");
            canvas.className = "db-loading-spinner-canvas";
            imageDiv.appendChild(canvas);
        }
        canvas.width = settings.frameWidth;
        canvas.height = settings.frameHeight;
        canvas.style.display = "block";
        canvas.style.width = "100%";
        canvas.style.height = "100%";
        canvas.style.margin = "0";
        canvas.style.padding = "0";
        canvas.style.imageRendering = settings.smooth ? "auto" : "pixelated";
        return canvas;
    }

    function ensureBarElements(root) {
        const oldBar = root.querySelector(".db-loading-bar");
        if (!settings.showBar) {
            if (oldBar) {
                oldBar.remove();
            }
            return;
        }
        if (oldBar) {
            return;
        }
        const bar = document.createElement("div");
        const fill = document.createElement("div");
        bar.className = "db-loading-bar";
        fill.className = "db-loading-bar-fill";
        bar.appendChild(fill);
        root.appendChild(bar);
    }

    function ensureLoadingElements() {
        const root = loadingRoot();
        if (!root) {
            return;
        }
        setupRootStyle(root);
        const imageDiv = loadingImageDiv();
        if (imageDiv) {
            setupImageDivStyle(imageDiv);
            ensureCanvasElement(imageDiv);
        }
        ensureBarElements(root);
    }

    function updateScaledLayout() {
        const root = loadingRoot();
        if (!root || !Graphics._canvas) {
            return;
        }
        if (isDefaultMode()) {
            return;
        }
        if (isBlackoutMode()) {
            applyBlackoutLoadingAppearance();
            return;
        }

        const scale = Graphics._realScale || 1;
        const rect = canvasRect();
        const left = Math.round(rect.left + settings.spinnerX * scale);
        const top = Math.round(rect.top + settings.spinnerY * scale);
        root.style.left = left + "px";
        root.style.top = top + "px";

        const imageDiv = loadingImageDiv();
        if (imageDiv) {
            imageDiv.style.display = settings.spinnerImage ? "block" : "none";
            imageDiv.style.width = Math.round(settings.frameWidth * scale) + "px";
            imageDiv.style.height = Math.round(settings.frameHeight * scale) + "px";
        }

        const bar = loadingBar();
        if (bar) {
            bar.style.position = "absolute";
            bar.style.left = Math.round(settings.barOffsetX * scale) + "px";
            bar.style.top = Math.round(settings.barOffsetY * scale) + "px";
            bar.style.width = Math.round(settings.barWidth * scale) + "px";
            bar.style.height = Math.round(settings.barHeight * scale) + "px";
            bar.style.overflow = "hidden";
            bar.style.background = settings.barBackgroundColor;
            bar.style.border = "1px solid " + settings.barBorderColor;
            bar.style.borderRadius = Math.round(settings.barRadius * scale) + "px";
            bar.style.boxSizing = "border-box";

            const fill = loadingBarFill();
            if (fill) {
                fill.style.position = "absolute";
                fill.style.left = "0px";
                fill.style.top = "0px";
                fill.style.height = "100%";
                fill.style.background = settings.barFillColor;
                fill.style.borderRadius = "inherit";
                fill.style.transform = "translateX(0px)";
            }
        }
    }

    function currentFrameIndex() {
        const frameMs = settings.frameWait * (1000 / 60);
        return Math.floor(performance.now() / frameMs) % settings.frameCount;
    }

    function drawSpinnerFrame(forceRedraw) {
        if (!isCustomMode()) {
            return;
        }
        const imageDiv = loadingImageDiv();
        const canvas = loadingCanvas();
        if (!imageDiv || !canvas) {
            return;
        }
        if (!settings.spinnerImage) {
            imageDiv.style.display = "none";
            return;
        }
        imageDiv.style.display = "block";
        const bitmap = loadSpinnerBitmap();
        if (!bitmap || !bitmap.isReady()) {
            return;
        }
        const frameIndex = currentFrameIndex();
        if (!forceRedraw && state.lastFrameIndex === frameIndex) {
            return;
        }
        state.lastFrameIndex = frameIndex;

        const context = canvas.getContext("2d");
        const image = bitmap.canvas || bitmap.image;
        if (!context || !image) {
            return;
        }
        context.clearRect(0, 0, canvas.width, canvas.height);
        context.imageSmoothingEnabled = settings.smooth;
        const sx = frameIndex * settings.frameWidth;
        const sy = 0;
        context.drawImage(
            image,
            sx,
            sy,
            settings.frameWidth,
            settings.frameHeight,
            0,
            0,
            settings.frameWidth,
            settings.frameHeight
        );
    }

    function countBitmapProgress(cache) {
        let total = 0;
        let loaded = 0;
        for (const url in cache) {
            const bitmap = cache[url];
            if (!bitmap) {
                continue;
            }
            total += 1;
            if (bitmap.isReady() || bitmap.isError()) {
                loaded += 1;
            }
        }
        return { total, loaded };
    }

    function countFontProgress() {
        let total = 0;
        let loaded = 0;
        if (!window.FontManager || !FontManager._states) {
            return { total, loaded };
        }
        for (const family in FontManager._states) {
            total += 1;
            const stateValue = FontManager._states[family];
            if (stateValue !== "loading") {
                loaded += 1;
            }
        }
        return { total, loaded };
    }

    function countEffectProgress() {
        let total = 0;
        let loaded = 0;
        if (!window.EffectManager || !EffectManager._cache) {
            return { total, loaded };
        }
        for (const url in EffectManager._cache) {
            const effect = EffectManager._cache[url];
            if (!effect) {
                continue;
            }
            total += 1;
            if (effect.isLoaded) {
                loaded += 1;
            }
        }
        return { total, loaded };
    }

    function countDatabaseProgress() {
        let total = 0;
        let loaded = 0;
        if (!window.DataManager || !Array.isArray(DataManager._databaseFiles)) {
            return { total, loaded };
        }
        for (const databaseFile of DataManager._databaseFiles) {
            total += 1;
            if (window[databaseFile.name]) {
                loaded += 1;
            }
        }
        if (state.mapLoading) {
            total += 1;
            if (window.$dataMap) {
                loaded += 1;
            }
        }
        return { total, loaded };
    }

    function totalProgressRate() {
        const bitmapCache1 = countBitmapProgress(ImageManager._cache || {});
        const bitmapCache2 = countBitmapProgress(ImageManager._system || {});
        const fonts = countFontProgress();
        const effects = countEffectProgress();
        const databases = countDatabaseProgress();
        const vrmRate = vrmProgressRate();

        const otherTotal = bitmapCache1.total + bitmapCache2.total + fonts.total + effects.total + databases.total;
        const otherLoaded = bitmapCache1.loaded + bitmapCache2.loaded + fonts.loaded + effects.loaded + databases.loaded;
        const otherRate = otherTotal > 0 ? Math.max(0, Math.min(1, otherLoaded / otherTotal)) : null;

        if (vrmRate !== null) {
            const weight = PROGRESS_WEIGHT.whenVrmActive;
            const resolvedOtherRate = otherRate !== null ? otherRate : 1;
            const composite = resolvedOtherRate * weight.other + vrmRate * weight.vrm;
            return Math.max(0, Math.min(1, composite));
        }

        if (otherRate !== null) {
            return otherRate;
        }
        return null;
    }

    function updateLoadingBar() {
        if (!isCustomMode()) {
            return;
        }
        if (!settings.showBar) {
            return;
        }
        const bar = loadingBar();
        const fill = loadingBarFill();
        if (!bar || !fill) {
            return;
        }
        const width = bar.clientWidth || Math.round(settings.barWidth * (Graphics._realScale || 1));
        const useProgress = settings.barMode !== "indeterminate";
        const progressRate = useProgress ? totalProgressRate() : null;

        if (progressRate !== null) {
            const fillWidth = Math.max(0, Math.min(width, Math.round(width * progressRate)));
            fill.style.width = fillWidth + "px";
            fill.style.transform = "translateX(0px)";
            return;
        }

        const segmentWidth = Math.max(8, Math.round(width * settings.indeterminateSegmentRate));
        const cycleWidth = width + segmentWidth;
        const timeSec = performance.now() / 1000;
        const x = Math.round((timeSec * settings.indeterminateSpeed) % cycleWidth) - segmentWidth;
        fill.style.width = segmentWidth + "px";
        fill.style.transform = `translateX(${x}px)`;
    }

    const _Graphics_createLoadingSpinner = Graphics._createLoadingSpinner;
    Graphics._createLoadingSpinner = function() {
        _Graphics_createLoadingSpinner.apply(this, arguments);
        normalizeViewportOverflow();
        const root = loadingRoot();
        if (root) {
            root.style.display = "none";
            root.style.visibility = "hidden";
        }
        if (isDefaultMode()) {
            applyDefaultLoadingAppearance();
        } else if (isBlackoutMode()) {
            applyBlackoutLoadingAppearance();
        } else {
            ensureLoadingElements();
            updateScaledLayout();
            drawSpinnerFrame(true);
            updateLoadingBar();
        }
        if (root) {
            root.style.visibility = "visible";
            root.style.display = "block";
        }
    };

    const _Graphics_startLoading = Graphics.startLoading;
    Graphics.startLoading = function() {
        ensureSunDVrmHooks();
        normalizeViewportOverflow();
        // 表示開始前に見た目を先に確定して、標準位置(右下)の一瞬表示を防ぐ。
        refreshCurrentLoadingAppearance();
        updateScaledLayout();
        drawSpinnerFrame(true);
        updateLoadingBar();
        _Graphics_startLoading.apply(this, arguments);
        refreshCurrentLoadingAppearance();
        updateScaledLayout();
        drawSpinnerFrame(true);
        updateLoadingBar();
    };

    const _Graphics_endLoading = Graphics.endLoading;
    Graphics.endLoading = function() {
        state.lastFrameIndex = -1;
        state.forceCustomDuringCurrentLoading = false;
        resetVrmTracker();
        return _Graphics_endLoading.apply(this, arguments);
    };

    const _Graphics_updateAllElements = Graphics._updateAllElements;
    Graphics._updateAllElements = function() {
        _Graphics_updateAllElements.apply(this, arguments);
        refreshCurrentLoadingAppearance();
        updateScaledLayout();
    };

    const _Graphics_onTick = Graphics._onTick;
    Graphics._onTick = function(deltaTime) {
        _Graphics_onTick.apply(this, arguments);
        if (document.getElementById("loadingSpinner")) {
            refreshCurrentLoadingAppearance();
            updateScaledLayout();
            drawSpinnerFrame(false);
            updateLoadingBar();
        }
    };

    PluginManager.registerCommand(pluginName, "setLoadingMode", args => {
        setCurrentMode(args.mode);
    });

    const _Game_System_initialize = Game_System.prototype.initialize;
    Game_System.prototype.initialize = function() {
        _Game_System_initialize.apply(this, arguments);
        this._dbCustomLoadingIndicatorMode = normalizeMode(this._dbCustomLoadingIndicatorMode || settings.initialMode);
        state.pendingMode = this._dbCustomLoadingIndicatorMode;
    };

    const _Scene_Load_executeLoad = Scene_Load.prototype.executeLoad;
    Scene_Load.prototype.executeLoad = function(savefileId) {
        state.forceCustomDuringCurrentLoading = true;
        return _Scene_Load_executeLoad.apply(this, arguments);
    };

    const _Scene_Load_onLoadFailure = Scene_Load.prototype.onLoadFailure;
    Scene_Load.prototype.onLoadFailure = function() {
        state.forceCustomDuringCurrentLoading = false;
        return _Scene_Load_onLoadFailure.apply(this, arguments);
    };

    const _Scene_Map_create = Scene_Map.prototype.create;
    Scene_Map.prototype.create = function() {
        ensureSunDVrmHooks();
        _Scene_Map_create.apply(this, arguments);
    };

    const _DataManager_loadMapData = DataManager.loadMapData;
    DataManager.loadMapData = function(mapId) {
        state.mapLoading = mapId > 0;
        return _DataManager_loadMapData.apply(this, arguments);
    };

    const _DataManager_makeEmptyMap = DataManager.makeEmptyMap;
    DataManager.makeEmptyMap = function() {
        state.mapLoading = false;
        return _DataManager_makeEmptyMap.apply(this, arguments);
    };

    const _DataManager_onLoad = DataManager.onLoad;
    DataManager.onLoad = function(object) {
        _DataManager_onLoad.apply(this, arguments);
        if (object === window.$dataMap) {
            state.mapLoading = false;
        }
    };
})();
