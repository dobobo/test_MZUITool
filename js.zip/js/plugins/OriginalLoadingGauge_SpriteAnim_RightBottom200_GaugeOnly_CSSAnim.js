/*:
 * @target MZ
 * @plugindesc 右下200x200・ゲージのみ・CSS steps式スプライトローディング v1.0
 * @author ChatGPT
 *
 * @param imageFile
 * @text 画像ファイル名
 * @type string
 * @default LoadingImage.png
 *
 * @param areaX
 * @text 表示エリアX
 * @type number
 * @default 1000
 *
 * @param areaY
 * @text 表示エリアY
 * @type number
 * @default 600
 *
 * @param areaWidth
 * @text 表示エリア幅
 * @type number
 * @default 200
 *
 * @param areaHeight
 * @text 表示エリア高さ
 * @type number
 * @default 200
 *
 * @param sourceFrameWidth
 * @text 元画像1コマ幅
 * @type number
 * @default 200
 *
 * @param sourceFrameHeight
 * @text 元画像1コマ高さ
 * @type number
 * @default 200
 *
 * @param displayFrameWidth
 * @text 表示時1コマ幅
 * @type number
 * @default 128
 *
 * @param displayFrameHeight
 * @text 表示時1コマ高さ
 * @type number
 * @default 128
 *
 * @param frameCount
 * @text コマ数
 * @type number
 * @default 4
 *
 * @param animSpeed
 * @text アニメ再生時間(ms)
 * @type number
 * @default 700
 *
 * @param imageOffsetX
 * @text 画像X補正
 * @type number
 * @default 0
 *
 * @param imageOffsetY
 * @text 画像Y補正
 * @type number
 * @default -18
 *
 * @param gaugeWidth
 * @text ゲージ幅
 * @type number
 * @default 160
 *
 * @param gaugeHeight
 * @text ゲージ高さ
 * @type number
 * @default 14
 *
 * @param gaugeOffsetY
 * @text ゲージY補正
 * @type number
 * @default 148
 *
 * @param gaugeBorderColor
 * @text ゲージ枠色
 * @type string
 * @default rgba(255,255,255,0.9)
 *
 * @param gaugeBackColor
 * @text ゲージ背景色
 * @type string
 * @default rgba(0,0,0,0.45)
 *
 * @param gaugeFillColor1
 * @text ゲージ色1
 * @type string
 * @default #6cf
 *
 * @param gaugeFillColor2
 * @text ゲージ色2
 * @type string
 * @default #39f
 *
 * @help
 * 右下200x200想定のローディング表示です。
 * - 文字なし
 * - パーセント表示なし
 * - ゲージのみ表示
 * - スプライト画像は CSS steps() で再生するため、
 *   setInterval式より止まりにくい構成です
 *
 * 画像は img/system/ に入れてください。
 * 例: LoadingImage.png
 *
 * 注意:
 * 完全に停止しない保証はありませんが、従来の
 * JavaScriptタイマー式より負荷時に止まりにくくなります。
 */

(() => {
    const pluginName = "OriginalLoadingGauge_SpriteAnim_RightBottom200_GaugeOnly_CSSAnim";
    const params = PluginManager.parameters(pluginName);

    const settings = {
        imageFile: String(params.imageFile || "LoadingImage.png"),
        areaX: Number(params.areaX || 1000),
        areaY: Number(params.areaY || 600),
        areaWidth: Number(params.areaWidth || 200),
        areaHeight: Number(params.areaHeight || 200),
        sourceFrameWidth: Number(params.sourceFrameWidth || 200),
        sourceFrameHeight: Number(params.sourceFrameHeight || 200),
        displayFrameWidth: Number(params.displayFrameWidth || 128),
        displayFrameHeight: Number(params.displayFrameHeight || 128),
        frameCount: Math.max(1, Number(params.frameCount || 4)),
        animSpeed: Math.max(100, Number(params.animSpeed || 700)),
        imageOffsetX: Number(params.imageOffsetX || 0),
        imageOffsetY: Number(params.imageOffsetY || -18),
        gaugeWidth: Number(params.gaugeWidth || 160),
        gaugeHeight: Number(params.gaugeHeight || 14),
        gaugeOffsetY: Number(params.gaugeOffsetY || 148),
        gaugeBorderColor: String(params.gaugeBorderColor || "rgba(255,255,255,0.9)"),
        gaugeBackColor: String(params.gaugeBackColor || "rgba(0,0,0,0.45)"),
        gaugeFillColor1: String(params.gaugeFillColor1 || "#6cf"),
        gaugeFillColor2: String(params.gaugeFillColor2 || "#39f")
    };

    let loadingWrap = null;
    let loadingBar = null;
    let timerId = null;
    let currentRate = 0;
    let targetRate = 0;
    let styleTag = null;

    function ensureStyle() {
        if (styleTag) return;
        styleTag = document.createElement("style");
        const totalMove = settings.displayFrameWidth * settings.frameCount;
        styleTag.textContent = `
@keyframes olgSpriteStepsAnim {
    from { background-position: 0px 0px; }
    to   { background-position: -${totalMove}px 0px; }
}
`;
        document.head.appendChild(styleTag);
    }

    Graphics._createLoadingSpinner = function() {
        ensureStyle();

        const wrap = document.createElement("div");
        wrap.id = "loadingSpinner";
        wrap.style.position = "absolute";
        wrap.style.left = `${settings.areaX}px`;
        wrap.style.top = `${settings.areaY}px`;
        wrap.style.width = `${settings.areaWidth}px`;
        wrap.style.height = `${settings.areaHeight}px`;
        wrap.style.pointerEvents = "none";
        wrap.style.zIndex = "99";
        wrap.style.overflow = "hidden";
        wrap.style.boxSizing = "border-box";

        const image = document.createElement("div");
        image.style.position = "absolute";
        image.style.left = `calc(50% + ${settings.imageOffsetX}px - ${settings.displayFrameWidth / 2}px)`;
        image.style.top = `${Math.floor((settings.areaHeight - settings.displayFrameHeight) / 2) + settings.imageOffsetY}px`;
        image.style.width = `${settings.displayFrameWidth}px`;
        image.style.height = `${settings.displayFrameHeight}px`;
        image.style.backgroundImage = `url('img/system/${settings.imageFile}')`;
        image.style.backgroundRepeat = "no-repeat";
        image.style.backgroundPosition = "0px 0px";
        image.style.backgroundSize = `${settings.displayFrameWidth * settings.frameCount}px ${settings.displayFrameHeight}px`;
        image.style.imageRendering = "pixelated";
        image.style.willChange = "background-position";
        image.style.transform = "translateZ(0)";
        image.style.animation = `olgSpriteStepsAnim ${settings.animSpeed}ms steps(${settings.frameCount}) infinite`;

        const frame = document.createElement("div");
        frame.style.position = "absolute";
        frame.style.left = `calc(50% - ${settings.gaugeWidth / 2}px)`;
        frame.style.top = `${settings.gaugeOffsetY}px`;
        frame.style.width = `${settings.gaugeWidth}px`;
        frame.style.height = `${settings.gaugeHeight}px`;
        frame.style.border = `2px solid ${settings.gaugeBorderColor}`;
        frame.style.background = settings.gaugeBackColor;
        frame.style.boxSizing = "border-box";

        const bar = document.createElement("div");
        bar.style.width = "0%";
        bar.style.height = "100%";
        bar.style.background = `linear-gradient(to right, ${settings.gaugeFillColor1}, ${settings.gaugeFillColor2})`;

        frame.appendChild(bar);
        wrap.appendChild(image);
        wrap.appendChild(frame);

        this._loadingSpinner = wrap;
        loadingWrap = wrap;
        loadingBar = bar;
    };

    Graphics.startLoading = function() {
        if (!document.getElementById("loadingSpinner")) {
            if (!this._loadingSpinner) {
                this._createLoadingSpinner();
            }
            document.body.appendChild(this._loadingSpinner);
        }

        currentRate = 0;
        targetRate = 0;
        if (loadingBar) loadingBar.style.width = "0%";

        if (timerId) clearInterval(timerId);
        timerId = setInterval(() => {
            if (targetRate < 90) targetRate += 3;
            if (currentRate < targetRate) currentRate += 1;
            if (currentRate > 90) currentRate = 90;
            if (loadingBar) loadingBar.style.width = `${currentRate}%`;
        }, 80);
    };

    Graphics.updateLoading = function() {
        // CSS animationで画像を動かすため、ここでは何もしない
    };

    Graphics.endLoading = function() {
        if (timerId) {
            clearInterval(timerId);
            timerId = null;
        }

        currentRate = 100;
        if (loadingBar) loadingBar.style.width = "100%";

        if (document.getElementById("loadingSpinner")) {
            setTimeout(() => {
                if (document.getElementById("loadingSpinner") && this._loadingSpinner) {
                    document.body.removeChild(this._loadingSpinner);
                }
            }, 120);
            return true;
        }
        return false;
    };
})();
