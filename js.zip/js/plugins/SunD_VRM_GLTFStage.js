/*:
 * @target MZ
 * @plugindesc SunD_VRM用：glTF/GLBステージを表示する（当たり判定なし） v1.8
 * @author DB
 * @base SunD_VRM
 * @orderAfter SunD_VRM
 *
 * @help
 * ■概要
 * - SunD_VRM が作成している three.js の scene に、VRMではない glTF/GLB を追加表示します。
 * - 当たり判定やイベント連動はしません（表示のみ）。
 *
 * ■配置
 * - 既定では「プロジェクト直下 /vrm/stage/」に .glb/.gltf を置きます。
 *   例： vrm/stage/BeachStage2.glb
 *
 * ■注意
 * - SunD_VRM の three描画は「2Dマップの上に重ね表示」です。
 * - Unityの見た目（URP/ポストプロセス/パーティクル/ベイクライトなど）はそのまま再現されません。
 * - 本版は、材質の性質（alpha / map / thin mesh）ベースで補正します。
 * - 名前による個別例外分岐は入れていません。
 * - 微調整値はすべてプラグイン内部で固定しています。
 *
 * @param stageFolder
 * @text ステージフォルダ
 * @type string
 * @desc プロジェクト直下からの相対パス（末尾に / を付ける）
 * @default vrm/stage/
 *
 * @command loadStage
 * @text ステージ読み込み
 * @desc glb/gltf をロードして scene に追加します（既に同キーがある場合は置き換え）
 *
 * @arg stageKey
 * @text ステージキー
 * @type string
 * @desc 管理用キー（例：bg）
 * @default bg
 *
 * @arg fileName
 * @text ファイル名
 * @type string
 * @desc 拡張子なし推奨（例：BeachStage2）。拡張子ありでも可（BeachStage2.glb）
 * @default BeachStage2
 *
 * @arg autoShow
 * @text 自動表示
 * @type boolean
 * @default true
 *
 * @arg position
 * @text 位置 (x,y,z)
 * @type string
 * @desc 例：0,0,0
 * @default 0,0,0
 *
 * @arg rotation
 * @text 回転 (x,y,z) 度
 * @type string
 * @desc 例：0,0,0（度指定）
 * @default 0,0,0
 *
 * @arg scale
 * @text スケール
 * @type number
 * @decimals 4
 * @default 1
 *
 * @arg playFirstAnimation
 * @text 先頭アニメ再生
 * @type boolean
 * @default false
 *
 * @command showStage
 * @text ステージ表示
 * @arg stageKey
 * @type string
 * @default bg
 *
 * @command hideStage
 * @text ステージ非表示
 * @arg stageKey
 * @type string
 * @default bg
 *
 * @command setStageTransform
 * @text ステージ変形
 * @desc 位置/回転/スケールを変更します
 *
 * @arg stageKey
 * @type string
 * @default bg
 *
 * @arg position
 * @text 位置 (x,y,z)
 * @type string
 * @default 0,0,0
 *
 * @arg rotation
 * @text 回転 (x,y,z) 度
 * @type string
 * @default 0,0,0
 *
 * @arg scale
 * @text スケール
 * @type number
 * @decimals 4
 * @default 1
 *
 * @command removeStage
 * @text ステージ削除
 * @desc scene から除去し、メモリも解放します
 * @arg stageKey
 * @type string
 * @default bg
 */

(() => {
  "use strict";

  const pluginName = "SunD_VRM_GLTFStage";
  const params = PluginManager.parameters(pluginName);

  const stageFolder = String(params.stageFolder || "vrm/stage/");

  // -------------------------------------------------
  // 内部固定値
  // -------------------------------------------------
  const USE_STAGE_LIGHTS = true;
  const AMBIENT_INTENSITY = 0.22;
  const DIRECTIONAL_INTENSITY = 0.28;
  const DIRECTIONAL_X = 1;
  const DIRECTIONAL_Y = 1;
  const DIRECTIONAL_Z = 1;

  const FORCE_DOUBLE_SIDE = false;
  const REMOVE_NORMAL_MAP = true;
  const REMOVE_AO_MAP = true;
  const REMOVE_EMISSIVE_MAP = false;
  const CLAMP_METALNESS = 0;
  const CLAMP_ROUGHNESS = 1;

  // 薄板判定
  const THIN_MESH_RATIO = 0.08;

  // 水平薄板（カーペット・机布）
  const HORIZONTAL_OFFSET_FACTOR = -2.5;
  const HORIZONTAL_OFFSET_UNITS = -2.5;
  const HORIZONTAL_ALPHA_TEST = 0.01;

  // 垂直薄板（カーテン・垂れ幕）
  const VERTICAL_ALPHA_TEST = 0.12;

  // 共通 cutout
  const BASE_CUTOUT_ALPHA_TEST = 0.12;

  /** @type {Map<string, {gltf:any, root:any, mixer:any, actions:any[]}>} */
  const STAGES = new Map();

  /** @type {{ambient:any, directional:any}|null} */
  let STAGE_LIGHTS = null;

  function ensureReady() {
    if (!window.SUND_VRM) {
      console.error(`[${pluginName}] SunD_VRM が見つかりません。プラグイン順を SunD_VRM の後にしてください。`);
      return false;
    }
    if (!SUND_VRM.moduleLoaded) {
      console.error(`[${pluginName}] three.js モジュールがまだ読み込まれていません（マップに入ってから実行してください）。`);
      return false;
    }
    return true;
  }

  function normPath(fileName) {
    const f = String(fileName || "").trim();
    if (!f) return "";
    const base = "./" + stageFolder.replace(/^\.?\//, "");
    if (/\.(glb|gltf)$/i.test(f)) return base + f;
    return base + f + ".glb";
  }

  function parseVec3(str, defX = 0, defY = 0, defZ = 0) {
    const s = String(str || "").trim();
    const a = s.split(",").map(v => Number(v));
    const x = Number.isFinite(a[0]) ? a[0] : defX;
    const y = Number.isFinite(a[1]) ? a[1] : defY;
    const z = Number.isFinite(a[2]) ? a[2] : defZ;
    return { x, y, z };
  }

  function applyTransform(root, args) {
    const three = SUND_MODS.THREE;

    const p = parseVec3(args.position, 0, 0, 0);
    root.position.set(p.x, p.y, p.z);

    const r = parseVec3(args.rotation, 0, 0, 0);
    root.rotation.set(
      three.MathUtils.degToRad(r.x),
      three.MathUtils.degToRad(r.y),
      three.MathUtils.degToRad(r.z)
    );

    const sc = Number(args.scale);
    root.scale.setScalar(Number.isFinite(sc) ? sc : 1);
  }

  function ensureStageLights() {
    if (!USE_STAGE_LIGHTS) return;
    if (STAGE_LIGHTS) return;
    if (!ensureReady()) return;

    const three = SUND_MODS.THREE;

    const ambient = new three.AmbientLight(0xfff1dc, AMBIENT_INTENSITY);
    const directional = new three.DirectionalLight(0xffd08a, DIRECTIONAL_INTENSITY);
    directional.position.set(DIRECTIONAL_X, DIRECTIONAL_Y, DIRECTIONAL_Z);
    directional.castShadow = false;

    SUND_VRM._scene.add(ambient);
    SUND_VRM._scene.add(directional);

    STAGE_LIGHTS = { ambient, directional };
  }

  function removeStageLightsIfUnused() {
    if (!STAGE_LIGHTS) return;
    if (STAGES.size > 0) return;
    try {
      STAGE_LIGHTS.ambient?.removeFromParent?.();
      STAGE_LIGHTS.directional?.removeFromParent?.();
    } catch (_) {}
    STAGE_LIGHTS = null;
  }

  function disposeMaterial(mat) {
    if (!mat) return;
    for (const k in mat) {
      const v = mat[k];
      if (v && v.isTexture && v.dispose) v.dispose();
    }
    if (mat.dispose) mat.dispose();
  }

  function disposeGltf(gltf) {
    if (!gltf) return;

    if (gltf.scene && gltf.scene.traverse) {
      gltf.scene.traverse(obj => {
        if (obj.geometry && obj.geometry.dispose) obj.geometry.dispose();
        if (obj.material) {
          if (Array.isArray(obj.material)) obj.material.forEach(disposeMaterial);
          else disposeMaterial(obj.material);
        }
      });
    }

    const cache = gltf?.parser?.sourceCache;
    if (cache) {
      for (const key in cache) {
        cache[key].then(tex => {
          try {
            if (tex?.image?.close) tex.image.close();
            if (tex?.dispose) tex.dispose();
          } catch (_) {}
        });
      }
    }
  }

  function tuneMaterial(mat) {
    if (!mat) return;
    const three = SUND_MODS.THREE;

    mat.side = FORCE_DOUBLE_SIDE ? three.DoubleSide : three.FrontSide;
    mat.depthWrite = true;
    mat.depthTest = true;
    mat.polygonOffset = false;
    mat.transparent = false;

    if (mat.isMeshStandardMaterial || mat.isMeshPhysicalMaterial) {
      mat.metalness = CLAMP_METALNESS;
      mat.roughness = CLAMP_ROUGHNESS;
      mat.envMapIntensity = 0;

      if (REMOVE_NORMAL_MAP && mat.normalMap) mat.normalMap = null;
      if (REMOVE_AO_MAP && mat.aoMap) mat.aoMap = null;
      if (REMOVE_EMISSIVE_MAP && mat.emissiveMap) mat.emissiveMap = null;

      mat.needsUpdate = true;
    } else {
      mat.needsUpdate = true;
    }
  }

  function analyzeThinMesh(obj) {
    const geo = obj.geometry;
    if (!geo) return null;

    if (!geo.boundingBox) geo.computeBoundingBox();
    const bb = geo.boundingBox;
    if (!bb) return null;

    const sx = Math.abs(obj.scale?.x ?? 1);
    const sy = Math.abs(obj.scale?.y ?? 1);
    const sz = Math.abs(obj.scale?.z ?? 1);

    const dx = Math.abs((bb.max.x - bb.min.x) * sx);
    const dy = Math.abs((bb.max.y - bb.min.y) * sy);
    const dz = Math.abs((bb.max.z - bb.min.z) * sz);

    const dims = [
      { axis: "x", value: dx },
      { axis: "y", value: dy },
      { axis: "z", value: dz }
    ].sort((a, b) => a.value - b.value);

    const thinnest = dims[0];
    const middle = dims[1];
    const thickest = dims[2];

    if (middle.value <= 0 || thickest.value <= 0) return null;

    const ratioToMiddle = thinnest.value / middle.value;
    const ratioToLargest = thinnest.value / thickest.value;
    const isThin = ratioToMiddle <= THIN_MESH_RATIO && ratioToLargest <= THIN_MESH_RATIO;

    return {
      dx, dy, dz,
      thinnestAxis: thinnest.axis,
      isThin
    };
  }

  function isCutoutLike(mat) {
    if (!mat) return false;
    return !!(
      mat.alphaMap ||
      (typeof mat.alphaTest === "number" && mat.alphaTest > 0) ||
      (mat.map && mat.transparent)
    );
  }

  function isRealBlendLike(mat) {
    if (!mat) return false;
    return !!(
      (typeof mat.opacity === "number" && mat.opacity < 1) &&
      !mat.alphaMap &&
      (!mat.alphaTest || mat.alphaTest <= 0)
    );
  }

  function hasUsefulTexture(mat) {
    return !!(mat && (mat.map || mat.alphaMap || mat.emissiveMap));
  }

  function tuneStageRoot(root) {
    if (!root || !root.traverse) return;

    const three = SUND_MODS.THREE;

    root.traverse(obj => {
      if (!obj.isMesh) return;

      obj.castShadow = false;
      obj.receiveShadow = false;
      obj.frustumCulled = true;

      const thinInfo = analyzeThinMesh(obj);
      const mats = Array.isArray(obj.material) ? obj.material : [obj.material];

      mats.forEach(mat => {
        if (!mat) return;

        tuneMaterial(mat);

        const cutoutLike = isCutoutLike(mat);
        const realBlendLike = isRealBlendLike(mat);
        const textured = hasUsefulTexture(mat);
        const thinSheet = !!(thinInfo && thinInfo.isThin);

        // 基本の切り抜き処理
        if (cutoutLike) {
          mat.side = three.DoubleSide;
          mat.transparent = false;
          mat.alphaTest = BASE_CUTOUT_ALPHA_TEST;
          mat.depthWrite = true;
          mat.depthTest = true;
          obj.renderOrder = Math.max(obj.renderOrder || 0, 10);
          mat.needsUpdate = true;
        }

        // 本当に半透明が必要なものだけ blend
        if (realBlendLike) {
          mat.transparent = true;
          mat.depthWrite = false;
          mat.depthTest = true;
          obj.renderOrder = Math.max(obj.renderOrder || 0, 30);
          mat.needsUpdate = true;
        }

        if (thinSheet) {
          // 水平に近い薄板：カーペット、机布、敷物
			if (thinInfo.thinnestAxis === "y") {
			  mat.polygonOffset = true;
			  mat.polygonOffsetFactor = -1.0;
			  mat.polygonOffsetUnits = -1.0;

			  mat.depthWrite = true;
			  mat.depthTest = true;

			  // カーペット系は alphaTest を実質切る
			  if (cutoutLike) {
			    mat.transparent = false;
			    mat.alphaTest = 0.0;
			  }

			  // 床からほんの少し浮かせる
			  obj.position.y += 0.003;

			  obj.renderOrder = 50;
			  mat.needsUpdate = true;
			}

          // 垂直に近い薄板：カーテン、垂れ幕
          if (thinInfo.thinnestAxis === "x" || thinInfo.thinnestAxis === "z") {
            mat.side = three.DoubleSide;

            if (cutoutLike) {
              mat.transparent = false;
              mat.alphaTest = VERTICAL_ALPHA_TEST;
              mat.depthWrite = true;
              mat.depthTest = true;
            }

            obj.renderOrder = Math.max(obj.renderOrder || 0, 12);
            mat.needsUpdate = true;
          }

          if (textured) {
            mat.side = three.DoubleSide;
            mat.needsUpdate = true;
          }
        }
      });

      if (Array.isArray(obj.material)) {
        obj.material = mats;
      } else {
        obj.material = mats[0];
      }
    });
  }

  function logMapSummary(root, stageKey, path) {
    let meshCount = 0;
    let materialCount = 0;
    let hasMapTrue = 0;
    let hasMapFalse = 0;
    let withNormalMap = 0;
    let withAoMap = 0;
    let withEmissiveMap = 0;
    const samples = [];

    root.traverse(obj => {
      if (obj.isMesh && obj.material) {
        meshCount++;
        const mats = Array.isArray(obj.material) ? obj.material : [obj.material];
        mats.forEach((mat, i) => {
          materialCount++;
          const hasMap = !!mat.map;
          if (hasMap) hasMapTrue++;
          else hasMapFalse++;
          if (mat.normalMap) withNormalMap++;
          if (mat.aoMap) withAoMap++;
          if (mat.emissiveMap) withEmissiveMap++;

          if (samples.length < 12) {
            samples.push({
              mesh: obj.name || "(no-name)",
              index: i,
              type: mat.type || "(unknown)",
              hasMap: hasMap,
              hasNormalMap: !!mat.normalMap,
              hasAoMap: !!mat.aoMap,
              hasEmissiveMap: !!mat.emissiveMap,
              color: mat.color ? ("#" + mat.color.getHexString()) : null,
              mapImage: (mat.map && mat.map.image) ? {
                width: mat.map.image.width || null,
                height: mat.map.image.height || null,
                src: mat.map.image.currentSrc || mat.map.image.src || null
              } : null
            });
          }
        });
      }
    });

    console.warn("MAP_SUMMARY", {
      stageKey: stageKey,
      path: path,
      meshCount: meshCount,
      materialCount: materialCount,
      hasMapTrue: hasMapTrue,
      hasMapFalse: hasMapFalse,
      withNormalMap: withNormalMap,
      withAoMap: withAoMap,
      withEmissiveMap: withEmissiveMap,
      sampleMaterials: samples
    });
  }

  function removeStageInternal(stageKey) {
    const data = STAGES.get(stageKey);
    if (!data) return;

    try {
      if (data.actions) data.actions.forEach(a => a.stop && a.stop());
      if (data.mixer && data.mixer.uncacheRoot) data.mixer.uncacheRoot(data.root);
    } catch (_) {}

    try {
      if (data.root) data.root.removeFromParent();
    } catch (_) {}

    try {
      disposeGltf(data.gltf);
    } catch (_) {}

    STAGES.delete(stageKey);
    removeStageLightsIfUnused();
  }

  function hasVisibleStage() {
    for (const data of STAGES.values()) {
      if (data?.root?.visible) return true;
    }
    return false;
  }

  const _updateMap = SUND_VRM.updateMap;
  SUND_VRM.updateMap = function() {
    const dt = SUND_VRM.deltaTime || 0;
    STAGES.forEach(s => {
      if (s.mixer && s.root && s.root.visible) s.mixer.update(dt);
    });
    _updateMap.call(this);
  };

  PluginManager.registerCommand(pluginName, "loadStage", args => {
    if (!ensureReady()) return;

    const stageKey = String(args.stageKey || "bg");
    const fileName = String(args.fileName || "");
    const path = normPath(fileName);
    if (!path) return;

    removeStageInternal(stageKey);

    SUND_VRM.loader.load(
      path,
      (gltf) => {
        const root = gltf.scene;
        if (!root) {
          console.error(`[${pluginName}] gltf.scene がありません: ${path}`);
          return;
        }

        logMapSummary(root, stageKey, path);

        applyTransform(root, args);
        tuneStageRoot(root);

        root.visible = (String(args.autoShow) === "true");
        SUND_VRM._scene.add(root);

        ensureStageLights();

        let mixer = null;
        const actions = [];

        if (String(args.playFirstAnimation) === "true" && gltf.animations && gltf.animations.length > 0) {
          mixer = new SUND_MODS.THREE.AnimationMixer(root);
          const action = mixer.clipAction(gltf.animations[0]);
          action.play();
          actions.push(action);
        }

        STAGES.set(stageKey, { gltf, root, mixer, actions });
        console.log(`[${pluginName}] stage loaded: key=${stageKey}, path=${path}`);
      },
      undefined,
      (err) => {
        console.error(`[${pluginName}] load error: ${path}`, err);
      }
    );
  });

  PluginManager.registerCommand(pluginName, "showStage", args => {
    if (!ensureReady()) return;
    const stageKey = String(args.stageKey || "bg");
    const data = STAGES.get(stageKey);
    if (data?.root) data.root.visible = true;
  });

  PluginManager.registerCommand(pluginName, "hideStage", args => {
    if (!ensureReady()) return;
    const stageKey = String(args.stageKey || "bg");
    const data = STAGES.get(stageKey);
    if (data?.root) data.root.visible = false;
  });

  PluginManager.registerCommand(pluginName, "setStageTransform", args => {
    if (!ensureReady()) return;
    const stageKey = String(args.stageKey || "bg");
    const data = STAGES.get(stageKey);
    if (!data?.root) return;
    applyTransform(data.root, args);
  });

  PluginManager.registerCommand(pluginName, "removeStage", args => {
    if (!ensureReady()) return;
    const stageKey = String(args.stageKey || "bg");
    removeStageInternal(stageKey);
  });



  window.SUND_VRM_GLTFStage = window.SUND_VRM_GLTFStage || {};
  window.SUND_VRM_GLTFStage.hasVisibleStage = hasVisibleStage;

})();