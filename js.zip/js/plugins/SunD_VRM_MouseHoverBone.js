/*:
 * @target MZ
 * @plugindesc SunD_VRM用：ボーン追従の軽量ホバー判定 + デバッグ表示 + 当たり判定開発モード v1.2.0
 * @author OpenAI
 * @base SunD_VRM
 * @orderAfter SunD_VRM
 *
 * @help
 * SunD_VRM_MouseHoverBone.js
 *
 * ■概要
 * - SunD_VRM の VRMモデルに対して、指定したボーンに追従する球コライダだけを使って
 *   軽量ホバー判定を行います。
 * - 実メッシュには raycast しません。
 * - 自分で登録した area だけが判定対象です。
 * - デバッグ表示ONで、登録球を半透明表示できます。
 * - 開発モードキーで、当たり判定用HUDを左上表示できます。
 * - 開発モード中、X/Y/Z キーを押しながら左ドラッグで offset を編集できます。
 *
 * ■開発モード
 * - 指定キーでON/OFFを切り替えます。
 * - ONの間、左上に以下を表示します。
 *   - modelKey
 *   - areaKey
 *   - boneName
 *   - mouseX / mouseY
 *   - worldX / worldY / worldZ
 *   - distance
 *   - serial
 *   - offsetX / offsetY / offsetZ
 *   - radius
 *   - 現在の編集軸
 *
 * ■ドラッグ編集
 * - 開発モード中のみ有効
 * - ホバー中エリアに対して、左クリック押下中に以下のキーで編集
 *   - Xキー: offsetX
 *   - Yキー: offsetY
 *   - Zキー: offsetZ
 * - X はマウス左右ドラッグを使います。
 * - Y / Z はマウス上下ドラッグを使います。
 *
 * ■判定対象
 * - modelKey ごとの area
 * - area は球のみ
 * - boneName を基準に offsetX/Y/Z を加えた位置に追従
 *
 * ■デバッグ表示
 * - ONで球を半透明表示
 * - ホバー中の area は黄色
 * - それ以外は紫
 *
 * ■保存先
 * - hoverSwitchId          : ホバー中か
 * - modelKeyVariableId     : modelKey
 * - areaKeyVariableId      : areaKey
 * - boneNameVariableId     : boneName
 * - mouseXVariableId       : マウスX
 * - mouseYVariableId       : マウスY
 * - hitWorldXVariableId    : ヒット座標X
 * - hitWorldYVariableId    : ヒット座標Y
 * - hitWorldZVariableId    : ヒット座標Z
 * - distanceVariableId     : カメラからの距離
 * - hoverSerialVariableId  : 対象変化シリアル
 *
 * ■よく使う boneName 例
 * - head
 * - neck
 * - chest
 * - spine
 * - hips
 * - leftHand
 * - rightHand
 * - leftLowerArm
 * - rightLowerArm
 *
 * @param enabledByDefault
 * @text 初期状態で有効
 * @type boolean
 * @default true
 *
 * @param debugVisibleByDefault
 * @text 初期デバッグ表示
 * @type boolean
 * @default false
 *
 * @param refreshFrames
 * @text 再判定間隔フレーム
 * @type number
 * @min 1
 * @default 2
 *
 * @param hoverSwitchId
 * @text ホバー中スイッチ
 * @type switch
 * @default 10
 *
 * @param modelKeyVariableId
 * @text モデルキー変数
 * @type variable
 * @default 11
 *
 * @param areaKeyVariableId
 * @text エリアキー変数
 * @type variable
 * @default 12
 *
 * @param boneNameVariableId
 * @text ボーン名変数
 * @type variable
 * @default 20
 *
 * @param mouseXVariableId
 * @text マウスX変数
 * @type variable
 * @default 13
 *
 * @param mouseYVariableId
 * @text マウスY変数
 * @type variable
 * @default 14
 *
 * @param hitWorldXVariableId
 * @text ヒットX変数
 * @type variable
 * @default 15
 *
 * @param hitWorldYVariableId
 * @text ヒットY変数
 * @type variable
 * @default 16
 *
 * @param hitWorldZVariableId
 * @text ヒットZ変数
 * @type variable
 * @default 17
 *
 * @param distanceVariableId
 * @text 距離変数
 * @type variable
 * @default 18
 *
 * @param hoverSerialVariableId
 * @text 変化シリアル変数
 * @type variable
 * @default 19
 *
 * @param devToggleKey
 * @text 開発モード切替キー
 * @type string
 * @default F7
 *
 * @param axisXKey
 * @text X編集キー
 * @type string
 * @default X
 *
 * @param axisYKey
 * @text Y編集キー
 * @type string
 * @default Y
 *
 * @param axisZKey
 * @text Z編集キー
 * @type string
 * @default Z
 * 
 * @param radiusKey
 * @text 半径編集キー
 * @type string
 * @default R
 *
 * @param radiusSensitivity
 * @text 半径ドラッグ感度
 * @type number
 * @decimals 4
 * @default 0.005
 *
 * @param dragSensitivity
 * @text ドラッグ感度
 * @type number
 * @decimals 4
 * @default 0.005
 *
 * @param forceDebugVisibleInDevMode
 * @text 開発モード中は球を強制表示
 * @type boolean
 * @default true
 *
 * @param devHudX
 * @text HUD X
 * @type number
 * @min 0
 * @default 8
 *
 * @param devHudY
 * @text HUD Y
 * @type number
 * @min 0
 * @default 8
 *
 * @param devHudFontSize
 * @text HUD 文字サイズ
 * @type number
 * @min 8
 * @default 16
 *
 * @param roundDigits
 * @text 小数丸め桁数
 * @type number
 * @min 0
 * @default 3
 *
 * @param debugLog
 * @text デバッグログ
 * @type boolean
 * @default false
 *
 * @command setEnabled
 * @text 有効/無効
 * @desc ホバー判定全体の有効/無効を切り替えます。
 *
 * @arg enabled
 * @type boolean
 * @default true
 *
 * @command setDebugVisible
 * @text デバッグ表示
 * @desc デバッグ球の表示/非表示を切り替えます。
 *
 * @arg visible
 * @type boolean
 * @default true
 *
 * @command addBoneArea
 * @text ボーン判定追加
 * @desc 指定モデルにボーン追従球判定を追加または上書きします。
 *
 * @arg modelKey
 * @text モデルキー
 * @type string
 * @default
 *
 * @arg areaKey
 * @text エリアキー
 * @type string
 * @default face
 *
 * @arg boneName
 * @text ボーン名
 * @type string
 * @default head
 *
 * @arg offsetX
 * @text offsetX
 * @type number
 * @decimals 3
 * @min -9999
 * @max 9999
 * @default 0
 *
 * @arg offsetY
 * @text offsetY
 * @type number
 * @decimals 3
 * @min -9999
 * @max 9999
 * @default 0
 *
 * @arg offsetZ
 * @text offsetZ
 * @type number
 * @decimals 3
 * @min -9999
 * @max 9999
 * @default 0
 *
 * @arg radius
 * @text 半径
 * @type number
 * @decimals 3
 * @default 0.25
 *
 * @command removeArea
 * @text 判定削除
 * @desc 指定モデルの指定エリアを削除します。
 *
 * @arg modelKey
 * @text モデルキー
 * @type string
 * @default
 *
 * @arg areaKey
 * @text エリアキー
 * @type string
 * @default face
 *
 * @command clearAreasByModel
 * @text モデルの判定全削除
 * @desc 指定モデルの当たり判定をすべて削除します。
 *
 * @arg modelKey
 * @text モデルキー
 * @type string
 * @default
 *
 * @command clearAllAreas
 * @text 全判定削除
 * @desc 全モデルの当たり判定をすべて削除します。
 *
 * @command clearHoverState
 * @text 状態クリア
 * @desc 現在のホバー状態をクリアします。
 */

(() => {
    "use strict";

    const pluginName = "SunD_VRM_MouseHoverBone";
    const params = PluginManager.parameters(pluginName);

    const PARAM_ENABLED_DEFAULT = String(params.enabledByDefault || "true") === "true";
    const PARAM_DEBUG_VISIBLE_DEFAULT = String(params.debugVisibleByDefault || "false") === "true";
    const PARAM_REFRESH_FRAMES = Math.max(1, Number(params.refreshFrames || 2));
    const PARAM_HOVER_SWITCH_ID = Number(params.hoverSwitchId || 0);
    const PARAM_MODEL_KEY_VAR_ID = Number(params.modelKeyVariableId || 0);
    const PARAM_AREA_KEY_VAR_ID = Number(params.areaKeyVariableId || 0);
    const PARAM_BONE_NAME_VAR_ID = Number(params.boneNameVariableId || 0);
    const PARAM_MOUSE_X_VAR_ID = Number(params.mouseXVariableId || 0);
    const PARAM_MOUSE_Y_VAR_ID = Number(params.mouseYVariableId || 0);
    const PARAM_HIT_X_VAR_ID = Number(params.hitWorldXVariableId || 0);
    const PARAM_HIT_Y_VAR_ID = Number(params.hitWorldYVariableId || 0);
    const PARAM_HIT_Z_VAR_ID = Number(params.hitWorldZVariableId || 0);
    const PARAM_DISTANCE_VAR_ID = Number(params.distanceVariableId || 0);
    const PARAM_SERIAL_VAR_ID = Number(params.hoverSerialVariableId || 0);
    const PARAM_DEV_TOGGLE_KEY = String(params.devToggleKey || "F7").trim();
    const PARAM_AXIS_X_KEY = String(params.axisXKey || "X").trim();
    const PARAM_AXIS_Y_KEY = String(params.axisYKey || "Y").trim();
    const PARAM_AXIS_Z_KEY = String(params.axisZKey || "Z").trim();
    const PARAM_DRAG_SENSITIVITY = Number(params.dragSensitivity || 0.005);
    const PARAM_FORCE_DEBUG_VISIBLE_IN_DEV = String(params.forceDebugVisibleInDevMode || "true") === "true";
    const PARAM_DEV_HUD_X = Number(params.devHudX || 8);
    const PARAM_DEV_HUD_Y = Number(params.devHudY || 8);
    const PARAM_DEV_HUD_FONT_SIZE = Number(params.devHudFontSize || 16);
    const PARAM_ROUND_DIGITS = Number(params.roundDigits || 3);
    const PARAM_DEBUG = String(params.debugLog || "false") === "true";
    const PARAM_RADIUS_KEY = String(params.radiusKey || "R").trim();
    const PARAM_RADIUS_SENSITIVITY = Number(params.radiusSensitivity || 0.005);    

    function debugLog(...args) {
        if (PARAM_DEBUG) console.log(`[${pluginName}]`, ...args);
    }

    function roundValue(value) {
        const p = Math.pow(10, PARAM_ROUND_DIGITS);
        return Math.round((Number(value) || 0) * p) / p;
    }

    function isSceneMapActive() {
        const scene = SceneManager._scene;
        return scene && scene.constructor === Scene_Map;
    }

    function canUseRuntime() {
        return !!(
            window.SUND_VRM &&
            window.SUND_MODS &&
            window.SUND_MODS.THREE &&
            window.$sundVRMs &&
            SUND_VRM.moduleLoaded &&
            SUND_VRM._renderer &&
            SUND_VRM._camera &&
            SUND_VRM._scene
        );
    }

    function makeDefaultHover() {
        return {
            hit: false,
            modelKey: "",
            areaKey: "",
            boneName: "",
            mouseX: 0,
            mouseY: 0,
            worldX: 0,
            worldY: 0,
            worldZ: 0,
            distance: 0
        };
    }

    function makeDefaultData() {
        return {
            enabled: PARAM_ENABLED_DEFAULT,
            debugVisible: PARAM_DEBUG_VISIBLE_DEFAULT,
            devMode: false,
            serial: 0,
            mouse: {
                inside: false,
                moved: false,
                clientX: 0,
                clientY: 0
            },
            areas: [],
            hover: makeDefaultHover()
        };
    }

    function ensureSystemData(system) {
        const target = system || window.$gameSystem;
        if (!target) return null;
        if (!target._sundVrmMouseHoverBone) {
            target._sundVrmMouseHoverBone = makeDefaultData();
        }
        return target._sundVrmMouseHoverBone;
    }

    function setVariable(id, value) {
        if (id > 0) $gameVariables.setValue(id, value);
    }

    function setSwitch(id, value) {
        if (id > 0) $gameSwitches.setValue(id, !!value);
    }

    function writeOut(data) {
        if (!$gameVariables || !$gameSwitches) return;
        const h = data.hover;
        setSwitch(PARAM_HOVER_SWITCH_ID, h.hit);
        setVariable(PARAM_MODEL_KEY_VAR_ID, h.modelKey);
        setVariable(PARAM_AREA_KEY_VAR_ID, h.areaKey);
        setVariable(PARAM_BONE_NAME_VAR_ID, h.boneName);
        setVariable(PARAM_MOUSE_X_VAR_ID, h.mouseX);
        setVariable(PARAM_MOUSE_Y_VAR_ID, h.mouseY);
        setVariable(PARAM_HIT_X_VAR_ID, h.worldX);
        setVariable(PARAM_HIT_Y_VAR_ID, h.worldY);
        setVariable(PARAM_HIT_Z_VAR_ID, h.worldZ);
        setVariable(PARAM_DISTANCE_VAR_ID, h.distance);
        setVariable(PARAM_SERIAL_VAR_ID, data.serial);
    }

    function sameHover(a, b) {
        return !!(
            a.hit === b.hit &&
            a.modelKey === b.modelKey &&
            a.areaKey === b.areaKey &&
            a.boneName === b.boneName
        );
    }

    function keyMatches(event, configuredKey) {
        const target = String(configuredKey || "").trim().toUpperCase();
        if (!target) return false;

        const evKey = String(event.key || "").trim().toUpperCase();
        const evCode = String(event.code || "").trim().toUpperCase();

        if (evKey === target || evCode === target) return true;
        if (target.length === 1 && evCode === `KEY${target}`) return true;

        return false;
    }

    const _Game_System_initialize = Game_System.prototype.initialize;
    Game_System.prototype.initialize = function() {
        _Game_System_initialize.apply(this, arguments);
        ensureSystemData(this);
    };

    Game_System.prototype.sundVrmMouseHoverBoneState = function() {
        const data = ensureSystemData(this);
        return data ? JSON.parse(JSON.stringify(data.hover)) : null;
    };

    Game_System.prototype.sundVrmMouseHoverBoneSerial = function() {
        const data = ensureSystemData(this);
        return data ? data.serial : 0;
    };

    Game_System.prototype.sundVrmMouseHoverBoneSetEnabled = function(enabled) {
        const data = ensureSystemData(this);
        if (data) data.enabled = !!enabled;
    };

    Game_System.prototype.sundVrmMouseHoverBoneSetDebugVisible = function(visible) {
        const data = ensureSystemData(this);
        if (data) data.debugVisible = !!visible;
    };

    Game_System.prototype.sundVrmMouseHoverBoneSetDevMode = function(enabled) {
        const data = ensureSystemData(this);
        if (data) data.devMode = !!enabled;
    };

    Game_System.prototype.sundVrmMouseHoverBoneDevMode = function() {
        const data = ensureSystemData(this);
        return data ? !!data.devMode : false;
    };

    Game_System.prototype.sundVrmMouseHoverBoneAddArea = function(modelKey, areaKey, boneName, offsetX, offsetY, offsetZ, radius) {
        const data = ensureSystemData(this);
        if (!data) return;

        modelKey = String(modelKey || "").trim();
        areaKey = String(areaKey || "").trim();
        boneName = String(boneName || "").trim();
        if (!modelKey || !areaKey || !boneName) return;

        const area = {
            modelKey: modelKey,
            areaKey: areaKey,
            boneName: boneName,
            offsetX: Number(offsetX || 0),
            offsetY: Number(offsetY || 0),
            offsetZ: Number(offsetZ || 0),
            radius: Math.max(0.001, Number(radius || 0.25))
        };

        const index = data.areas.findIndex(a => a.modelKey === modelKey && a.areaKey === areaKey);
        if (index >= 0) {
            data.areas[index] = area;
        } else {
            data.areas.push(area);
        }
    };

    Game_System.prototype.sundVrmMouseHoverBoneRemoveArea = function(modelKey, areaKey) {
        const data = ensureSystemData(this);
        if (!data) return;

        modelKey = String(modelKey || "").trim();
        areaKey = String(areaKey || "").trim();
        data.areas = data.areas.filter(a => !(a.modelKey === modelKey && a.areaKey === areaKey));
    };

    Game_System.prototype.sundVrmMouseHoverBoneClearAreasByModel = function(modelKey) {
        const data = ensureSystemData(this);
        if (!data) return;

        modelKey = String(modelKey || "").trim();
        data.areas = data.areas.filter(a => a.modelKey !== modelKey);
    };

    Game_System.prototype.sundVrmMouseHoverBoneClearAllAreas = function() {
        const data = ensureSystemData(this);
        if (!data) return;

        data.areas = [];
    };

    Game_System.prototype.sundVrmMouseHoverBoneClear = function() {
        const data = ensureSystemData(this);
        if (!data) return;

        data.hover = makeDefaultHover();
        data.serial += 1;
        writeOut(data);
    };

    PluginManager.registerCommand(pluginName, "setEnabled", args => {
        $gameSystem.sundVrmMouseHoverBoneSetEnabled(String(args.enabled) === "true");
    });

    PluginManager.registerCommand(pluginName, "setDebugVisible", args => {
        $gameSystem.sundVrmMouseHoverBoneSetDebugVisible(String(args.visible) === "true");
    });

    PluginManager.registerCommand(pluginName, "addBoneArea", args => {
        $gameSystem.sundVrmMouseHoverBoneAddArea(
            args.modelKey,
            args.areaKey,
            args.boneName,
            args.offsetX,
            args.offsetY,
            args.offsetZ,
            args.radius
        );
    });

    PluginManager.registerCommand(pluginName, "removeArea", args => {
        $gameSystem.sundVrmMouseHoverBoneRemoveArea(args.modelKey, args.areaKey);
    });

    PluginManager.registerCommand(pluginName, "clearAreasByModel", args => {
        $gameSystem.sundVrmMouseHoverBoneClearAreasByModel(args.modelKey);
    });

    PluginManager.registerCommand(pluginName, "clearAllAreas", () => {
        $gameSystem.sundVrmMouseHoverBoneClearAllAreas();
    });

    PluginManager.registerCommand(pluginName, "clearHoverState", () => {
        $gameSystem.sundVrmMouseHoverBoneClear();
    });

    const HoverRuntime = {
        attached: false,
        raycaster: null,
        ndc: null,
        tmpOffset: null,
        tmpSphere: null,
        tmpHit: null,
        debugMap: new Map(),
        overlay: null,
        keyState: {
            x: false,
            y: false,
            z: false,
            r: false
        },
        dragState: null,
        lastUpdateFrame: -999999,

        ensureReady() {
            if (!canUseRuntime()) return false;
            const three = SUND_MODS.THREE;
            if (!this.raycaster) this.raycaster = new three.Raycaster();
            if (!this.ndc) this.ndc = new three.Vector2();
            if (!this.tmpOffset) this.tmpOffset = new three.Vector3();
            if (!this.tmpSphere) this.tmpSphere = new three.Sphere();
            if (!this.tmpHit) this.tmpHit = new three.Vector3();
            return true;
        },

        attachIfNeeded() {
            if (this.attached) return;

            this._pointerMoveHandler = this.onPointerMove.bind(this);
            this._pointerLeaveHandler = this.onPointerLeave.bind(this);
            this._pointerDownHandler = this.onPointerDown.bind(this);
            this._pointerUpHandler = this.onPointerUp.bind(this);
            this._windowBlurHandler = this.onWindowBlur.bind(this);
            this._keyDownHandler = this.onKeyDown.bind(this);
            this._keyUpHandler = this.onKeyUp.bind(this);

            document.body.addEventListener("pointermove", this._pointerMoveHandler, { passive: false });
            document.body.addEventListener("pointerleave", this._pointerLeaveHandler, { passive: true });
            document.body.addEventListener("pointerdown", this._pointerDownHandler, { passive: false });
            window.addEventListener("pointerup", this._pointerUpHandler, { passive: true });
            window.addEventListener("blur", this._windowBlurHandler);
            window.addEventListener("keydown", this._keyDownHandler);
            window.addEventListener("keyup", this._keyUpHandler);

            this.attached = true;
            debugLog("attached");
        },

        ensureOverlay() {
            if (this.overlay) return;

            const div = document.createElement("div");
            div.id = "SUND_VRM_MouseHoverBone_HUD";
            div.style.position = "absolute";
            div.style.left = `${PARAM_DEV_HUD_X}px`;
            div.style.top = `${PARAM_DEV_HUD_Y}px`;
            div.style.zIndex = "999999";
            div.style.pointerEvents = "none";
            div.style.whiteSpace = "pre";
            div.style.fontFamily = "monospace";
            div.style.fontSize = `${PARAM_DEV_HUD_FONT_SIZE}px`;
            div.style.lineHeight = "1.35";
            div.style.color = "#ffffff";
            div.style.background = "rgba(0,0,0,0.6)";
            div.style.padding = "6px 8px";
            div.style.border = "1px solid rgba(255,255,255,0.25)";
            div.style.borderRadius = "4px";
            div.style.display = "none";
            document.body.appendChild(div);

            this.overlay = div;
        },

        updateOverlay(data) {
            this.ensureOverlay();
            if (!this.overlay) return;

            this.overlay.style.left = `${PARAM_DEV_HUD_X}px`;
            this.overlay.style.top = `${PARAM_DEV_HUD_Y}px`;
            this.overlay.style.fontSize = `${PARAM_DEV_HUD_FONT_SIZE}px`;

            const visible = !!(data && data.devMode && isSceneMapActive());
            this.overlay.style.display = visible ? "block" : "none";
            if (!visible) return;

            const h = data.hover || makeDefaultHover();
            const area = this.findArea(data, h.modelKey, h.areaKey);
            const lines = [
                `[HoverDev:${data.devMode ? "ON" : "OFF"}] key=${PARAM_DEV_TOGGLE_KEY}`,
                `hit=${h.hit}`,
                `model=${h.modelKey || "-"}`,
                `area=${h.areaKey || "-"}`,
                `bone=${h.boneName || "-"}`,
                `mouse=(${h.mouseX}, ${h.mouseY})`,
                `world=(${h.worldX}, ${h.worldY}, ${h.worldZ})`,
                `distance=${h.distance}`,
                `serial=${data.serial}`,
                `offset=(${area ? roundValue(area.offsetX) : "-"}, ${area ? roundValue(area.offsetY) : "-"}, ${area ? roundValue(area.offsetZ) : "-"})`,
                `radius=${area ? roundValue(area.radius) : "-"}`,
                `axisKey=[${this.currentAxisName() || "-"}]  X:offsetX Y:offsetY Z:offsetZ R:radius`,
                `radiusSensitivity=${PARAM_RADIUS_SENSITIVITY}`,                
                `dragging=${this.dragState ? "ON" : "OFF"}`,
                `debugSphere=${(data.debugVisible || (data.devMode && PARAM_FORCE_DEBUG_VISIBLE_IN_DEV)) ? "ON" : "OFF"}`
            ];

            this.overlay.textContent = lines.join("\n");
        },

        onPointerMove(event) {
            const data = ensureSystemData($gameSystem);
            if (!data) return;
            if (event.pointerType && event.pointerType !== "mouse") return;

            data.mouse.inside = true;
            data.mouse.moved = true;
            data.mouse.clientX = event.clientX;
            data.mouse.clientY = event.clientY;

            if (this.dragState) {
                const dx = event.clientX - this.dragState.lastClientX;
                const dy = event.clientY - this.dragState.lastClientY;
                this.dragState.lastClientX = event.clientX;
                this.dragState.lastClientY = event.clientY;

                const area = this.dragState.area;
                if (area) {
                    if (this.dragState.axis === "x") {
                        area.offsetX += dx * PARAM_DRAG_SENSITIVITY;
                    } else if (this.dragState.axis === "y") {
                        area.offsetY += -dy * PARAM_DRAG_SENSITIVITY;
                    } else if (this.dragState.axis === "z") {
                        area.offsetZ += -dy * PARAM_DRAG_SENSITIVITY;
                    } else if (this.dragState.axis === "r") {
                        area.radius = Math.max(
                            0.001,
                            area.radius + (-dy * PARAM_RADIUS_SENSITIVITY)
                        );
                    }
                    data.mouse.moved = true;
                    event.preventDefault();
                }
            }
        },

        onPointerLeave() {
            const data = ensureSystemData($gameSystem);
            if (!data) return;
            data.mouse.inside = false;
            data.mouse.moved = true;
        },

        onPointerDown(event) {
            if (event.button !== 0) return;
            if (!$gameSystem) return;

            const data = ensureSystemData($gameSystem);
            if (!data || !data.devMode) return;
            if (!data.hover.hit) return;

            const axis = this.currentAxisName();
            if (!axis) return;

            const area = this.findArea(data, data.hover.modelKey, data.hover.areaKey);
            if (!area) return;

            this.dragState = {
                axis: axis,
                area: area,
                lastClientX: event.clientX,
                lastClientY: event.clientY
            };

            event.preventDefault();
            debugLog("drag start", {
                axis: axis,
                modelKey: area.modelKey,
                areaKey: area.areaKey
            });
        },

        onPointerUp() {
            if (this.dragState) {
                debugLog("drag end", {
                    axis: this.dragState.axis,
                    modelKey: this.dragState.area ? this.dragState.area.modelKey : "",
                    areaKey: this.dragState.area ? this.dragState.area.areaKey : ""
                });
            }
            this.dragState = null;
        },

        onWindowBlur() {
            const data = ensureSystemData($gameSystem);
            if (!data) return;
            data.mouse.inside = false;
            data.mouse.moved = true;
            this.dragState = null;
            this.keyState.x = false;
            this.keyState.y = false;
            this.keyState.z = false;
            this.keyState.r = false;            
        },

        onKeyDown(event) {
            if (keyMatches(event, PARAM_DEV_TOGGLE_KEY)) {
                if (!event.repeat && $gameSystem) {
                    const data = ensureSystemData($gameSystem);
                    if (data) {
                        data.devMode = !data.devMode;
                        debugLog(`devMode=${data.devMode}`);
                    }
                }
                event.preventDefault();
                return;
            }

            if (keyMatches(event, PARAM_AXIS_X_KEY)) {
                this.keyState.x = true;
                event.preventDefault();
                return;
            }
            if (keyMatches(event, PARAM_AXIS_Y_KEY)) {
                this.keyState.y = true;
                event.preventDefault();
                return;
            }
            if (keyMatches(event, PARAM_AXIS_Z_KEY)) {
                this.keyState.z = true;
                event.preventDefault();
                return;
            }
            if (keyMatches(event, PARAM_RADIUS_KEY)) {
                this.keyState.r = true;
                event.preventDefault();
                return;
            }            
        },

        onKeyUp(event) {
            if (keyMatches(event, PARAM_AXIS_X_KEY)) {
                this.keyState.x = false;
                return;
            }
            if (keyMatches(event, PARAM_AXIS_Y_KEY)) {
                this.keyState.y = false;
                return;
            }
            if (keyMatches(event, PARAM_AXIS_Z_KEY)) {
                this.keyState.z = false;
                return;
            }
            if (keyMatches(event, PARAM_RADIUS_KEY)) {
                this.keyState.r = false;
                return;
            }            
        },

        currentAxisName() {
            if (this.keyState.x) return "x";
            if (this.keyState.y) return "y";
            if (this.keyState.z) return "z";
            if (this.keyState.r) return "r";
            return "";
        },

        findArea(data, modelKey, areaKey) {
            if (!data || !Array.isArray(data.areas)) return null;
            return data.areas.find(a => a.modelKey === modelKey && a.areaKey === areaKey) || null;
        },

        getModelObject(modelKey) {
            return $sundVRMs.get(modelKey) || null;
        },

        resolveBoneNode(vrm, boneName) {
            if (!vrm) return null;

            const humanoid = vrm.humanoid;
            if (humanoid) {
                if (typeof humanoid.getRawBoneNode === "function") {
                    const raw = humanoid.getRawBoneNode(boneName);
                    if (raw) return raw;
                }
                if (typeof humanoid.getNormalizedBoneNode === "function") {
                    const normalized = humanoid.getNormalizedBoneNode(boneName);
                    if (normalized) return normalized;
                }
                if (humanoid.humanBones && humanoid.humanBones[boneName] && humanoid.humanBones[boneName].node) {
                    return humanoid.humanBones[boneName].node;
                }
                if (humanoid.normalizedHumanBones && humanoid.normalizedHumanBones[boneName] && humanoid.normalizedHumanBones[boneName].node) {
                    return humanoid.normalizedHumanBones[boneName].node;
                }
            }

            if (vrm.scene && typeof vrm.scene.getObjectByName === "function") {
                const byName = vrm.scene.getObjectByName(boneName);
                if (byName) return byName;
            }

            return null;
        },

        getAreaWorldCenter(area) {
            const obj = this.getModelObject(area.modelKey);
            if (!obj || !obj._loaded || !obj._vrm || !obj._vrm.scene || !obj._vrm.scene.visible) return null;

            const boneNode = this.resolveBoneNode(obj._vrm, area.boneName);
            if (!boneNode) return null;

            boneNode.updateWorldMatrix(true, false);

            const offset = this.tmpOffset.set(
                Number(area.offsetX || 0),
                Number(area.offsetY || 0),
                Number(area.offsetZ || 0)
            );

            return boneNode.localToWorld(offset.clone());
        },

        updateDebugMeshes(data, hoveredId) {
            const three = SUND_MODS.THREE;
            const alive = new Set();
            const visibleByMode = !!(data.debugVisible || (data.devMode && PARAM_FORCE_DEBUG_VISIBLE_IN_DEV));

            for (const area of data.areas) {
                const id = `${area.modelKey}::${area.areaKey}`;
                alive.add(id);

                let entry = this.debugMap.get(id);
                if (!entry) {
                    const geom = new three.SphereGeometry(1, 20, 16);
                    const mat = new three.MeshBasicMaterial({
                        color: 0xff00ff,
                        transparent: true,
                        opacity: 0.35,
                        depthTest: false,
                        depthWrite: false,
                        toneMapped: false
                    });
                    const mesh = new three.Mesh(geom, mat);
                    mesh.renderOrder = 999999;
                    mesh.frustumCulled = false;
                    SUND_VRM._scene.add(mesh);
                    entry = { mesh };
                    this.debugMap.set(id, entry);
                }

                if (!visibleByMode) {
                    entry.mesh.visible = false;
                    continue;
                }

                const center = this.getAreaWorldCenter(area);
                if (!center) {
                    entry.mesh.visible = false;
                    continue;
                }

                entry.mesh.position.copy(center);
                entry.mesh.scale.setScalar(Math.max(0.001, Number(area.radius || 0.25)));
                entry.mesh.visible = true;
                entry.mesh.material.color.setHex(id === hoveredId ? 0xffff33 : 0xff00ff);

                debugLog("debug area", {
                    modelKey: area.modelKey,
                    areaKey: area.areaKey,
                    boneName: area.boneName,
                    radius: area.radius,
                    offsetX: area.offsetX,
                    offsetY: area.offsetY,
                    offsetZ: area.offsetZ,
                    x: center.x,
                    y: center.y,
                    z: center.z,
                    devMode: data.devMode,
                    debugVisible: visibleByMode
                });
            }

            for (const [id, entry] of this.debugMap.entries()) {
                if (!alive.has(id)) {
                    entry.mesh.removeFromParent();
                    entry.mesh.geometry.dispose();
                    entry.mesh.material.dispose();
                    this.debugMap.delete(id);
                }
            }
        },

        pickFromAreas(data) {
            const canvas = SUND_VRM._renderer.domElement;
            const rect = canvas.getBoundingClientRect();
            if (rect.width <= 0 || rect.height <= 0) {
                return { hover: makeDefaultHover(), hoveredId: "" };
            }

            const clientX = data.mouse.clientX;
            const clientY = data.mouse.clientY;
            const x = ((clientX - rect.left) / rect.width) * 2 - 1;
            const y = -((clientY - rect.top) / rect.height) * 2 + 1;

            this.ndc.set(x, y);
            this.raycaster.setFromCamera(this.ndc, SUND_VRM._camera);

            let best = null;
            let bestDist = Infinity;
            let hoveredId = "";

            for (const area of data.areas) {
                const center = this.getAreaWorldCenter(area);
                if (!center) continue;

                const sphere = this.tmpSphere;
                sphere.center.copy(center);
                sphere.radius = Number(area.radius || 0.25);

                const hitPoint = this.raycaster.ray.intersectSphere(sphere, this.tmpHit.clone());
                if (!hitPoint) continue;

                const dist = this.raycaster.ray.origin.distanceTo(hitPoint);
                if (dist < bestDist) {
                    bestDist = dist;
                    best = {
                        hit: true,
                        modelKey: area.modelKey,
                        areaKey: area.areaKey,
                        boneName: area.boneName,
                        mouseX: clientX,
                        mouseY: clientY,
                        worldX: roundValue(hitPoint.x),
                        worldY: roundValue(hitPoint.y),
                        worldZ: roundValue(hitPoint.z),
                        distance: roundValue(dist)
                    };
                    hoveredId = `${area.modelKey}::${area.areaKey}`;
                }
            }

            if (best) return { hover: best, hoveredId: hoveredId };

            return {
                hover: {
                    hit: false,
                    modelKey: "",
                    areaKey: "",
                    boneName: "",
                    mouseX: clientX,
                    mouseY: clientY,
                    worldX: 0,
                    worldY: 0,
                    worldZ: 0,
                    distance: 0
                },
                hoveredId: ""
            };
        },

        hideOverlay() {
            if (this.overlay) {
                this.overlay.style.display = "none";
            }
        },

        hideDebugMeshes() {
            for (const entry of this.debugMap.values()) {
                if (entry && entry.mesh) {
                    entry.mesh.visible = false;
                }
            }
        },

        isDebugVisualActive(data) {
            return !!(
                data &&
                data.enabled &&
                isSceneMapActive() &&
                (data.debugVisible || (data.devMode && PARAM_FORCE_DEBUG_VISIBLE_IN_DEV))
            );
        },

        update() {
            const data = ensureSystemData($gameSystem);
            const overlayActive = !!(data && data.devMode && isSceneMapActive());
            if (overlayActive) {
                this.updateOverlay(data);
            } else {
                this.hideOverlay();
            }

            if (!isSceneMapActive()) {
                this.hideDebugMeshes();
                return;
            }
            if (!this.ensureReady()) return;
            this.attachIfNeeded();

            if (!data || !data.enabled) {
                this.hideDebugMeshes();
                return;
            }

            const debugVisualActive = this.isDebugVisualActive(data);
            const frame = Graphics.frameCount || 0;
            const shouldRefresh =
                data.mouse.moved ||
                (frame - this.lastUpdateFrame) >= PARAM_REFRESH_FRAMES ||
                !!this.dragState;

            if (!shouldRefresh) {
                if (debugVisualActive) {
                    this.updateDebugMeshes(
                        data,
                        data.hover.hit ? `${data.hover.modelKey}::${data.hover.areaKey}` : ""
                    );
                } else {
                    this.hideDebugMeshes();
                }
                return;
            }

            this.lastUpdateFrame = frame;
            data.mouse.moved = false;

            let nextHover;
            let hoveredId = "";

            if (!data.mouse.inside) {
                nextHover = makeDefaultHover();
            } else {
                const result = this.pickFromAreas(data);
                nextHover = result.hover;
                hoveredId = result.hoveredId;
            }

            if (!sameHover(data.hover, nextHover)) {
                data.hover = nextHover;
                data.serial += 1;
                debugLog("hover changed", data.hover);
            } else {
                data.hover.mouseX = nextHover.mouseX;
                data.hover.mouseY = nextHover.mouseY;
                data.hover.worldX = nextHover.worldX;
                data.hover.worldY = nextHover.worldY;
                data.hover.worldZ = nextHover.worldZ;
                data.hover.distance = nextHover.distance;
            }

            if (debugVisualActive) {
                this.updateDebugMeshes(data, hoveredId);
            } else {
                this.hideDebugMeshes();
            }
            writeOut(data);
        }
    };

    const _Scene_Map_update = Scene_Map.prototype.update;
    Scene_Map.prototype.update = function() {
        _Scene_Map_update.apply(this, arguments);
        HoverRuntime.update();
    };

    const _Scene_Map_terminate = Scene_Map.prototype.terminate;
    Scene_Map.prototype.terminate = function() {
        if ($gameSystem) {
            $gameSystem.sundVrmMouseHoverBoneClear();
        }
        _Scene_Map_terminate.apply(this, arguments);
    };

    window.SUND_VRM_MouseHoverBone = {
        getState() {
            return $gameSystem ? $gameSystem.sundVrmMouseHoverBoneState() : null;
        },
        getSerial() {
            return $gameSystem ? $gameSystem.sundVrmMouseHoverBoneSerial() : 0;
        },
        setEnabled(enabled) {
            if ($gameSystem) $gameSystem.sundVrmMouseHoverBoneSetEnabled(!!enabled);
        },
        setDebugVisible(visible) {
            if ($gameSystem) $gameSystem.sundVrmMouseHoverBoneSetDebugVisible(!!visible);
        },
        setDevMode(enabled) {
            if ($gameSystem) $gameSystem.sundVrmMouseHoverBoneSetDevMode(!!enabled);
        },
        clear() {
            if ($gameSystem) $gameSystem.sundVrmMouseHoverBoneClear();
        },
        isDebugRenderActive() {
            const data = ensureSystemData($gameSystem);
            return HoverRuntime.isDebugVisualActive(data);
        }
    };
})();