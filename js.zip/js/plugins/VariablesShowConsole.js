//=============================================================================
// RPG Maker MZ - show variables value
//=============================================================================

/*:
 * @target MZ
 * @plugindesc show variables and Switches value in console.
 * @author DB
 *
 *
 * 変数やスイッチに変化があった場合コンソールに表示します。
 */



//変数をコンソールだす
const _Game_Variables_setValue_dx = Game_Variables.prototype.setValue;
Game_Variables.prototype.setValue = function(variableId, value) {
    _Game_Variables_setValue_dx.call(this, variableId, value);
    console.log("変数名:【" + $dataSystem.variables[variableId] + "】, ID:（" + variableId + "） , 値:" + $gameVariables.value(variableId));        
};

const _Game_Switches_setValue_dx = Game_Switches.prototype.setValue;
Game_Switches.prototype.setValue = function(switchId, value) {
    _Game_Switches_setValue_dx.call(this, switchId, value);
    console.log("スイッチ名:【" + $dataSystem.switches[switchId] + "】, ID:（" + switchId + "） , 値:" + $gameSwitches.value(switchId));   

};
