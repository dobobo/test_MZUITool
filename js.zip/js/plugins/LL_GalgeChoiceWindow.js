//=============================================================================
// RPGツクールMZ - LL_GalgeChoiceWindow.js v2.0.1
//-----------------------------------------------------------------------------
// ルルの教会 (Lulu's Church)
// https://nine-yusha.com/
//
// URL below for license details.
// https://nine-yusha.com/plugin/
//=============================================================================

/*:
 * @target MZ
 * @plugindesc Visual novel style choice window plugin.
 * @author Lulu's Church
 * @url https://nine-yusha.com/plugin-galgechoicewindow/
 *
 * @help LL_GalgeChoiceWindow.js
 *
 * Displays a visual novel-style choice window.
 * You can set custom window and button images.
 * (Place images in the img/system folder)
 *
 * Plugin Commands:
 *   Show Choices: Shows choices and stores result in a variable.
 *
 * Terms of use:
 *   ・No copyright notice required.
 *   ・No report needed for use.
 *   ・Free for commercial and non-commercial.
 *   ・No restriction for adult works.
 *   ・You may modify freely for your game.
 *   ・Redistribution as plugin material (incl. modified) prohibited.
 *
 * Author: Lulu's Church
 * Date: 2022/12/9
 *
 * @command showChoice
 * @text Show Choices
 * @desc Displays choices and stores result in a variable.
 *
 * @arg messageText
 * @text Question Message
 * @desc The question message. (Max 2 lines)
 * You can use \V[n], \N[n], \P[n], \G, etc.
 * @type multiline_string
 *
 * @arg choices
 * @text Choice List
 * @desc Strings to display as choices.
 * @default []
 * @type struct<choices>[]
 *
 * @arg maxCols
 * @text Choice Columns
 * @desc Number of columns for displaying choices.
 * @default 1
 * @min 1
 * @max 20
 * @type number
 *
 * @arg variableNumber
 * @text Result Variable
 * @desc Variable ID to store the selected result.
 * @type variable
 *
 * @arg cancelType
 * @text Allow Cancel
 * @desc -1 is stored in the variable when canceled.
 * @default true
 * @type boolean
 *
 * @arg iniPosition
 * @text Initial Cursor
 * @desc Initial position of the cursor. Use number or variable.
 * 0 = no selection.
 * @default 1
 * @type combo
 * @option $gameVariables.value(1)
 * @option 0
 * @option 1
 * @option 2
 * @option 3
 * @option 4
 * @option 5
 * @option 6
 *
 * @arg windowWidth
 * @text Window Width
 * @desc Width of the choice window. Adjust when using BG image.
 * @default 480
 * @min 0
 * @max 9999
 * @type number
 *
 * @arg windowBgImage
 * @text Window Image
 * @desc Select image for custom window background.
 * Default frame will be hidden.
 * @dir img/system
 * @type file
 * @require 1
 *
 * @arg buttonBgImage
 * @text Button Image
 * @desc Image for button background.
 * @dir img/system
 * @type file
 * @require 1
 *
 * @arg buttonFocusImage
 * @text Button Image (Focus)
 * @desc Image shown when the button is selected.
 * Must match base button image size.
 * @dir img/system
 * @type file
 * @require 1
 *
 * @arg buttonImageAdjustX
 * @text Button X Offset
 * @desc X offset for button image. (+ = right, - = left)
 * @default 0
 * @min -9999
 * @max 9999
 * @type number
 *
 * @arg buttonImageAdjustY
 * @text Button Y Offset
 * @desc Y offset for button image. (+ = down, - = up)
 * @default 0
 * @min -9999
 * @max 9999
 * @type number
 *
 * @arg itemHeightAdjust
 * @text Choice Height Adj.
 * @desc Adjusts height of each choice. (Default: 8)
 * Increase if images overlap.
 * @default 8
 * @min -9999
 * @max 9999
 * @type number
 */

/*~struct~choices:
 *
 * @param label
 * @text Choice Text
 * @desc Text to display for the choice.
 * Supports \V[n], \N[n], \P[n], \G, etc.
 * @type string
 *
 * @param switchId
 * @text Switch ID
 * @desc Show only if switch is ON.
 * Usually leave blank.
 * @type switch
 *
 * @param resultNumber
 * @text Result Value
 * @desc Value stored when selected.
 * Use 0 for default index.
 * @default 0
 * @min 0
 * @max 99999999
 * @type number
 */

/*:ja
 * @target MZ
 * @plugindesc ノベルゲーム風選択肢ウィンドウプラグイン
 * @author ルルの教会
 * @url https://nine-yusha.com/plugin-galgechoicewindow/
 *
 * @help LL_GalgeChoiceWindow.js
 *
 * ノベルゲーム風の選択肢ウィンドウを表示します。
 * 独自のウィンドウ画像、ボタン画像を設定することもできます。
 * (画像はimg/systemフォルダに配置してください)
 *
 * プラグインコマンド:
 *   選択肢の表示: 選択肢を表示し、結果を変数で受け取ります。
 *
 * 利用規約:
 *   ・著作権表記は必要ございません。
 *   ・利用するにあたり報告の必要は特にございません。
 *   ・商用・非商用問いません。
 *   ・R18作品にも使用制限はありません。
 *   ・ゲームに合わせて自由に改変していただいて問題ございません。
 *   ・プラグイン素材としての再配布（改変後含む）は禁止させていただきます。
 *
 * 作者: ルルの教会
 * 作成日: 2022/12/9
 *
 * @command showChoice
 * @text 選択肢の表示
 * @desc 選択肢を表示し、結果を変数で受け取ります。
 *
 * @arg messageText
 * @text 質問メッセージ
 * @desc 質問メッセージです。 (2行以内推奨)
 * \V[n]、\N[n]、\P[n]、\Gの制御文字が使用できます。
 * @type multiline_string
 *
 * @arg choices
 * @text 選択肢リスト
 * @desc 選択肢として表示する文字列のリストです。
 * @default []
 * @type struct<choices>[]
 *
 * @arg maxCols
 * @text 選択肢列数
 * @desc 選択肢を何列で表示するかの設定です。
 * @default 1
 * @min 1
 * @max 20
 * @type number
 *
 * @arg variableNumber
 * @text 結果受け取り変数
 * @desc 選択結果を受け取る変数IDを指定します。
 * @type variable
 *
 * @arg cancelType
 * @text キャンセル許可
 * @desc キャンセルされた場合は-1が変数に代入されます。
 * @default true
 * @type boolean
 *
 * @arg iniPosition
 * @text 初期カーソル位置
 * @desc カーソルの初期位置です。(0にすると選択なし)
 * 数値を入力するか変数で指定することもできます。
 * @default 1
 * @type combo
 * @option $gameVariables.value(1)   // 変数ID:1の値
 * @option 0
 * @option 1
 * @option 2
 * @option 3
 * @option 4
 * @option 5
 * @option 6
 *
 * @arg windowWidth
 * @text ウィンドウ幅
 * @desc 選択肢ウィンドウの幅です。
 * 背景画像を使用する場合は横幅を調整してください。
 * @default 480
 * @min 0
 * @max 9999
 * @type number
 *
 * @arg windowBgImage
 * @text ウィンドウ画像
 * @desc ウィンドウ画像を使用する場合は画像を選択してください。
 * 標準のウィンドウ枠は非表示になります。
 * @dir img/system
 * @type file
 * @require 1
 *
 * @arg buttonBgImage
 * @text ボタン画像
 * @desc ボタン画像を使用する場合は画像を選択してください。
 * @dir img/system
 * @type file
 * @require 1
 *
 * @arg buttonFocusImage
 * @text ボタン画像(選択時)
 * @desc フォーカス時のボタン画像を選択してください。
 * ベースとなるボタン画像と大きさを必ず統一してください。
 * @dir img/system
 * @type file
 * @require 1
 *
 * @arg buttonImageAdjustX
 * @text ボタン画像X座標
 * @desc ボタン画像の表示位置(X)の調整値です。(初期値: 0)
 * ＋で右へ、－で左へ調整します。
 * @default 0
 * @min -9999
 * @max 9999
 * @type number
 *
 * @arg buttonImageAdjustY
 * @text ボタン画像Y座標
 * @desc ボタン画像の表示位置(Y)の調整値です。(初期値: 0)
 * ＋で下へ、－で上へ調整します。
 * @default 0
 * @min -9999
 * @max 9999
 * @type number
 *
 * @arg itemHeightAdjust
 * @text 選択肢項目高さ
 * @desc 選択肢項目の高さの調整値です。(初期値: 8)
 * 画像が重なってしまう場合はこの数値を大きくしてください。
 * @default 8
 * @min -9999
 * @max 9999
 * @type number
 */

/*~struct~choices:ja
 *
 * @param label
 * @text 選択肢文字列
 * @desc 選択肢として表示する文字列です。
 * \V[n]、\N[n]、\P[n]、\Gの制御文字が使用できます。
 * @type string
 *
 * @param switchId
 * @text スイッチID
 * @desc スイッチON時のみ選択肢を表示したい場合に設定します。
 * 通常は「なし」のままで問題ありません。
 * @type switch
 *
 * @param resultNumber
 * @text 結果返却値
 * @desc この選択肢が選ばれた時に変数に入力する値を指定できます。
 * 「0」にすると自動で選択肢番号が返却されます。
 * @default 0
 * @min 0
 * @max 99999999
 * @type number
 */

(() => {
    "use strict";
    const pluginName = "LL_GalgeChoiceWindow";

    const parameters = PluginManager.parameters(pluginName);

    // Padding
    const gcwWindowPadding = 32;
    // キャンセル許可時のタッチUI戻るボタンの表示
    const gcwCancelButtonEnabled = false;
    // フェードイン効果フレーム
    const gcwFadeInFrame = 32;

    // 設定保存用変数定義
    let messageTextLists = [];
    let choiceLists = [];
    let maxCols = 1;
    let variableNumber = 0;
    let cancelType = true;
    let iniPosition = 1;
    let gcwWindowWidth = 480;
    let backgroundImage = "";
    let gcwButtonImage = "";
    let gcwButtonFocusImage = "";
    let gcwButtonAdjustX = 0;
    let gcwButtonAdjustY = 0;
    let gcwItemHeightAdjust = 8;


    function isGalgeChoicePluginCommand(command) {
        if (!command || command.code !== 357) return false;
        const params = command.parameters || [];
        return String(params[0] || "") === pluginName && String(params[1] || "") === "showChoice";
    }

    function findAdjacentMessageCommandBefore(list, index) {
        let i = index - 1;
        while (i >= 0 && list[i] && list[i].code === 401) {
            i--;
        }
        return i >= 0 && list[i] && list[i].code === 101 ? i : -1;
    }

    function findAdjacentMessageCommandAfter(list, index) {
        let i = index + 1;
        while (i < list.length && list[i] && list[i].code === 657) {
            i++;
        }
        return i < list.length && list[i] && list[i].code === 101 ? i : -1;
    }

    function findAdjacentGalgeChoiceCommandAfter(list, index) {
        let i = index + 1;
        while (i < list.length && list[i] && list[i].code === 401) {
            i++;
        }
        return i < list.length && isGalgeChoicePluginCommand(list[i]) ? i : -1;
    }

    Game_Interpreter.prototype.llGalgeChoiceHasPreviousMessage = function() {
        return findAdjacentMessageCommandBefore(this._list || [], this._index) >= 0;
    };

    Game_Interpreter.prototype.llGalgeChoiceHasNextMessage = function() {
        return findAdjacentMessageCommandAfter(this._list || [], this._index) >= 0;
    };

    PluginManager.registerCommand(pluginName, "showChoice", function(args) {
        // 設定を取得
        const messageText = String(args.messageText).split("\n");
        const choices = JSON.parse(args.choices || "null");
        maxCols = Number(args.maxCols || 1);
        variableNumber = Number(args.variableNumber);
        cancelType = String(args.cancelType) === "true" ? true : false;
        iniPosition = eval(args.iniPosition);
        gcwWindowWidth = Number(args.windowWidth || 480);
        backgroundImage = String(args.windowBgImage || "");
        gcwButtonImage = String(args.buttonBgImage || "");
        gcwButtonFocusImage = String(args.buttonFocusImage || "");
        gcwButtonAdjustX = Number(args.buttonImageAdjustX || 0);
        gcwButtonAdjustY = Number(args.buttonImageAdjustY || 0);
        gcwItemHeightAdjust = Number(args.itemHeightAdjust || 8);

        messageTextLists = [];
        if (messageText != "") {
            messageText.forEach((elm) => {
                messageTextLists.push(String(elm));
            });
        }

        // 選択肢を定義
        choiceLists = [];
        if (choices) {
            choices.forEach((elm) => {
                if (Number(JSON.parse(elm).switchId) === 0 || $gameSwitches.value(Number(JSON.parse(elm).switchId))) {
                    choiceLists.push(JSON.parse(elm));
                }
            });
        }

        // 選択肢が空の場合、終了
        if (choiceLists.length == 0) {
            console.log(pluginName + ": 有効な選択肢が存在しなかったため、コマンドがスキップされました");
            return;
        }

        if (!$gameMessage.isBusy()) {
            const keepMessageFromPrev = this.llGalgeChoiceHasPreviousMessage();
            const keepMessageToNext = this.llGalgeChoiceHasNextMessage();
            $gameMessage.setGalgeChoices(choiceLists, keepMessageFromPrev, keepMessageToNext);
            this.setWaitMode('message');
        }
    });


    //-----------------------------------------------------------------------------
    // Game_Message
    //

    const _Game_Message_clear = Game_Message.prototype.clear;
    Game_Message.prototype.clear = function() {
        _Game_Message_clear.apply(this, arguments);

        this._galgeChoices = [];
        this._galgeKeepMessageFromPrev = false;
        this._galgeKeepMessageToNext = false;
        this._galgeKeepWindowForChoice = false;
    };

    Game_Message.prototype.galgeChoices = function() {
        return this._galgeChoices;
    };

    Game_Message.prototype.isGalgeChoice = function() {
        return this._galgeChoices.length > 0;
    };

    Game_Message.prototype.setGalgeChoices = function(choices, keepMessageFromPrev, keepMessageToNext) {
        this._galgeChoices = choices;
        this._galgeKeepMessageFromPrev = !!keepMessageFromPrev;
        this._galgeKeepMessageToNext = !!keepMessageToNext;
    };

    Game_Message.prototype.clearGalgeChoices = function() {
        this._galgeChoices = [];
        this._galgeKeepMessageFromPrev = false;
        this._galgeKeepMessageToNext = false;
    };

    Game_Message.prototype.keepMessageFromPrevForGalgeChoice = function() {
        return !!this._galgeKeepMessageFromPrev;
    };

    Game_Message.prototype.keepMessageToNextForGalgeChoice = function() {
        return !!this._galgeKeepMessageToNext;
    };

    Game_Message.prototype.reserveMessageWindowKeepForGalgeChoice = function() {
        this._galgeKeepWindowForChoice = true;
    };

    Game_Message.prototype.consumeMessageWindowKeepForGalgeChoice = function() {
        const result = !!this._galgeKeepWindowForChoice;
        this._galgeKeepWindowForChoice = false;
        return result;
    };

    Game_Message.prototype.clearBusyStateForGalgeChoiceKeep = function() {
        // 直前メッセージを表示したまま選択肢へ遷移する時に Game_Message.clear() を呼ぶと、
        // 他プラグインが保持しているメッセージウィンドウの高さ・位置関連の状態まで
        // 初期化されることがあります。ここでは待機解除に必要なメッセージ情報だけを
        // 最小限クリアし、表示中ウィンドウの見た目は維持します。
        this._texts = [];
        this._choices = [];
        this._choiceCallback = null;
        this._numInputVariableId = 0;
        this._numInputMaxDigits = 0;
        this._itemChoiceVariableId = 0;
        this._itemChoiceItypeId = 0;
        this._scrollMode = false;
        this._scrollSpeed = 2;
        this._scrollNoFast = false;
    };

    const _Game_Interpreter_command101 = Game_Interpreter.prototype.command101;
    Game_Interpreter.prototype.command101 = function(params) {
        const result = _Game_Interpreter_command101.apply(this, arguments);
        if ($gameMessage.hasText() && findAdjacentGalgeChoiceCommandAfter(this._list || [], this._index) >= 0) {
            $gameMessage.reserveMessageWindowKeepForGalgeChoice();
        }
        return result;
    };

    const _Game_Message_isBusy = Game_Message.prototype.isBusy;
    Game_Message.prototype.isBusy = function() {
        return (
            _Game_Message_isBusy.apply(this, arguments) ||
            this.isGalgeChoice()
        );
    };


    //-----------------------------------------------------------------------------
    // Scene_Message
    //

    const _Scene_Message_createAllWindows = Scene_Message.prototype.createAllWindows;
    Scene_Message.prototype.createAllWindows = function() {
        _Scene_Message_createAllWindows.apply(this, arguments);
        this.createGalgeChoiceListWindow();
        this.associateGalgeChoiceWindow();
    };

    Scene_Message.prototype.createGalgeChoiceListWindow = function() {
        this._galgeChoiceListWindow = new Window_GalgeChoiceList();
        this.addWindow(this._galgeChoiceListWindow);
    };

    Scene_Message.prototype.associateGalgeChoiceWindow = function() {
        if (!this._messageWindow || !this._galgeChoiceListWindow) return;
        this._messageWindow.setGalgeChoiceListWindow(this._galgeChoiceListWindow);
        this._galgeChoiceListWindow.setMessageWindow(this._messageWindow);
    };

    const _Scene_Message_associateWindows = Scene_Message.prototype.associateWindows;
    Scene_Message.prototype.associateWindows = function() {
        _Scene_Message_associateWindows.apply(this, arguments);
        this.associateGalgeChoiceWindow();
    };

    const _Scene_Message_update = Scene_Message.prototype.update;
    Scene_Message.prototype.update = function() {
        _Scene_Message_update.apply(this, arguments);
        if (this._galgeChoiceListWindow && this._galgeChoiceListWindow.isOpen()) {
            this._galgeChoiceListWindow.bringToFront();
        }
    };


    //-----------------------------------------------------------------------------
    // Window_Message
    //

    const _Window_Message_initMembers = Window_Message.prototype.initMembers;
    Window_Message.prototype.initMembers = function() {
        _Window_Message_initMembers.apply(this, arguments);

        this._galgeChoiceListWindow = null;
        this._galgeMessageVisibleByChoice = false;
    };

    const _Window_Message_terminateMessage = Window_Message.prototype.terminateMessage;
    Window_Message.prototype.terminateMessage = function() {
        if ($gameMessage.consumeMessageWindowKeepForGalgeChoice()) {
            this._galgeMessageVisibleByChoice = true;
            this.pause = false;
            this._textState = null;
            this._closing = false;
            if (this._goldWindow) {
                this._goldWindow.close();
            }
            $gameMessage.clearBusyStateForGalgeChoiceKeep();
            return;
        }
        _Window_Message_terminateMessage.apply(this, arguments);
    };

    const _Window_Message_startInput = Window_Message.prototype.startInput;
    Window_Message.prototype.startInput = function() {
        if ($gameMessage.isGalgeChoice()) {
            if (this._galgeMessageVisibleByChoice) {
                this._closing = false;
                this.open();
            }
            this._galgeChoiceListWindow.start();
            return true;
        }

        return _Window_Message_startInput.apply(this, arguments);
    };

    Window_Message.prototype.onGalgeChoiceEnd = function() {
        const keepMessageFromPrev = this._galgeMessageVisibleByChoice;
        const keepMessageToNext = keepMessageFromPrev && $gameMessage.keepMessageToNextForGalgeChoice();
        $gameMessage.clearGalgeChoices();
        if (keepMessageFromPrev) {
            this._galgeMessageVisibleByChoice = false;
            if (!keepMessageToNext) {
                this.close();
                if (this._nameBoxWindow) {
                    this._nameBoxWindow.hide();
                }
            }
        } else {
            this.terminateMessage();
        }
    };

    Window_Message.prototype.setGalgeChoiceListWindow = function(galgeChoiceListWindow) {
        this._galgeChoiceListWindow = galgeChoiceListWindow;
    };

    const _Window_Message_isAnySubWindowActive = Window_Message.prototype.isAnySubWindowActive;
    Window_Message.prototype.isAnySubWindowActive = function() {
        if (this._galgeChoiceListWindow) {
            return (
                _Window_Message_isAnySubWindowActive.apply(this, arguments) ||
                this._galgeChoiceListWindow.active
            );
        }

        return _Window_Message_isAnySubWindowActive.apply(this, arguments);
    };

    //-----------------------------------------------------------------------------
    // Window_GalgeChoiceList
    //
    // ノベルゲーム風選択肢ウィンドウを定義します。

    function Window_GalgeChoiceList() {
        this.initialize(...arguments);
    }

    Window_GalgeChoiceList.prototype = Object.create(Window_Command.prototype);
    Window_GalgeChoiceList.prototype.constructor = Window_GalgeChoiceList;

    Window_GalgeChoiceList.prototype.initialize = function() {
        Window_Command.prototype.initialize.call(this, new Rectangle());
        this.createCancelButton();
        this.openness = 0;
        this.deactivate();
        this._background = 0;
        this._canRepeat = false;
        // フォーカスアニメーション判定
        this._originalCursorSpriteFade = true;
    };

    Window_GalgeChoiceList.prototype.setMessageWindow = function(messageWindow) {
        this._messageWindow = messageWindow;
    };

    Window_GalgeChoiceList.prototype.createCancelButton = function() {
        if (ConfigManager.touchUI) {
            this._cancelButton = new Sprite_Button("cancel");
            this._cancelButton.visible = false;
            this.addChild(this._cancelButton);
        }
    };

    Window_GalgeChoiceList.prototype.start = function() {
        this.updatePlacement();
        this.bringToFront();
        this.createCancelButton();
        this.placeCancelButton();
        this.createContents();
        this.refresh();
        this.setQuestionText();
        this.setSymbol();
        this.createOriginalBackground();
        this.open();
        this.activate();
    };

    const _Window_GalgeChoiceList_refresh = Window_GalgeChoiceList.prototype.refresh;
    Window_GalgeChoiceList.prototype.refresh = function() {
        this.removeChild(this._bgSprite);
        this._bgSprite = null;
        this.removeChild(this._bgDummy);
        this._bgDummy = null;
        this.removeChild(this._originalCursorSprite);
        this._originalCursorSprite = null;
        this.removeChild(this._originalButtonSprite);
        this._originalButtonSprite = null;

        // ウィンドウ枠、カーソルを初期化
        this.setCursorRect(0, 0, 0, 0);
        this.opacity = 255;

        _Window_GalgeChoiceList_refresh.apply(this, arguments);
    };

    Window_GalgeChoiceList.prototype.keepPreviousMessageVisible = function() {
        return !!(this._messageWindow && this._messageWindow._galgeMessageVisibleByChoice);
    };

    Window_GalgeChoiceList.prototype.bringToFront = function() {
        if (this.parent) {
            this.parent.addChild(this);
        }
    };

    Window_GalgeChoiceList.prototype.updatePlacement = function() {
        const wh = this.calcWindowHeight();
        const ww = gcwWindowWidth;
        const wx = Math.floor((Graphics.boxWidth - ww) / 2);
        const wy = Math.floor((Graphics.boxHeight - wh) / 2);

        this.width = ww;
        this.height = wh;
        this.x = wx;
        this.y = wy;
    };

    Window_GalgeChoiceList.prototype.calcWindowHeight = function() {
        // ウィンドウの高さを計算
        const itemCols = Math.ceil(choiceLists.length / maxCols);
        let height = this.lineHeight() * messageTextLists.length;
        if (messageTextLists.length > 0) height += gcwWindowPadding;
        height += (this.itemHeight()) * itemCols;
        height += gcwWindowPadding * 2;  // padding
        return height;
    };

    Window_GalgeChoiceList.prototype.createCancelButton = function() {
        if (ConfigManager.touchUI) {
            this._cancelButton = new Sprite_Button("cancel");
            this._cancelButton.visible = false;
            this.addChild(this._cancelButton);
        }
    };

    Window_GalgeChoiceList.prototype.createOriginalBackground = function() {
        if (backgroundImage != "") {
            this._bgSprite = new Sprite();
            this._bgSprite.bitmap = ImageManager.loadSystem(backgroundImage);
            this._bgSprite.bitmap.addLoadListener(function() {
                this._bgSprite.x = this.width / 2 - this._bgSprite.width / 2;
                this._bgSprite.y = this.height / 2 - this._bgSprite.height / 2;
            }.bind(this));
            this._bgSprite.opacity = 0;
            this.addChildToBack(this._bgSprite);
            // ウィンドウ枠を消去
            this.opacity = 0;
        }
    };

    Window_GalgeChoiceList.prototype.drawAllItems = function() {
        this.createOriginalCursor();
        this.createOriginalButton();
        Window_Selectable.prototype.drawAllItems.call(this);
    };

    Window_GalgeChoiceList.prototype.createOriginalCursor = function() {
        if (gcwButtonFocusImage != "") {
            this._originalCursorSprite = null;
            this._originalCursorSprite = new Sprite();
            this._originalCursorSprite.bitmap = ImageManager.loadSystem(gcwButtonFocusImage);
            this._originalCursorSprite.opacity = 128;
            this._originalCursorSprite.visible = true;
            this.addChildToBack(this._originalCursorSprite);
        }
    };

    Window_GalgeChoiceList.prototype.createOriginalButton = function() {
        if (gcwButtonImage != "") {
            this._originalButtonSprite = null;
            this._originalButtonSprite = new Sprite();
            this._originalButtonSprite.visible = false;
            this.addChildToBack(this._originalButtonSprite);
        }
    };

    Window_GalgeChoiceList.prototype.drawBackgroundRect = function(rect) {
        const c1 = ColorManager.itemBackColor1();
        const c2 = ColorManager.itemBackColor2();
        const x = rect.x;
        const y = rect.y;
        const w = rect.width;
        const h = rect.height;
        if (gcwButtonImage != "") {
            const originalButtonSprite = new Sprite();
            originalButtonSprite.bitmap = ImageManager.loadSystem(gcwButtonImage);
            originalButtonSprite.x = x + gcwButtonAdjustX + gcwWindowPadding;
            originalButtonSprite.y = y + gcwButtonAdjustY + gcwWindowPadding;
            this._originalButtonSprite.addChild(originalButtonSprite);
        } else {
            this.contentsBack.gradientFillRect(x, y, w, h, c1, c2, true);
            this.contentsBack.strokeRect(x, y, w, h, c1);
        }
    };

    Window_GalgeChoiceList.prototype.refreshCursor = function() {
        if (this._cursorAll) {
            this.refreshCursorForAll();
        } else if (this.index() >= 0) {
            const rect = this.itemRect(this.index());
            if (gcwButtonFocusImage != "") {
                if (this._originalCursorSprite) {
                    this._originalCursorSprite.x = rect.x + gcwButtonAdjustX + gcwWindowPadding;
                    this._originalCursorSprite.y = rect.y + gcwButtonAdjustY + gcwWindowPadding;
                }
            } else {
                this.setCursorRect(rect.x, rect.y, rect.width, rect.height);
            }
        } else {
            this.setCursorRect(0, 0, 0, 0);
        }
    };

    Window_GalgeChoiceList.prototype.refreshCursorForAll = function() {
        const maxItems = this.maxItems();
        if (maxItems > 0) {
            const rect = this.itemRect(0);
            rect.enlarge(this.itemRect(maxItems - 1));
            if (gcwButtonFocusImage != "") {
                if (this._originalCursorSprite) {
                    this._originalCursorSprite.x = rect.x + gcwButtonAdjustX;
                    this._originalCursorSprite.y = rect.y + gcwButtonAdjustY;
                }
            } else {
                this.setCursorRect(rect.x, rect.y, rect.width, rect.height);
            }
        } else {
            this.setCursorRect(0, 0, 0, 0);
        }
    };

    Window_GalgeChoiceList.prototype.update = function() {
        Window_Command.prototype.update.call(this);
        this.updateCancelButton();
        this.updateOriginalButton();
        this.updateOriginalCursorButton();
        if (this._bgSprite) this._bgSprite.opacity = this.openness;
    };

    Window_GalgeChoiceList.prototype.updateOriginalButton = function() {
        if (this._originalButtonSprite) {
            if (this.isOpen()) {
                this._originalButtonSprite.visible = true;
            } else {
                this._originalButtonSprite.visible = false;
            }
        }
    };

    Window_GalgeChoiceList.prototype.updateOriginalCursorButton = function() {
        if (this._originalCursorSprite) {
            if (this.isOpen() && this._index > -1) {
                this._originalCursorSprite.visible = true;
                if (this._originalCursorSprite.opacity >= 255) this._originalCursorSpriteFade = false;
                if (this._originalCursorSprite.opacity <= 128) this._originalCursorSpriteFade = true;
                this._originalCursorSprite.opacity += this._originalCursorSpriteFade ? 6 : -6;
            } else {
                this._originalCursorSprite.visible = false;
            }
        }
    };

    Window_GalgeChoiceList.prototype.updateOpen = function() {
        if (this._opening) {
            this.openness += gcwFadeInFrame;
            if (this.isOpen()) {
                this._opening = false;
            }
        }
    };

    Window_GalgeChoiceList.prototype.updateCancelButton = function() {
        if (this._cancelButton) {
            this._cancelButton.visible = this.needsCancelButton() && this.isOpen() && gcwCancelButtonEnabled;
        }
    };

    Window_GalgeChoiceList.prototype.needsCancelButton = function() {
        return cancelType;
    };

    Window_GalgeChoiceList.prototype.placeCancelButton = function() {
        if (this._cancelButton) {
            const spacing = 8;
            const button = this._cancelButton;
            const right = this.x + this.width;
            if (right < Graphics.boxWidth - button.width + spacing) {
                button.x = this.width + spacing;
            } else {
                button.x = -button.width - spacing;
            }
            button.y = this.height / 2 - button.height / 2;
        }
    };

    Window_GalgeChoiceList.prototype.maxCols = function() {
        return maxCols;
    };

    Window_GalgeChoiceList.prototype.convertEscapeCharacters = function(text) {
        let result = text == null ? "" : String(text);
        for (let i = 0; i < 10; i++) {
            const next = Window_Base.prototype.convertEscapeCharacters.call(this, result);
            if (next === result) {
                break;
            }
            result = next;
        }
        return result;
    };

    Window_GalgeChoiceList.prototype.drawTextExAlign = function(text, x, y, width, align) {
        const rawText = text == null ? "" : String(text);
        const textRect = this.textSizeEx(rawText);
        let drawX = x;
        if (align === "center") {
            drawX = x + Math.max(0, Math.floor((width - textRect.width) / 2));
        } else if (align === "right") {
            drawX = x + Math.max(0, width - textRect.width);
        }
        return this.drawTextEx(rawText, drawX, y, width);
    };

    Window_GalgeChoiceList.prototype.setQuestionText = function() {
        messageTextLists.forEach((text, index) => {
            this.drawTextExAlign(text, 0, this.lineHeight() * index, this.innerWidth, "center");
        }, this);
    };

    Window_GalgeChoiceList.prototype.makeCommandList = function() {
        choiceLists.forEach(function(elm, index) {
            this.addCommand(String(elm.label), Number(elm.resultNumber || 0) !== 0 ? Number(elm.resultNumber) : index + 1);
        }, this);
    };

    Window_GalgeChoiceList.prototype.updatePadding = function() {
        this.padding = gcwWindowPadding;
    };

    Window_GalgeChoiceList.prototype.scrollBaseY = function(index) {
        let margin = this.lineHeight() * messageTextLists.length;
        if (messageTextLists.length > 0) margin += gcwWindowPadding;
        return this._scrollBaseY - margin;
    };

    Window_GalgeChoiceList.prototype.setSymbol = function() {
        if (iniPosition > 0) {
            this.selectSymbol(iniPosition);
        } else {
            this.deselect();
        }
    };

    Window_GalgeChoiceList.prototype.itemHeight = function() {
        return Window_Scrollable.prototype.itemHeight.call(this) + gcwItemHeightAdjust;
    };

    Window_GalgeChoiceList.prototype.drawItem = function(index) {
        const rect = this.itemLineRect(index);
        const align = this.itemTextAlign();
        this.resetTextColor();
        this.changePaintOpacity(this.isCommandEnabled(index));
        this.drawTextExAlign(this.commandName(index), rect.x, rect.y, rect.width, align);
    };

    Window_GalgeChoiceList.prototype.isCancelEnabled = function() {
        return cancelType;
    };

    Window_GalgeChoiceList.prototype.isOkTriggered = function() {
        return Input.isTriggered('ok');
    };

    Window_GalgeChoiceList.prototype.callOkHandler = function() {
        $gameVariables.setValue(variableNumber, this.currentSymbol());
        this._messageWindow.onGalgeChoiceEnd();
        this.close();
    };

    Window_GalgeChoiceList.prototype.callCancelHandler = function() {
        $gameVariables.setValue(variableNumber, -1);
        this._messageWindow.onGalgeChoiceEnd();
        this.close();
    };
})();
