/*:
 * @target MZ
 * @plugindesc 指定範囲ハイライト（BuildMap.js / UltraMode7 疑似3D対応）
 * @author DB
 *
 * @param OkColor
 * @text OK色
 * @type string
 * @default #50ff78
 *
 * @param NgColor
 * @text NG色
 * @type string
 * @default #ff5050
 *
 * @param FillAlpha
 * @text 塗りアルファ
 * @type number
 * @decimals 2
 * @min 0
 * @max 1
 * @default 0.25
 *
 * @param LineAlpha
 * @text 線アルファ
 * @type number
 * @decimals 2
 * @min 0
 * @max 1
 * @default 0.75
 *
 * @param LineWidth
 * @text 線の太さ
 * @type number
 * @min 1
 * @default 1
 *
 * @param PulseSpeed
 * @text 点滅速度（0で固定）
 * @type number
 * @decimals 3
 * @default 0
 *
 * @command ShowRect
 * @text 矩形表示
 * @arg id
 * @text ID
 * @type string
 * @default main
 * @arg x
 * @text X
 * @type number
 * @default 0
 * @arg y
 * @text Y
 * @type number
 * @default 0
 * @arg width
 * @text 幅
 * @type number
 * @min 1
 * @default 1
 * @arg height
 * @text 高さ
 * @type number
 * @min 1
 * @default 1
 * @arg ok
 * @text OK色を使う
 * @type boolean
 * @default true
 *
 * @command ShowDiamond
 * @text 菱形表示
 * @arg id
 * @text ID
 * @type string
 * @default main
 * @arg x
 * @text 中心X
 * @type number
 * @default 0
 * @arg y
 * @text 中心Y
 * @type number
 * @default 0
 * @arg radius
 * @text 半径
 * @type number
 * @min 0
 * @default 1
 * @arg ok
 * @text OK色を使う
 * @type boolean
 * @default true
 *
 * @command Hide
 * @text 指定ID消去
 * @arg id
 * @text ID
 * @type string
 * @default main
 *
 * @command Clear
 * @text 全消去
 */

(() => {
    "use strict";

    const PLUGIN_NAME = document.currentScript.src.split("/").pop().replace(/\.js$/, "");
    const params = PluginManager.parameters(PLUGIN_NAME);

    const OK_COLOR_CSS = String(params.OkColor || "#50ff78");
    const NG_COLOR_CSS = String(params.NgColor || "#ff5050");
    const FILL_ALPHA = Number(params.FillAlpha || 0.25);
    const LINE_ALPHA = Number(params.LineAlpha || 0.75);
    const LINE_WIDTH = Math.max(1, Number(params.LineWidth || 1));
    const PULSE_SPEED = Number(params.PulseSpeed || 0);

    function cssToHexNumber(css) {
        const m = String(css).trim().match(/^#([0-9a-fA-F]{6})$/);
        return m ? Number("0x" + m[1]) : 0xffffff;
    }

    function dbIsUltraMode7ActiveLocal() {
        return !!(window.UltraMode7 && typeof UltraMode7.isActive === "function" && UltraMode7.isActive());
    }

    // BuildMap.js の helper に合わせた座標変換
    function mapPointToScreen(tileX, tileY) {
        const tw = $gameMap.tileWidth();
        const th = $gameMap.tileHeight();

        if (dbIsUltraMode7ActiveLocal() && typeof UltraMode7.mapToScreen === "function") {
            let mx = tileX;
            let my = tileY;

            if (typeof $gameMap.adjustUltraMode7LoopedPosition === "function") {
                const p = $gameMap.adjustUltraMode7LoopedPosition(tileX, tileY);
                mx = p.x;
                my = p.y;
            }

            const s = UltraMode7.mapToScreen(mx * tw, my * th);
            return { x: s.x, y: s.y, z: s.z || 0 };
        }

        return {
            x: Math.floor($gameMap.adjustX(tileX) * tw),
            y: Math.floor($gameMap.adjustY(tileY) * th),
            z: 0
        };
    }

    function getTilePolygonPoints(tx, ty) {
        return {
            p1: mapPointToScreen(tx,     ty),
            p2: mapPointToScreen(tx + 1, ty),
            p3: mapPointToScreen(tx + 1, ty + 1),
            p4: mapPointToScreen(tx,     ty + 1)
        };
    }

    function drawTilePolygon(g, tx, ty, fillColor, fillAlpha, lineColor, lineAlpha) {
        const p = getTilePolygonPoints(tx, ty);
        g.lineStyle(LINE_WIDTH, lineColor, lineAlpha, 1);
        g.beginFill(fillColor, fillAlpha);
        g.drawPolygon([
            p.p1.x, p.p1.y,
            p.p2.x, p.p2.y,
            p.p3.x, p.p3.y,
            p.p4.x, p.p4.y
        ]);
        g.endFill();
    }

    function makeCellSet(cells) {
        const set = new Set();
        for (const c of cells) {
            set.add(`${c.x},${c.y}`);
        }
        return set;
    }

    function buildRectCells(x, y, width, height) {
        const cells = [];
        for (let dy = 0; dy < height; dy++) {
            for (let dx = 0; dx < width; dx++) {
                cells.push({ x: x + dx, y: y + dy });
            }
        }
        return cells;
    }

    function buildDiamondCells(cx, cy, radius) {
        const cells = [];
        for (let dy = -radius; dy <= radius; dy++) {
            const remain = radius - Math.abs(dy);
            for (let dx = -remain; dx <= remain; dx++) {
                cells.push({ x: cx + dx, y: cy + dy });
            }
        }
        return cells;
    }

    function pulseRate(area) {
        if (PULSE_SPEED <= 0) return 1.0;
        area.phase = Number(area.phase || 0) + PULSE_SPEED;
        const t = (Math.sin(area.phase) + 1) * 0.5;
        return 0.4 + t * 0.6;
    }

    window.RectHighlightManager = {
        _areas: {},

        showRect(id, x, y, width, height, ok = true) {
            this._areas[String(id)] = {
                type: "rect",
                x: Number(x),
                y: Number(y),
                width: Math.max(1, Number(width)),
                height: Math.max(1, Number(height)),
                ok: !!ok,
                phase: 0
            };
        },

        showDiamond(id, x, y, radius, ok = true) {
            this._areas[String(id)] = {
                type: "diamond",
                x: Number(x),
                y: Number(y),
                radius: Math.max(0, Number(radius)),
                ok: !!ok,
                phase: 0
            };
        },

        hide(id) {
            delete this._areas[String(id)];
        },

        clear() {
            this._areas = {};
        }
    };

class Sprite_RectHighlight extends PIXI.Container {
    constructor() {
        super();
        this._graphics = new PIXI.Graphics();
        this.addChild(this._graphics);

        // tilemap配下での前後関係用
        this.z = 2;
        this.y = 0;
    }

        update() {
            this.redraw();
        }

        redraw() {
            const g = this._graphics;
            g.clear();

            for (const id in RectHighlightManager._areas) {
                this.drawArea(g, RectHighlightManager._areas[id]);
            }
        }

        drawArea(g, area) {
            const color = area.ok ? cssToHexNumber(OK_COLOR_CSS) : cssToHexNumber(NG_COLOR_CSS);
            const rate = pulseRate(area);
            const fillAlpha = FILL_ALPHA * rate;
            const lineAlpha = LINE_ALPHA * rate;

            const cells = area.type === "rect"
                ? buildRectCells(area.x, area.y, area.width, area.height)
                : buildDiamondCells(area.x, area.y, area.radius);

            const set = makeCellSet(cells);

            // まず各マスを疑似3Dポリゴンで描く
            for (const cell of cells) {
                if (!$gameMap.isValid(cell.x, cell.y)) continue;
                drawTilePolygon(g, cell.x, cell.y, color, fillAlpha, color, lineAlpha);
            }

            // 次に内部グリッド線を、タイル境界の共有辺として描く
            g.lineStyle(LINE_WIDTH, color, lineAlpha, 1);

            for (const cell of cells) {
                if (!$gameMap.isValid(cell.x, cell.y)) continue;

                const keyRight = `${cell.x + 1},${cell.y}`;
                const keyDown  = `${cell.x},${cell.y + 1}`;

                const p = getTilePolygonPoints(cell.x, cell.y);

                // 右隣がある → 共有辺 p2-p3
                if (set.has(keyRight)) {
                    g.moveTo(p.p2.x, p.p2.y);
                    g.lineTo(p.p3.x, p.p3.y);
                }

                // 下隣がある → 共有辺 p4-p3
                if (set.has(keyDown)) {
                    g.moveTo(p.p4.x, p.p4.y);
                    g.lineTo(p.p3.x, p.p3.y);
                }
            }
        }
    }

const _Spriteset_Map_createLowerLayer = Spriteset_Map.prototype.createLowerLayer;
Spriteset_Map.prototype.createLowerLayer = function() {
    _Spriteset_Map_createLowerLayer.call(this);
    this.createRectHighlightLayer();
};

Spriteset_Map.prototype.createRectHighlightLayer = function() {
    this._rectHighlightSprite = new Sprite_RectHighlight();

    // 床タイルの上、キャラの下を狙う
    // character の z より少し低め
    this._rectHighlightSprite.z = 2;
    this._rectHighlightSprite.y = 0;

    this._tilemap.addChild(this._rectHighlightSprite);
};

const _Spriteset_Map_update = Spriteset_Map.prototype.update;
Spriteset_Map.prototype.update = function() {
    _Spriteset_Map_update.call(this);
    if (this._rectHighlightSprite && this._rectHighlightSprite.update) {
        this._rectHighlightSprite.update();
    }
};

    PluginManager.registerCommand(PLUGIN_NAME, "ShowRect", args => {
        RectHighlightManager.showRect(
            String(args.id || "main"),
            Number(args.x || 0),
            Number(args.y || 0),
            Number(args.width || 1),
            Number(args.height || 1),
            args.ok !== "false"
        );
    });

    PluginManager.registerCommand(PLUGIN_NAME, "ShowDiamond", args => {
        RectHighlightManager.showDiamond(
            String(args.id || "main"),
            Number(args.x || 0),
            Number(args.y || 0),
            Number(args.radius || 0),
            args.ok !== "false"
        );
    });

    PluginManager.registerCommand(PLUGIN_NAME, "Hide", args => {
        RectHighlightManager.hide(String(args.id || "main"));
    });

    PluginManager.registerCommand(PLUGIN_NAME, "Clear", () => {
        RectHighlightManager.clear();
    });
})();