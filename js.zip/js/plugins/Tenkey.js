/*:
 * @target MZ
 * @plugindesc v1.0 テンキー0～9を条件分岐やイベントで判定できるようにします
 * @author OpenAI
 *
 * @help
 * 【概要】
 * テンキー0～9を、RPGツクールMZ上で専用に判定できるようにします。
 * 標準のInput.keyMapperを書き換えないため、
 * 既存のカーソル移動や通常キー入力を壊しにくい構成です。
 *
 * 【使い方1：条件分岐の「スクリプト」】
 * 条件分岐 → スクリプト に以下を書いてください。
 *
 * 1回押した瞬間を判定：
 * Input.isNumpadTriggered(1)
 *
 * 押している間ずっと判定：
 * Input.isNumpadPressed(1)
 *
 * 長押し判定：
 * Input.isNumpadLongPressed(1)
 *
 * キーリピート判定：
 * Input.isNumpadRepeated(1)
 *
 * 離した瞬間を判定：
 * Input.isNumpadReleased(1)
 *
 * 例：
 * 条件分岐：スクリプト Input.isNumpadTriggered(5)
 * → テンキー5を押した瞬間だけ分岐成立
 *
 * --------------------------------------------------
 * 【使い方2：プラグインコマンドでスイッチへ反映】
 * プラグインコマンド「CheckNumpad」を使うと、
 * 指定したテンキーの状態をスイッチへ代入できます。
 *
 * 例：
 * CheckNumpad
 *   key: 3
 *   mode: triggered
 *   switchId: 10
 *
 * → そのフレームでテンキー3が押された瞬間なら、
 *    スイッチ10がONになります。そうでなければOFFです。
 *
 * そのあと通常の条件分岐で
 * 「スイッチ10がON」を使えます。
 *
 * --------------------------------------------------
 * 【使い方3：最後に押されたテンキー番号を変数へ保存】
 * プラグインコマンド「StoreTriggeredNumpad」を使うと、
 * そのフレームで押されたテンキー番号を変数に入れられます。
 *
 * 例：
 * StoreTriggeredNumpad
 *   variableId: 20
 *   noInputValue: -1
 *
 * → テンキー7が押されたら変数20 = 7
 * → 何も押されていなければ変数20 = -1
 *
 * --------------------------------------------------
 * 【スクリプト一覧】
 * Input.isNumpadPressed(number)
 * Input.isNumpadTriggered(number)
 * Input.isNumpadRepeated(number)
 * Input.isNumpadLongPressed(number)
 * Input.isNumpadReleased(number)
 * Input.getTriggeredNumpad()
 *
 * getTriggeredNumpad() は、
 * そのフレームで押されたテンキー番号を返します。
 * 何もなければ -1 です。
 *
 * --------------------------------------------------
 * 【補足】
 * ・物理的なテンキーを見ています。
 * ・NumLockの状態によって、OS側では矢印やHome/End扱いになる場合がありますが、
 *   このプラグインは「テンキーの物理キー」として判定します。
 * ・同じフレームで複数のテンキーが押された場合、
 *   getTriggeredNumpad() と StoreTriggeredNumpad は
 *   小さい番号から順に見て、最初に見つかったものを返します。
 *
 * @command CheckNumpad
 * @text テンキー判定→スイッチ
 * @desc 指定したテンキーの状態をスイッチへ反映します
 *
 * @arg key
 * @text テンキー番号
 * @type select
 * @option 0
 * @value 0
 * @option 1
 * @value 1
 * @option 2
 * @value 2
 * @option 3
 * @value 3
 * @option 4
 * @value 4
 * @option 5
 * @value 5
 * @option 6
 * @value 6
 * @option 7
 * @value 7
 * @option 8
 * @value 8
 * @option 9
 * @value 9
 * @default 0
 *
 * @arg mode
 * @text 判定方法
 * @type select
 * @option 押した瞬間
 * @value triggered
 * @option 押している間
 * @value pressed
 * @option 長押し
 * @value longPressed
 * @option リピート
 * @value repeated
 * @option 離した瞬間
 * @value released
 * @default triggered
 *
 * @arg switchId
 * @text 反映先スイッチ
 * @type switch
 * @default 1
 *
 * @command StoreTriggeredNumpad
 * @text 押したテンキー番号→変数
 * @desc そのフレームで押されたテンキー番号を変数へ保存します
 *
 * @arg variableId
 * @text 保存先変数
 * @type variable
 * @default 1
 *
 * @arg noInputValue
 * @text 入力なし時の値
 * @type number
 * @default -1
 */

(() => {
    "use strict";

    const pluginName = document.currentScript.src.match(/([^\/]+)\.js$/)[1];

    const numpadState = {
        raw: Array(10).fill(false),
        current: Array(10).fill(false),
        previous: Array(10).fill(false),
        triggered: Array(10).fill(false),
        released: Array(10).fill(false),
        pressedTime: Array(10).fill(0)
    };

    function clearNumpadState() {
        for (let i = 0; i <= 9; i++) {
            numpadState.raw[i] = false;
            numpadState.current[i] = false;
            numpadState.previous[i] = false;
            numpadState.triggered[i] = false;
            numpadState.released[i] = false;
            numpadState.pressedTime[i] = 0;
        }
    }

    function toNumpadNumber(value) {
        const n = Number(value);
        if (!Number.isInteger(n)) return -1;
        if (n < 0 || n > 9) return -1;
        return n;
    }

    function eventToNumpadNumber(event) {
        if (event && typeof event.code === "string") {
            const match = event.code.match(/^Numpad([0-9])$/);
            if (match) {
                return Number(match[1]);
            }
        }

        const keyCode = Number(event.keyCode || 0);
        if (keyCode >= 96 && keyCode <= 105) {
            return keyCode - 96;
        }

        return -1;
    }

    function updateNumpadState() {
        for (let i = 0; i <= 9; i++) {
            const wasPressed = numpadState.current[i];
            const isPressed = !!numpadState.raw[i];

            numpadState.previous[i] = wasPressed;
            numpadState.current[i] = isPressed;
            numpadState.triggered[i] = isPressed && !wasPressed;
            numpadState.released[i] = !isPressed && wasPressed;

            if (isPressed) {
                if (!wasPressed) {
                    numpadState.pressedTime[i] = 0;
                } else {
                    numpadState.pressedTime[i]++;
                }
            } else {
                numpadState.pressedTime[i] = 0;
            }
        }
    }

    const _Input_clear = Input.clear;
    Input.clear = function() {
        _Input_clear.call(this);
        clearNumpadState();
    };

    const _Input_update = Input.update;
    Input.update = function() {
        _Input_update.call(this);
        updateNumpadState();
    };

    const _SceneManager_setupEventHandlers = SceneManager.setupEventHandlers;
    SceneManager.setupEventHandlers = function() {
        _SceneManager_setupEventHandlers.call(this);

        document.addEventListener("keydown", event => {
            const n = eventToNumpadNumber(event);
            if (n >= 0) {
                numpadState.raw[n] = true;
            }
        });

        document.addEventListener("keyup", event => {
            const n = eventToNumpadNumber(event);
            if (n >= 0) {
                numpadState.raw[n] = false;
            }
        });

        window.addEventListener("blur", () => {
            clearNumpadState();
        });
    };

    Input.isNumpadPressed = function(number) {
        const n = toNumpadNumber(number);
        return n >= 0 ? !!numpadState.current[n] : false;
    };

    Input.isNumpadTriggered = function(number) {
        const n = toNumpadNumber(number);
        return n >= 0 ? !!numpadState.triggered[n] : false;
    };

    Input.isNumpadReleased = function(number) {
        const n = toNumpadNumber(number);
        return n >= 0 ? !!numpadState.released[n] : false;
    };

    Input.isNumpadRepeated = function(number) {
        const n = toNumpadNumber(number);
        if (n < 0) return false;
        if (!numpadState.current[n]) return false;
        return (
            numpadState.triggered[n] ||
            (
                numpadState.pressedTime[n] >= this.keyRepeatWait &&
                numpadState.pressedTime[n] % this.keyRepeatInterval === 0
            )
        );
    };

    Input.isNumpadLongPressed = function(number) {
        const n = toNumpadNumber(number);
        if (n < 0) return false;
        return (
            numpadState.current[n] &&
            numpadState.pressedTime[n] >= this.keyRepeatWait
        );
    };

    Input.getTriggeredNumpad = function() {
        for (let i = 0; i <= 9; i++) {
            if (numpadState.triggered[i]) {
                return i;
            }
        }
        return -1;
    };

    PluginManager.registerCommand(pluginName, "CheckNumpad", args => {
        const key = Number(args.key || 0);
        const mode = String(args.mode || "triggered");
        const switchId = Number(args.switchId || 0);

        let value = false;

        switch (mode) {
            case "pressed":
                value = Input.isNumpadPressed(key);
                break;
            case "longPressed":
                value = Input.isNumpadLongPressed(key);
                break;
            case "repeated":
                value = Input.isNumpadRepeated(key);
                break;
            case "released":
                value = Input.isNumpadReleased(key);
                break;
            case "triggered":
            default:
                value = Input.isNumpadTriggered(key);
                break;
        }

        if (switchId > 0) {
            $gameSwitches.setValue(switchId, value);
        }
    });

    PluginManager.registerCommand(pluginName, "StoreTriggeredNumpad", args => {
        const variableId = Number(args.variableId || 0);
        const noInputValue = Number(args.noInputValue ?? -1);
        const value = Input.getTriggeredNumpad();

        if (variableId > 0) {
            $gameVariables.setValue(variableId, value >= 0 ? value : noInputValue);
        }
    });
})();