/*:
 * @target MZ
 * @plugindesc メモ欄タグ付きイベントに接した時、イベントID・イベント名を変数に入れてコモンイベントを起動
 * @author OpenAI
 *
 * @param CommonEventId
 * @text 判定用コモンイベントID
 * @type common_event
 * @default 10
 *
 * @param EventIdVariable
 * @text 接触イベントID保存変数
 * @type variable
 * @default 20
 *
 * @param EventNameVariable
 * @text 接触イベント名保存変数
 * @type variable
 * @default 21
 *
 * @param TagName
 * @text メモ欄タグ名
 * @type string
 * @default TouchJudge
 *
 * @help
 * イベントのメモ欄に
 *   <TouchJudge>
 * と書かれたイベントにプレイヤーが正面から接した時、
 * 指定コモンイベントを起動します。
 *
 * その時、
 * - 接触したイベントID
 * - 接触したイベント名
 * を指定変数に保存します。
 *
 * 例:
 * イベント名: 店_道具屋
 * メモ欄   : <TouchJudge>
 *
 * コモンイベント側でイベント名を見て処理を分岐できます。
 *
 * 注意:
 * - 判定は「プレイヤーの正面1マスにあるイベント」です
 * - 同じイベントに接し続けている間は連続起動しません
 * - 離れて再度接すると、もう一度起動します
 */

(() => {
    "use strict";

    const pluginName = "TouchJudgeByName";
    const params = PluginManager.parameters(pluginName);

    const COMMON_EVENT_ID = Number(params.CommonEventId || 10);
    const EVENT_ID_VARIABLE = Number(params.EventIdVariable || 20);
    const EVENT_NAME_VARIABLE = Number(params.EventNameVariable || 21);
    const TAG_NAME = String(params.TagName || "TouchJudge");

    let lastMapId = 0;
    let lastEventId = 0;

    function clearLastTouch() {
        lastMapId = 0;
        lastEventId = 0;
    }

    function getFrontEvent() {
        const x = $gameMap.roundXWithDirection($gamePlayer.x, $gamePlayer.direction());
        const y = $gameMap.roundYWithDirection($gamePlayer.y, $gamePlayer.direction());
        const events = $gameMap.eventsXy(x, y);
        return events.length > 0 ? events[0] : null;
    }

    function hasJudgeTag(event) {
        const dataEvent = event.event();
        if (!dataEvent || !dataEvent.meta) return false;
        return Object.prototype.hasOwnProperty.call(dataEvent.meta, TAG_NAME);
    }

    function reserveJudgeCommon(event) {
        const dataEvent = event.event();
        if (!dataEvent) return;

        const eventId = event.eventId();
        const eventName = dataEvent.name || "";

        $gameVariables.setValue(EVENT_ID_VARIABLE, eventId);
        $gameVariables.setValue(EVENT_NAME_VARIABLE, eventName);
        $gameTemp.reserveCommonEvent(COMMON_EVENT_ID);
    }

    function updateTouchJudge() {
        const event = getFrontEvent();

        if (!event) {
            clearLastTouch();
            return;
        }

        const mapId = $gameMap.mapId();
        const eventId = event.eventId();

        if (lastMapId === mapId && lastEventId === eventId) {
            return;
        }

        if (!hasJudgeTag(event)) {
            clearLastTouch();
            return;
        }

        lastMapId = mapId;
        lastEventId = eventId;
        reserveJudgeCommon(event);
    }

    const _Scene_Map_update = Scene_Map.prototype.update;
    Scene_Map.prototype.update = function() {
        _Scene_Map_update.call(this);
        if ($gameMap.isEventRunning()) return;
        if (!$gamePlayer.canMove()) return;
        updateTouchJudge();
    };

    const _Game_Player_performTransfer = Game_Player.prototype.performTransfer;
    Game_Player.prototype.performTransfer = function() {
        clearLastTouch();
        _Game_Player_performTransfer.call(this);
    };
})();