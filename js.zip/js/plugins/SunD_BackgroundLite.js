/*:
 * @target MZ
 * @plugindesc v0.1.7 Lightweight PNG / static / live / VRM-scene 3D background plugin for SunD tools.
 * @author DB / ChatGPT
 * @url
 *
 * @help
 * SunD_BackgroundLite.js
 *
 * ■目的
 * PNG背景、またはGLB/GLTF等の3Dモデル背景を、可能な限り軽量に表示するための
 * RPGツクールMZ向けプラグインです。
 *
 * 3D背景は軽量優先の場合、一度だけレンダリングして2D画像化し、
 * 以後は通常のSpriteとして表示します。
 * v0.1.4から、2D化せずに3Dレンダラーを保持する「常駐表示」も追加しました。
 * v0.1.5から、SunD_VRMと同じ3DシーンへGLB/GLTFを追加する「VRM空間3D背景」も追加しました。
 * v0.1.6から、VRM空間3D背景の明るさ補正・ライト無視表示を追加しました。
 * v0.1.7から、SunD_VRM_Config.json の backgrounds を読み込み、背景キーだけで表示できるようにしました。
 * そのため、VRMモデルのような毎フレーム更新・当たり判定・ボーン更新・表情更新・
 * レイキャスト等は行いません。
 *
 * ■PNG背景
 * - img/pictures など任意フォルダのPNGを背景として表示できます。
 * - 表示サイズ、フィット方式、透明度、表示レイヤーを指定できます。
 *
 * ■3D背景
 * - THREE.js と GLTFLoader がすでに読み込まれている環境でのみ使用できます。
 * - GLB/GLTFを一度だけレンダリングし、Bitmapへ転写して表示します。
 * - 転写後、既定では3D側のメモリを解放します。
 * - 「3D背景を常駐表示」を使うと、2D化せず3Dレンダラーを保持します。
 * - 「VRM空間3D背景を表示」を使うと、SunD_VRMのscene/camera/rendererを共有し、VRMと同じ座標空間に表示します。
 * - アニメーション、コリジョン、マウス判定はありません。
 *
 * ■想定運用
 * - 重いVRM/3Dシーンとは分離し、背景表示だけに特化させる。
 * - SunD_VRM_Command_Tool 側では、将来的に本プラグインのプラグインコマンドを
 *   出力・プレビュー対象にする。
 *
 * ■注意
 * - 3D背景は「静止背景」が前提です。カメラを動かす場合は RefreshModelBackground で
 *   再レンダリングしてください。
 * - 3D表示に必要な THREE / GLTFLoader は、このプラグインには同梱していません。
 *   既存のSunD系プラグインなどで読み込まれている場合に利用できます。
 *
 * @param DebugLog
 * @text デバッグログ
 * @type boolean
 * @default true
 *
 * @param WarnOnLargeImage
 * @text 大きいPNG警告
 * @type boolean
 * @default true
 *
 * @param MaxPngPixels
 * @text PNG警告ピクセル数
 * @desc PNGの幅×高さがこの値を超えたら警告します。0で無効。
 * @type number
 * @default 8388608
 * @min 0
 *
 * @param DefaultLayer
 * @text 既定レイヤー
 * @type select
 * @option back
 * @option underWindow
 * @option front
 * @default underWindow
 *
 * @param MaxCaptureWidth
 * @text 3D最大レンダー幅
 * @desc 3D背景を2D化するときの最大内部レンダー幅。
 * @type number
 * @default 1280
 * @min 64
 *
 * @param MaxCaptureHeight
 * @text 3D最大レンダー高さ
 * @desc 3D背景を2D化するときの最大内部レンダー高さ。
 * @type number
 * @default 720
 * @min 64
 *
 * @param MaxRendererPixelRatio
 * @text 3D最大PixelRatio
 * @desc 3D背景レンダリング時のpixelRatio上限。軽量優先なら1推奨。
 * @type number
 * @decimals 2
 * @default 1
 * @min 0.25
 *
 * @param Dispose3DAfterCapture
 * @text 3D転写後に解放
 * @desc trueの場合、3D背景をBitmap化した後にrenderer/geometry/material/textureを解放します。
 * @type boolean
 * @default true
 *
 * @param externalConfigFile
 * @type string
 * @text 外部設定JSON
 * @desc backgrounds を外部JSONから読み込みます。SunD_VRM.js と同じJSONを指定してください。
 * @default js/plugins/SunD_VRM_Config/SunD_VRM_Config.json
 *
 * @command ShowPngBackground
 * @text PNG背景を表示
 * @desc PNG画像を軽量な2D Sprite背景として表示します。
 *
 * @arg id
 * @text 背景ID
 * @type string
 * @default bg1
 *
 * @arg folder
 * @text 画像フォルダ
 * @desc 例: img/pictures/  または img/backgrounds/ など。末尾スラッシュ推奨。
 * @type string
 * @default img/pictures/
 *
 * @arg filename
 * @text ファイル名
 * @desc 例: ForestBg または ForestBg.png。拡張子ありでも可。
 * @type string
 * @default
 *
 * @arg layer
 * @text レイヤー
 * @type select
 * @option back
 * @option underWindow
 * @option front
 * @default underWindow
 *
 * @arg x
 * @text X
 * @type number
 * @min -99999
 * @default 0
 *
 * @arg y
 * @text Y
 * @type number
 * @min -99999
 * @default 0
 *
 * @arg width
 * @text 表示幅
 * @desc 0なら画面幅。
 * @type number
 * @default 0
 * @min 0
 *
 * @arg height
 * @text 表示高さ
 * @desc 0なら画面高さ。
 * @type number
 * @default 0
 * @min 0
 *
 * @arg fitMode
 * @text フィット方式
 * @type select
 * @option none
 * @option stretch
 * @option contain
 * @option cover
 * @default cover
 *
 * @arg opacity
 * @text 透明度
 * @type number
 * @min 0
 * @max 255
 * @default 255
 *
 * @arg blendMode
 * @text ブレンドモード
 * @type select
 * @option 通常
 * @value 0
 * @option 加算
 * @value 1
 * @option 乗算
 * @value 2
 * @option スクリーン
 * @value 3
 * @default 0
 *
 * @arg visible
 * @text 表示ON
 * @type boolean
 * @default true
 *
 * @command ShowModelBackground
 * @text 3D背景を表示/2D化
 * @desc GLB/GLTFを一度レンダリングして2D背景化します。THREE/GLTFLoaderが必要です。
 *
 * @arg id
 * @text 背景ID
 * @type string
 * @default modelBg1
 *
 * @arg modelPath
 * @text 3Dモデルパス
 * @desc 例: models/background/room.glb または img/3d/room.glb
 * @type string
 * @default
 *
 * @arg layer
 * @text レイヤー
 * @type select
 * @option back
 * @option underWindow
 * @option front
 * @default underWindow
 *
 * @arg x
 * @text X
 * @type number
 * @min -99999
 * @default 0
 *
 * @arg y
 * @text Y
 * @type number
 * @min -99999
 * @default 0
 *
 * @arg width
 * @text 表示幅
 * @desc 0なら画面幅。
 * @type number
 * @default 0
 * @min 0
 *
 * @arg height
 * @text 表示高さ
 * @desc 0なら画面高さ。
 * @type number
 * @default 0
 * @min 0
 *
 * @arg opacity
 * @text 透明度
 * @type number
 * @min 0
 * @max 255
 * @default 255
 *
 * @arg backgroundColor
 * @text 背景色
 * @desc 例: #000000。空欄なら透明。
 * @type string
 * @default
 *
 * @arg backgroundAlpha
 * @text 背景色透明度
 * @type number
 * @decimals 2
 * @min 0
 * @max 1
 * @default 0
 *
 * @arg autoFit
 * @text 自動フィット
 * @type boolean
 * @default true
 *
 * @arg modelScale
 * @text モデル倍率
 * @type number
 * @decimals 3
 * @default 1
 *
 * @arg rotationX
 * @text 回転X
 * @desc 度数法。
 * @type number
 * @decimals 2
 * @min -360
 * @max 360
 * @default 0
 *
 * @arg rotationY
 * @text 回転Y
 * @desc 度数法。
 * @type number
 * @decimals 2
 * @min -360
 * @max 360
 * @default 0
 *
 * @arg rotationZ
 * @text 回転Z
 * @desc 度数法。
 * @type number
 * @decimals 2
 * @min -360
 * @max 360
 * @default 0
 *
 * @arg cameraFov
 * @text カメラFOV
 * @type number
 * @decimals 2
 * @min 1
 * @max 179
 * @default 45
 *
 * @arg cameraX
 * @text カメラX
 * @type number
 * @decimals 3
 * @min -99999
 * @default 0
 *
 * @arg cameraY
 * @text カメラY
 * @type number
 * @decimals 3
 * @min -99999
 * @default 1.2
 *
 * @arg cameraZ
 * @text カメラZ
 * @type number
 * @decimals 3
 * @min -99999
 * @default 4
 *
 * @arg targetX
 * @text 注視点X
 * @type number
 * @decimals 3
 * @min -99999
 * @default 0
 *
 * @arg targetY
 * @text 注視点Y
 * @type number
 * @decimals 3
 * @min -99999
 * @default 1
 *
 * @arg targetZ
 * @text 注視点Z
 * @type number
 * @decimals 3
 * @min -99999
 * @default 0
 *
 * @arg ambientIntensity
 * @text 環境光強度
 * @type number
 * @decimals 2
 * @min 0
 * @default 1.0
 *
 * @arg directionalIntensity
 * @text 平行光強度
 * @type number
 * @decimals 2
 * @min 0
 * @default 0.8
 *
 * @arg renderWidth
 * @text 内部レンダー幅
 * @desc 0なら表示幅。最大値はプラグインパラメータで制限されます。
 * @type number
 * @default 0
 * @min 0
 *
 * @arg renderHeight
 * @text 内部レンダー高さ
 * @desc 0なら表示高さ。最大値はプラグインパラメータで制限されます。
 * @type number
 * @default 0
 * @min 0
 *
 * @arg disposeAfterCapture
 * @text 転写後に3D解放
 * @type boolean
 * @default true
 *
 * @command ShowLiveModelBackground
 * @text 3D背景を常駐表示
 * @desc GLB/GLTFを2D化せず、3Dレンダラーを保持して背景表示します。必要時のみ描画する軽量モードも選べます。
 *
 * @arg id
 * @text 背景ID
 * @type string
 * @default liveModelBg1
 *
 * @arg modelPath
 * @text 3Dモデルパス
 * @desc 例: vrm/stage/BeachStage2.glb
 * @type string
 * @default
 *
 * @arg layer
 * @text レイヤー
 * @type select
 * @option back
 * @option underWindow
 * @option front
 * @default underWindow
 *
 * @arg x
 * @text X
 * @type number
 * @min -99999
 * @default 0
 *
 * @arg y
 * @text Y
 * @type number
 * @min -99999
 * @default 0
 *
 * @arg width
 * @text 表示幅
 * @desc 0なら画面幅。
 * @type number
 * @default 0
 * @min 0
 *
 * @arg height
 * @text 表示高さ
 * @desc 0なら画面高さ。
 * @type number
 * @default 0
 * @min 0
 *
 * @arg opacity
 * @text 透明度
 * @type number
 * @min 0
 * @max 255
 * @default 255
 *
 * @arg backgroundColor
 * @text 背景色
 * @desc 例: #000000。空欄なら透明。
 * @type string
 * @default
 *
 * @arg backgroundAlpha
 * @text 背景色透明度
 * @type number
 * @decimals 2
 * @min 0
 * @max 1
 * @default 0
 *
 * @arg autoFit
 * @text 自動フィット
 * @type boolean
 * @default true
 *
 * @arg modelScale
 * @text モデル倍率
 * @type number
 * @decimals 3
 * @default 1
 *
 * @arg rotationX
 * @text 回転X
 * @desc 度数法。
 * @type number
 * @decimals 2
 * @min -360
 * @max 360
 * @default 0
 *
 * @arg rotationY
 * @text 回転Y
 * @desc 度数法。
 * @type number
 * @decimals 2
 * @min -360
 * @max 360
 * @default 0
 *
 * @arg rotationZ
 * @text 回転Z
 * @desc 度数法。
 * @type number
 * @decimals 2
 * @min -360
 * @max 360
 * @default 0
 *
 * @arg cameraFov
 * @text カメラFOV
 * @type number
 * @decimals 2
 * @min 1
 * @max 179
 * @default 45
 *
 * @arg cameraX
 * @text カメラX
 * @type number
 * @decimals 3
 * @min -99999
 * @default 0
 *
 * @arg cameraY
 * @text カメラY
 * @type number
 * @decimals 3
 * @min -99999
 * @default 1.2
 *
 * @arg cameraZ
 * @text カメラZ
 * @type number
 * @decimals 3
 * @min -99999
 * @default 4
 *
 * @arg targetX
 * @text 注視点X
 * @type number
 * @decimals 3
 * @min -99999
 * @default 0
 *
 * @arg targetY
 * @text 注視点Y
 * @type number
 * @decimals 3
 * @min -99999
 * @default 1
 *
 * @arg targetZ
 * @text 注視点Z
 * @type number
 * @decimals 3
 * @min -99999
 * @default 0
 *
 * @arg ambientIntensity
 * @text 環境光強度
 * @type number
 * @decimals 2
 * @min 0
 * @default 1.0
 *
 * @arg directionalIntensity
 * @text 平行光強度
 * @type number
 * @decimals 2
 * @min 0
 * @default 0.8
 *
 * @arg renderWidth
 * @text 内部レンダー幅
 * @desc 0なら表示幅。最大値はプラグインパラメータで制限されます。
 * @type number
 * @default 0
 * @min 0
 *
 * @arg renderHeight
 * @text 内部レンダー高さ
 * @desc 0なら表示高さ。最大値はプラグインパラメータで制限されます。
 * @type number
 * @default 0
 * @min 0
 *
 * @arg continuousRender
 * @text 毎フレーム描画
 * @desc trueなら毎フレーム3D描画します。重くなりやすいので、通常はfalse推奨です。
 * @type boolean
 * @default false
 *

 * @command ShowVrmSceneModelBackground
 * @text VRM空間3D背景を表示
 * @desc SunD_VRMと同じ3DシーンへGLB/GLTFを追加します。VRMと同じ座標・奥行き判定で表示されます。
 *
 * @arg id
 * @text 背景ID
 * @type string
 * @default vrmSceneBg1
 *
 * @arg modelPath
 * @text 3Dモデルパス
 * @desc 例: vrm/stage/BeachStage2.glb
 * @type string
 * @default
 *
 * @arg x
 * @text 位置X
 * @type number
 * @decimals 3
 * @min -99999
 * @default 0
 *
 * @arg y
 * @text 位置Y
 * @type number
 * @decimals 3
 * @min -99999
 * @default 0
 *
 * @arg z
 * @text 位置Z
 * @type number
 * @decimals 3
 * @min -99999
 * @default 0
 *
 * @arg scale
 * @text 倍率
 * @type number
 * @decimals 3
 * @min 0
 * @default 1
 *
 * @arg rotationX
 * @text 回転X
 * @desc 度数法。
 * @type number
 * @decimals 2
 * @min -360
 * @max 360
 * @default 0
 *
 * @arg rotationY
 * @text 回転Y
 * @desc 度数法。
 * @type number
 * @decimals 2
 * @min -360
 * @max 360
 * @default 0
 *
 * @arg rotationZ
 * @text 回転Z
 * @desc 度数法。
 * @type number
 * @decimals 2
 * @min -360
 * @max 360
 * @default 0
 *
 * @arg visible
 * @text 表示ON
 * @type boolean
 * @default true
 *
 * @arg castShadow
 * @text 影を落とす
 * @type boolean
 * @default false
 *
 * @arg receiveShadow
 * @text 影を受ける
 * @type boolean
 * @default false
 *
 * @arg doubleSide
 * @text 両面表示
 * @desc trueならマテリアルを両面表示にします。床や板ポリゴンが裏から消える場合に使用。
 * @type boolean
 * @default false
 *
 * @arg depthTest
 * @text 奥行き判定
 * @desc true推奨。falseにすると座標に関係なく手前に出やすくなります。
 * @type boolean
 * @default true
 *
 * @arg depthWrite
 * @text 奥行き書き込み
 * @desc true推奨。透明マテリアルが多い背景で問題がある場合のみfalseを試してください。
 * @type boolean
 * @default true
 *
 * @arg renderOrder
 * @text 描画順補正
 * @desc 通常は0。大きいほど後から描画されます。基本は0推奨。
 * @type number
 * @min -9999
 * @max 9999
 * @default 0
 *
 * @arg materialMode
 * @text 明るさ方式
 * @desc VRM空間3D背景の材質表示方式。背景が暗い場合は「ライト無視」が軽くて安定します。
 * @type select
 * @option 通常（Sceneライト依存）
 * @value normal
 * @option 明るさ補正（emissive追加）
 * @value boost
 * @option ライト無視（Unlit）
 * @value unlit
 * @default unlit
 *
 * @arg brightness
 * @text 明るさ補正
 * @desc 1.0=通常。ライト無視/明るさ補正時に使用。暗い場合は1.2〜2.0程度を試してください。
 * @type number
 * @decimals 2
 * @min 0
 * @default 1.0
 *
 * @arg emissiveIntensity
 * @text 発光補正
 * @desc 明るさ方式が「明るさ補正」の時に使用。0=なし。0.3〜1.0程度。
 * @type number
 * @decimals 2
 * @min 0
 * @default 0.5
 *
 * @command SetVrmSceneModelVisual
 * @text VRM空間3D背景の明るさ変更
 * @desc VRM空間3D背景の明るさ方式・補正値を変更します。暗すぎる背景の調整用です。
 *
 * @arg id
 * @text 背景ID
 * @type string
 * @default vrmSceneBg1
 *
 * @arg materialMode
 * @text 明るさ方式
 * @desc 空欄なら変更しません。
 * @type select
 * @option 変更しない
 * @value
 * @option 通常（Sceneライト依存）
 * @value normal
 * @option 明るさ補正（emissive追加）
 * @value boost
 * @option ライト無視（Unlit）
 * @value unlit
 * @default
 *
 * @arg brightness
 * @text 明るさ補正
 * @desc 空欄なら変更しません。1.0=通常。
 * @type string
 * @default
 *
 * @arg emissiveIntensity
 * @text 発光補正
 * @desc 空欄なら変更しません。明るさ方式がboostの時に使用。
 * @type string
 * @default
 *
 * @arg doubleSide
 * @text 両面表示
 * @desc 空欄なら変更しません。
 * @type select
 * @option 変更しない
 * @value
 * @option ON
 * @value true
 * @option OFF
 * @value false
 * @default
 *
 * @arg depthTest
 * @text 奥行き判定
 * @desc 空欄なら変更しません。
 * @type select
 * @option 変更しない
 * @value
 * @option ON
 * @value true
 * @option OFF
 * @value false
 * @default
 *
 * @arg depthWrite
 * @text 奥行き書き込み
 * @desc 空欄なら変更しません。
 * @type select
 * @option 変更しない
 * @value
 * @option ON
 * @value true
 * @option OFF
 * @value false
 * @default
 *
 * @arg renderOrder
 * @text 描画順補正
 * @desc 空欄なら変更しません。
 * @type string
 * @default
 *
 * @command ShowVrmSceneModelBackgroundByKey
 * @text VRM空間3D背景をキーで表示
 * @desc 外部JSONの backgrounds に登録済みの背景キーを使って、VRMと同じ3D空間へ表示します。
 *
 * @arg backgroundKey
 * @text 背景キー
 * @type string
 * @desc 外部JSON backgrounds の keyName です。
 * @default vrmSceneBg1
 *
 * @arg reloadConfig
 * @text JSON再読込
 * @type boolean
 * @desc 実行時に外部JSONを再読込します。テスト中の調整反映にはtrue推奨。
 * @default true
 *
 * @command SetVrmSceneModelTransform
 * @text VRM空間3D背景の座標変更
 * @desc VRM空間3D背景の位置・回転・倍率・表示状態を変更します。
 *
 * @arg id
 * @text 背景ID
 * @type string
 * @default vrmSceneBg1
 *
 * @arg x
 * @text 位置X
 * @desc 空欄なら変更しません。
 * @type string
 * @default
 *
 * @arg y
 * @text 位置Y
 * @desc 空欄なら変更しません。
 * @type string
 * @default
 *
 * @arg z
 * @text 位置Z
 * @desc 空欄なら変更しません。
 * @type string
 * @default
 *
 * @arg scale
 * @text 倍率
 * @desc 空欄なら変更しません。
 * @type string
 * @default
 *
 * @arg rotationX
 * @text 回転X
 * @desc 空欄なら変更しません。度数法。
 * @type string
 * @default
 *
 * @arg rotationY
 * @text 回転Y
 * @desc 空欄なら変更しません。度数法。
 * @type string
 * @default
 *
 * @arg rotationZ
 * @text 回転Z
 * @desc 空欄なら変更しません。度数法。
 * @type string
 * @default
 *
 * @arg visible
 * @text 表示ON/OFF
 * @desc 空欄なら変更しません。
 * @type select
 * @option 変更しない
 * @value
 * @option ON
 * @value true
 * @option OFF
 * @value false
 * @default
 *
 * @command RefreshModelBackground
 * @text 3D背景を再レンダリング
 * @desc 指定IDの3D背景を、現在の設定で再レンダリングします。
 *
 * @arg id
 * @text 背景ID
 * @type string
 * @default modelBg1
 *
 * @command SetBackgroundTransform
 * @text 背景の表示位置変更
 * @desc PNG/3D背景の表示位置・サイズ・透明度などを変更します。
 *
 * @arg id
 * @text 背景ID
 * @type string
 * @default bg1
 *
 * @arg x
 * @text X
 * @desc 空欄なら変更しません。
 * @type string
 * @default
 *
 * @arg y
 * @text Y
 * @desc 空欄なら変更しません。
 * @type string
 * @default
 *
 * @arg width
 * @text 表示幅
 * @desc 空欄なら変更しません。0なら画面幅。
 * @type string
 * @default
 *
 * @arg height
 * @text 表示高さ
 * @desc 空欄なら変更しません。0なら画面高さ。
 * @type string
 * @default
 *
 * @arg opacity
 * @text 透明度
 * @desc 空欄なら変更しません。
 * @type string
 * @default
 *
 * @arg layer
 * @text レイヤー
 * @desc 空欄なら変更しません。
 * @type select
 * @option 変更しない
 * @value
 * @option back
 * @value back
 * @option underWindow
 * @value underWindow
 * @option front
 * @value front
 * @default
 *
 * @arg visible
 * @text 表示ON/OFF
 * @desc 空欄なら変更しません。
 * @type select
 * @option 変更しない
 * @value
 * @option ON
 * @value true
 * @option OFF
 * @value false
 * @default
 *
 * @command HideBackground
 * @text 背景を非表示/削除
 * @desc 指定IDの背景を非表示または削除します。
 *
 * @arg id
 * @text 背景ID
 * @type string
 * @default bg1
 *
 * @arg dispose
 * @text 完全削除
 * @desc trueならSprite/Bitmap参照を破棄して管理対象から削除します。falseなら非表示のみ。
 * @type boolean
 * @default true
 *
 * @command CheckBackgroundStatus
 * @text 背景表示状態をチェック
 * @desc 指定IDの背景が表示可能な状態か確認し、結果や原因を変数/コンソールへ出力します。
 *
 * @arg id
 * @text 背景ID
 * @type string
 * @default bg1
 *
 * @arg visibleVariableId
 * @text 表示結果変数
 * @desc 1=表示できている可能性が高い / 0=表示されていない、または表示不能。0なら代入しません。
 * @type variable
 * @default 0
 *
 * @arg codeVariableId
 * @text 状態コード変数
 * @desc 状態コードを代入します。0なら代入しません。
 * @type variable
 * @default 0
 *
 * @arg reasonVariableId
 * @text 原因テキスト変数
 * @desc 原因の短い文字列を代入します。0なら代入しません。
 * @type variable
 * @default 0
 *
 * @arg detailVariableId
 * @text 詳細テキスト変数
 * @desc 追加情報をJSON文字列で代入します。0なら代入しません。
 * @type variable
 * @default 0
 *
 * @arg dumpConsole
 * @text コンソール出力
 * @type boolean
 * @default true
 *
 * @command DumpBackgroundStatus
 * @text 背景状態をコンソール出力
 * @desc 全背景、または指定IDの状態をコンソールに詳しく出力します。
 *
 * @arg id
 * @text 背景ID
 * @desc 空欄なら全背景。
 * @type string
 * @default
 *
 * @command Check3DEnvironment
 * @text 3D背景環境をチェック
 * @desc THREE.js / GLTFLoader が3D背景で使える状態か確認し、結果や原因を変数/コンソールへ出力します。
 *
 * @arg readyVariableId
 * @text 使用可否変数
 * @desc 1=3D背景使用可能 / 0=不可。0なら代入しません。
 * @type variable
 * @default 0
 *
 * @arg codeVariableId
 * @text 状態コード変数
 * @desc 状態コードを代入します。0なら代入しません。
 * @type variable
 * @default 0
 *
 * @arg reasonVariableId
 * @text 原因テキスト変数
 * @desc 原因の短い文字列を代入します。0なら代入しません。
 * @type variable
 * @default 0
 *
 * @arg detailVariableId
 * @text 詳細テキスト変数
 * @desc THREE/GLTFLoader検出状況をJSON文字列で代入します。0なら代入しません。
 * @type variable
 * @default 0
 *
 * @arg dumpConsole
 * @text コンソール出力
 * @type boolean
 * @default true
 *
 * @command ClearBackgrounds
 * @text 背景を全削除
 * @desc このプラグインで表示した背景をすべて削除します。
 */
(() => {
    'use strict';

    const pluginName = 'SunD_BackgroundLite';
    const params = PluginManager.parameters(pluginName);

    const P = {
        debugLog: params.DebugLog === 'true',
        warnOnLargeImage: params.WarnOnLargeImage === 'true',
        maxPngPixels: Number(params.MaxPngPixels || 8388608),
        defaultLayer: String(params.DefaultLayer || 'underWindow'),
        maxCaptureWidth: Math.max(64, Number(params.MaxCaptureWidth || 1280)),
        maxCaptureHeight: Math.max(64, Number(params.MaxCaptureHeight || 720)),
        maxRendererPixelRatio: Math.max(0.25, Number(params.MaxRendererPixelRatio || 1)),
        dispose3DAfterCapture: params.Dispose3DAfterCapture !== 'false',
        externalConfigFile: String(params.externalConfigFile || 'js/plugins/SunD_VRM_Config/SunD_VRM_Config.json')
    };

    const clamp = (v, min, max) => Math.max(min, Math.min(max, v));
    const toNumber = (v, def = 0) => {
        if (v === undefined || v === null || v === '') return def;
        const n = Number(v);
        return Number.isFinite(n) ? n : def;
    };
    const toBool = (v, def = false) => {
        if (v === undefined || v === null || v === '') return def;
        if (typeof v === 'boolean') return v;
        return String(v).toLowerCase() === 'true';
    };
    const log = (...args) => {
        if (P.debugLog) console.log('[SunD_BackgroundLite]', ...args);
    };
    const warn = (...args) => console.warn('[SunD_BackgroundLite]', ...args);
    const rad = deg => toNumber(deg, 0) * Math.PI / 180;

    function screenWidth() {
        return Graphics.boxWidth || Graphics.width || 816;
    }

    function screenHeight() {
        return Graphics.boxHeight || Graphics.height || 624;
    }

    function normalizeLayer(layer) {
        if (layer === 'back' || layer === 'underWindow' || layer === 'front') return layer;
        return P.defaultLayer;
    }

    function normalizePath(path) {
        return String(path || '').replace(/\\/g, '/').replace(/^\.\//, '');
    }

    function normalizeExternalConfigPath(fileName) {
        return normalizePath(fileName).replace(/^\/+/, '');
    }

    function loadExternalConfigFile(fileName) {
        const url = normalizeExternalConfigPath(fileName);
        if (!url) return null;
        try {
            const xhr = new XMLHttpRequest();
            xhr.open('GET', url, false);
            if (xhr.overrideMimeType) xhr.overrideMimeType('application/json');
            xhr.send();
            const okStatus = xhr.status === 0 || (xhr.status >= 200 && xhr.status < 400);
            if (!okStatus || !xhr.responseText) {
                warn('外部設定JSONを読み込めませんでした。', url);
                return null;
            }
            return JSON.parse(xhr.responseText);
        } catch (error) {
            warn('外部設定JSONの読み込み/解析に失敗しました。', url, error);
            return null;
        }
    }

    function configRoot(config) {
        return (config && (config.SunD_BackgroundLite || config.sundBackgroundLite || config.sund_background_lite || config.SunD_VRM || config.sundVrm || config.sund_vrm)) || config;
    }

    function configArray(config, names) {
        for (const name of names) {
            const value = config ? config[name] : null;
            if (value === undefined || value === null) continue;
            if (Array.isArray(value)) return value;
            if (typeof value === 'object') {
                return Object.keys(value).map((key) => {
                    const item = value[key];
                    if (item !== null && typeof item === 'object' && !Array.isArray(item)) return Object.assign({ keyName: key }, item);
                    return { keyName: key, value: item };
                });
            }
        }
        return [];
    }

    function configKey(item) {
        return String(item && (item.keyName || item.key || item.id || item.name) || '').trim();
    }

    function normalizeBackgroundConfigItem(item) {
        const key = configKey(item);
        if (!key) return null;
        const modelPath = item.modelPath || item.fileName || item.file || item.path || item.value || '';
        if (!modelPath) return null;
        return {
            id: item.id || key,
            keyName: key,
            modelPath,
            x: item.x ?? 0,
            y: item.y ?? 0,
            z: item.z ?? 0,
            scale: item.scale ?? 1,
            rotationX: item.rotationX ?? 0,
            rotationY: item.rotationY ?? 0,
            rotationZ: item.rotationZ ?? 0,
            visible: item.visible !== undefined ? item.visible : true,
            materialMode: item.materialMode || 'unlit',
            brightness: item.brightness ?? 1,
            emissiveIntensity: item.emissiveIntensity ?? 0.5,
            doubleSide: item.doubleSide !== undefined ? item.doubleSide : false,
            depthTest: item.depthTest !== undefined ? item.depthTest : true,
            depthWrite: item.depthWrite !== undefined ? item.depthWrite : true,
            renderOrder: item.renderOrder ?? 0
        };
    }

    function normalizeMaterialMode(mode) {
        const m = String(mode || 'unlit').toLowerCase();
        if (m === 'normal' || m === 'boost' || m === 'unlit') return m;
        return 'unlit';
    }

    function loadBitmapFromArgs(folder, filename) {
        const f = String(folder || 'img/pictures/');
        const name = String(filename || '').trim();
        if (!name) return null;
        const hasExt = /\.(png|jpg|jpeg|webp)$/i.test(name);
        const hasSlash = name.includes('/') || name.includes('\\');
        if (hasSlash) {
            return Bitmap.load(normalizePath(name));
        }
        if (hasExt) {
            const base = f.endsWith('/') ? f : `${f}/`;
            return Bitmap.load(normalizePath(base + name));
        }
        const folderPath = f.endsWith('/') ? f : `${f}/`;
        return ImageManager.loadBitmap(folderPath, name);
    }

    function destroySprite(sprite) {
        if (!sprite) return;
        if (sprite.parent) sprite.parent.removeChild(sprite);
        if (sprite.destroy) {
            try { sprite.destroy({ children: true }); } catch (_) { sprite.destroy(); }
        }
    }

    function disposeThreeObject(root) {
        if (!root || !root.traverse) return;
        root.traverse(obj => {
            if (obj.geometry && obj.geometry.dispose) obj.geometry.dispose();
            const mat = obj.material;
            const disposeMaterial = material => {
                if (!material) return;
                Object.keys(material).forEach(key => {
                    const value = material[key];
                    if (value && value.isTexture && value.dispose) value.dispose();
                });
                if (material.dispose) material.dispose();
            };
            if (Array.isArray(mat)) mat.forEach(disposeMaterial);
            else disposeMaterial(mat);
        });
    }

    function disposeLiveResources(entry) {
        if (!entry || !entry.live) return;
        const live = entry.live;
        try {
            if (live.model) disposeThreeObject(live.model);
        } catch (e) {
            warn('常駐3D背景のモデル解放中にエラーが発生しました。', entry.id, e);
        }
        try {
            if (live.renderer && live.renderer.dispose) live.renderer.dispose();
            if (live.renderer && live.renderer.forceContextLoss) live.renderer.forceContextLoss();
            if (live.renderer && live.renderer.domElement && live.renderer.domElement.remove) {
                live.renderer.domElement.remove();
            }
        } catch (e) {
            warn('常駐3D背景のrenderer解放中にエラーが発生しました。', entry.id, e);
        }
        if (live.texture && live.texture.destroy) {
            try { live.texture.destroy(true); } catch (_) { try { live.texture.destroy(); } catch (__) {} }
        }
        entry.live = null;
    }


    function disposeVrmSceneResources(entry) {
        if (!entry || !entry.vrmScene) return;
        const vrmScene = entry.vrmScene;
        try {
            if (vrmScene.model && vrmScene.model.parent) {
                vrmScene.model.parent.remove(vrmScene.model);
            }
            if (vrmScene.model) disposeThreeObject(vrmScene.model);
        } catch (e) {
            warn('VRM空間3D背景の解放中にエラーが発生しました。', entry.id, e);
        }
        entry.vrmScene = null;
    }

    function makePixiTextureFromCanvas(canvas) {
        if (window.PIXI) {
            if (PIXI.Texture && PIXI.Texture.from) {
                try { return PIXI.Texture.from(canvas); } catch (_) {}
            }
            if (PIXI.Texture && PIXI.Texture.fromCanvas) {
                try { return PIXI.Texture.fromCanvas(canvas); } catch (_) {}
            }
            if (PIXI.BaseTexture && PIXI.Texture) {
                try {
                    const base = PIXI.BaseTexture.fromCanvas ? PIXI.BaseTexture.fromCanvas(canvas) : PIXI.BaseTexture.from(canvas);
                    return new PIXI.Texture(base);
                } catch (_) {}
            }
        }
        throw new Error('PIXI textureをWebGL canvasから作成できませんでした。');
    }

    const Manager = {
        _entries: new Map(),
        _backgroundConfigMap: new Map(),
        _externalConfigLoaded: false,

        reloadExternalConfig() {
            this._backgroundConfigMap.clear();
            const config = loadExternalConfigFile(P.externalConfigFile);
            // Command Toolの標準JSONはトップレベルに backgrounds を持つ。
            // ただし将来的な入れ子形式にも対応する。
            const root = config && (config.backgrounds || config.backgroundList || config.vrmSceneBackgrounds) ? config : configRoot(config);
            const list = configArray(root, ['backgrounds', 'backgroundList', 'vrmSceneBackgrounds']);
            list.forEach((raw) => {
                const item = normalizeBackgroundConfigItem(raw);
                if (!item) return;
                this._backgroundConfigMap.set(item.keyName, item);
            });
            this._externalConfigLoaded = true;
            log('外部JSON背景登録', this._backgroundConfigMap.size);
            return this._backgroundConfigMap;
        },

        ensureExternalConfigLoaded() {
            if (!this._externalConfigLoaded) this.reloadExternalConfig();
            return this._backgroundConfigMap;
        },

        backgroundConfigByKey(keyName, reload) {
            if (toBool(reload, true)) this.reloadExternalConfig();
            else this.ensureExternalConfigLoaded();
            return this._backgroundConfigMap.get(String(keyName || '').trim()) || null;
        },

        showVrmSceneModelByKey(args) {
            const key = String(args.backgroundKey || args.keyName || args.id || '').trim();
            if (!key) {
                warn('ShowVrmSceneModelBackgroundByKey: backgroundKey が空です。');
                return;
            }
            const item = this.backgroundConfigByKey(key, args.reloadConfig);
            if (!item) {
                warn('ShowVrmSceneModelBackgroundByKey: 外部JSONに背景キーが登録されていません。', key);
                return;
            }
            this.showVrmSceneModel(Object.assign({}, item, { id: item.id || key, keyName: key }));
        },

        showPng(args) {
            const id = String(args.id || 'bg1');
            if (!args.filename) {
                warn('PNG背景のfilenameが空です。', id);
                return;
            }
            this.disposeEntry(id, true);

            const entry = {
                type: 'png',
                id,
                layer: normalizeLayer(args.layer),
                x: toNumber(args.x, 0),
                y: toNumber(args.y, 0),
                width: toNumber(args.width, 0),
                height: toNumber(args.height, 0),
                fitMode: String(args.fitMode || 'cover'),
                opacity: clamp(toNumber(args.opacity, 255), 0, 255),
                blendMode: toNumber(args.blendMode, 0),
                visible: toBool(args.visible, true),
                sprite: new Sprite(),
                bitmap: loadBitmapFromArgs(args.folder, args.filename),
                warnedLarge: false,
                needsLayout: true
            };
            if (!entry.bitmap) {
                warn('PNG背景を読み込めませんでした。', id, args.folder, args.filename);
                return;
            }
            entry.sprite.bitmap = entry.bitmap;
            entry.sprite.blendMode = entry.blendMode;
            this._entries.set(id, entry);
            log('ShowPngBackground', entry);
        },

        showModel(args) {
            const id = String(args.id || 'modelBg1');
            if (!args.modelPath) {
                warn('3D背景のmodelPathが空です。', id);
                return;
            }
            this.disposeEntry(id, true);

            const w = toNumber(args.width, 0) || screenWidth();
            const h = toNumber(args.height, 0) || screenHeight();
            const bitmap = new Bitmap(Math.max(1, w), Math.max(1, h));
            const sprite = new Sprite(bitmap);

            const entry = {
                type: 'model',
                id,
                layer: normalizeLayer(args.layer),
                modelPath: normalizePath(args.modelPath),
                x: toNumber(args.x, 0),
                y: toNumber(args.y, 0),
                width: toNumber(args.width, 0),
                height: toNumber(args.height, 0),
                opacity: clamp(toNumber(args.opacity, 255), 0, 255),
                visible: true,
                sprite,
                bitmap,
                modelArgs: Object.assign({}, args),
                loading: false,
                loaded: false,
                error: null,
                needsLayout: true
            };
            this._entries.set(id, entry);
            this.captureModel(entry);
            log('ShowModelBackground', entry.modelPath);
        },

        showLiveModel(args) {
            const id = String(args.id || 'liveModelBg1');
            if (!args.modelPath) {
                warn('常駐3D背景のmodelPathが空です。', id);
                return;
            }
            this.disposeEntry(id, true);

            const displayW = toNumber(args.width, 0) || screenWidth();
            const displayH = toNumber(args.height, 0) || screenHeight();
            const entry = {
                type: 'liveModel',
                id,
                layer: normalizeLayer(args.layer),
                modelPath: normalizePath(args.modelPath),
                x: toNumber(args.x, 0),
                y: toNumber(args.y, 0),
                width: toNumber(args.width, 0),
                height: toNumber(args.height, 0),
                opacity: clamp(toNumber(args.opacity, 255), 0, 255),
                visible: true,
                sprite: null,
                bitmap: null,
                modelArgs: Object.assign({}, args),
                continuousRender: toBool(args.continuousRender, false),
                needsRender: true,
                loading: false,
                loaded: false,
                error: null,
                needsLayout: true,
                live: null
            };
            entry.modelArgs.width = displayW;
            entry.modelArgs.height = displayH;
            this._entries.set(id, entry);
            this.loadLiveModel(entry);
            log('ShowLiveModelBackground', entry.modelPath);
        },


        showVrmSceneModel(args) {
            const id = String(args.id || 'vrmSceneBg1');
            if (!args.modelPath) {
                warn('VRM空間3D背景のmodelPathが空です。', id);
                return;
            }
            this.disposeEntry(id, true);
            const entry = {
                type: 'vrmSceneModel',
                id,
                layer: 'vrmScene',
                modelPath: normalizePath(args.modelPath),
                x: toNumber(args.x, 0),
                y: toNumber(args.y, 0),
                z: toNumber(args.z, 0),
                scale: Math.max(0, toNumber(args.scale, 1)),
                rotationX: toNumber(args.rotationX, 0),
                rotationY: toNumber(args.rotationY, 0),
                rotationZ: toNumber(args.rotationZ, 0),
                materialMode: normalizeMaterialMode(args.materialMode),
                brightness: Math.max(0, toNumber(args.brightness, 1)),
                emissiveIntensity: Math.max(0, toNumber(args.emissiveIntensity, 0.5)),
                opacity: 255,
                visible: toBool(args.visible, true),
                sprite: null,
                bitmap: null,
                modelArgs: Object.assign({}, args),
                loading: false,
                loaded: false,
                error: null,
                vrmScene: null
            };
            this._entries.set(id, entry);
            this.installVrmSceneRenderBridge();
            this.loadVrmSceneModel(entry);
            log('ShowVrmSceneModelBackground', entry.modelPath);
        },

        setVrmSceneTransform(args) {
            const id = String(args.id || '');
            const entry = this._entries.get(id);
            if (!entry || entry.type !== 'vrmSceneModel') {
                warn('SetVrmSceneModelTransform: 指定IDのVRM空間3D背景がありません。', id);
                return;
            }
            if (args.x !== '') entry.x = toNumber(args.x, entry.x);
            if (args.y !== '') entry.y = toNumber(args.y, entry.y);
            if (args.z !== '') entry.z = toNumber(args.z, entry.z);
            if (args.scale !== '') entry.scale = Math.max(0, toNumber(args.scale, entry.scale));
            if (args.rotationX !== '') entry.rotationX = toNumber(args.rotationX, entry.rotationX);
            if (args.rotationY !== '') entry.rotationY = toNumber(args.rotationY, entry.rotationY);
            if (args.rotationZ !== '') entry.rotationZ = toNumber(args.rotationZ, entry.rotationZ);
            if (args.visible !== '') entry.visible = toBool(args.visible, entry.visible);
            this.applyVrmSceneTransform(entry);
        },

        setVrmSceneVisual(args) {
            const id = String(args.id || '');
            const entry = this._entries.get(id);
            if (!entry || entry.type !== 'vrmSceneModel') {
                warn('SetVrmSceneModelVisual: 指定IDのVRM空間3D背景がありません。', id);
                return;
            }
            if (args.materialMode !== '') entry.materialMode = normalizeMaterialMode(args.materialMode);
            if (args.brightness !== '') entry.brightness = Math.max(0, toNumber(args.brightness, entry.brightness));
            if (args.emissiveIntensity !== '') entry.emissiveIntensity = Math.max(0, toNumber(args.emissiveIntensity, entry.emissiveIntensity));
            if (args.doubleSide !== '') entry.modelArgs.doubleSide = args.doubleSide;
            if (args.depthTest !== '') entry.modelArgs.depthTest = args.depthTest;
            if (args.depthWrite !== '') entry.modelArgs.depthWrite = args.depthWrite;
            if (args.renderOrder !== '') entry.modelArgs.renderOrder = args.renderOrder;
            this.applyVrmSceneMaterialSettings(entry);
            log('SetVrmSceneModelVisual', id, { materialMode: entry.materialMode, brightness: entry.brightness, emissiveIntensity: entry.emissiveIntensity });
        },

        getVrmRuntime() {
            const w = typeof window !== 'undefined' ? window : globalThis;
            const api = w && w.SUND_VRM ? w.SUND_VRM : null;
            return {
                api,
                scene: api && api._scene ? api._scene : null,
                camera: api && api._camera ? api._camera : null,
                renderer: api && api._renderer ? api._renderer : null
            };
        },

        installVrmSceneRenderBridge() {
            const w = typeof window !== 'undefined' ? window : globalThis;
            if (!w) return;
            const target = w.SUND_VRM_GLTFStage || {};
            if (!target._sundBgLiteBridgeInstalled) {
                const previousHasVisibleStage = typeof target.hasVisibleStage === 'function'
                    ? target.hasVisibleStage.bind(target)
                    : null;
                target.hasVisibleStage = function() {
                    let prev = false;
                    try { prev = previousHasVisibleStage ? !!previousHasVisibleStage() : false; } catch (_) { prev = false; }
                    return prev || Manager.hasVisibleVrmSceneModels();
                };
                target._sundBgLiteBridgeInstalled = true;
                target._sundBgLiteBridgeNote = 'SunD_BackgroundLite uses this hook to make SUND_VRM render VRM-space background models even when no VRM model is visible.';
            }
            w.SUND_VRM_GLTFStage = target;
        },

        hasVisibleVrmSceneModels() {
            for (const entry of this._entries.values()) {
                if (entry && entry.type === 'vrmSceneModel' && entry.visible && entry.loaded && entry.vrmScene && entry.vrmScene.model) {
                    return true;
                }
            }
            return false;
        },

        async loadVrmSceneModel(entry) {
            if (!entry || entry.loading) return;
            const runtime = this.getVrmRuntime();
            if (!runtime.scene) {
                entry.error = 'SunD_VRMの3Dシーンが見つかりません。SunD_VRM.jsより後に実行するか、VRMシーン初期化後にコマンドを実行してください。';
                warn(entry.error, { hasSundVrm: !!runtime.api, hasScene: !!runtime.scene });
                return;
            }
            const env = this.detect3DEnvironment();
            entry.threeEnv = env.detail;
            if (!env.THREE || !env.LoaderClass) {
                entry.error = env.message;
                warn(entry.error, env.detail, 'VRM空間3D背景は THREE.js と GLTFLoader の両方が必要です。');
                return;
            }
            entry.loading = true;
            entry.loaded = false;
            entry.error = null;
            try {
                await this.loadVrmSceneModelInternal(entry, env.THREE, env.LoaderClass, runtime.scene);
                entry.loaded = true;
                this.applyVrmSceneTransform(entry);
            } catch (e) {
                entry.error = e;
                warn('VRM空間3D背景の読み込みに失敗しました。', entry.id, e);
            } finally {
                entry.loading = false;
            }
        },

        async loadVrmSceneModelInternal(entry, THREE, LoaderClass, vrmScene) {
            const args = entry.modelArgs || {};
            const loader = new LoaderClass();
            const gltf = await this.loadGltf(loader, entry.modelPath);
            const model = gltf.scene || (gltf.scenes && gltf.scenes[0]);
            if (!model) throw new Error('GLTF sceneが見つかりません。');

            const renderOrder = toNumber(args.renderOrder, 0);
            const depthTest = toBool(args.depthTest, true);
            const depthWrite = toBool(args.depthWrite, true);
            const doubleSide = toBool(args.doubleSide, false);
            const castShadow = toBool(args.castShadow, false);
            const receiveShadow = toBool(args.receiveShadow, false);

            model.traverse(obj => {
                if (obj.isMesh || obj.isSkinnedMesh) {
                    obj.castShadow = castShadow;
                    obj.receiveShadow = receiveShadow;
                    obj.renderOrder = renderOrder;
                    const applyMaterial = material => {
                        if (!material) return;
                        if ('depthTest' in material) material.depthTest = depthTest;
                        if ('depthWrite' in material) material.depthWrite = depthWrite;
                        if (doubleSide && THREE.DoubleSide !== undefined && 'side' in material) material.side = THREE.DoubleSide;
                        material.needsUpdate = true;
                    };
                    if (Array.isArray(obj.material)) obj.material.forEach(applyMaterial);
                    else applyMaterial(obj.material);
                }
            });

            vrmScene.add(model);
            entry.vrmScene = { THREE, LoaderClass, scene: vrmScene, model, gltf, originalMaterials: new Set(), generatedMaterials: new Set() };
            this.applyVrmSceneMaterialSettings(entry);
            this.applyVrmSceneTransform(entry);
            log('VRM空間3D背景を読み込みました。', entry.id, entry.modelPath);
        },

        disposeGeneratedVrmSceneMaterials(entry) {
            if (!entry || !entry.vrmScene || !entry.vrmScene.generatedMaterials) return;
            for (const mat of entry.vrmScene.generatedMaterials) {
                try { if (mat && mat.dispose) mat.dispose(); } catch (_) {}
            }
            entry.vrmScene.generatedMaterials.clear();
        },

        rememberOriginalMaterial(obj) {
            if (!obj || !obj.userData) return obj ? obj.material : null;
            if (obj.userData._sundBgLiteOriginalMaterial === undefined) {
                obj.userData._sundBgLiteOriginalMaterial = obj.material;
            }
            return obj.userData._sundBgLiteOriginalMaterial;
        },

        restoreOriginalMaterial(obj) {
            if (!obj || !obj.userData) return;
            if (obj.userData._sundBgLiteOriginalMaterial !== undefined) {
                obj.material = obj.userData._sundBgLiteOriginalMaterial;
            }
        },

        makeUnlitMaterial(original, THREE, brightness, common) {
            if (!original || !THREE || !THREE.MeshBasicMaterial) return original;
            const src = original;
            const color = new THREE.Color(1, 1, 1);
            if (src.color && color.copy) color.copy(src.color);
            if (color.multiplyScalar) color.multiplyScalar(Math.max(0, brightness));
            const params = {
                color,
                map: src.map || null,
                alphaMap: src.alphaMap || null,
                transparent: !!src.transparent || toNumber(src.opacity, 1) < 1,
                opacity: src.opacity !== undefined ? src.opacity : 1,
                alphaTest: src.alphaTest || 0,
                side: common.side !== undefined ? common.side : src.side,
                depthTest: common.depthTest,
                depthWrite: common.depthWrite,
                blending: src.blending,
                fog: false
            };
            const mat = new THREE.MeshBasicMaterial(params);
            if ('toneMapped' in mat) mat.toneMapped = false;
            mat.needsUpdate = true;
            return mat;
        },

        applyVrmSceneMaterialSettings(entry) {
            if (!entry || !entry.vrmScene || !entry.vrmScene.model) return;
            const THREE = entry.vrmScene.THREE;
            const args = entry.modelArgs || {};
            const mode = normalizeMaterialMode(entry.materialMode);
            const brightness = Math.max(0, toNumber(entry.brightness, 1));
            const emissiveIntensity = Math.max(0, toNumber(entry.emissiveIntensity, 0.5));
            const renderOrder = toNumber(args.renderOrder, 0);
            const depthTest = toBool(args.depthTest, true);
            const depthWrite = toBool(args.depthWrite, true);
            const doubleSide = toBool(args.doubleSide, false);
            const castShadow = toBool(args.castShadow, false);
            const receiveShadow = toBool(args.receiveShadow, false);
            const common = {
                depthTest,
                depthWrite,
                side: doubleSide && THREE && THREE.DoubleSide !== undefined ? THREE.DoubleSide : undefined
            };

            this.disposeGeneratedVrmSceneMaterials(entry);

            entry.vrmScene.model.traverse(obj => {
                if (!(obj.isMesh || obj.isSkinnedMesh)) return;
                obj.castShadow = castShadow;
                obj.receiveShadow = receiveShadow;
                obj.renderOrder = renderOrder;

                const original = this.rememberOriginalMaterial(obj);
                const applyCommon = material => {
                    if (!material) return;
                    if ('depthTest' in material) material.depthTest = depthTest;
                    if ('depthWrite' in material) material.depthWrite = depthWrite;
                    if (common.side !== undefined && 'side' in material) material.side = common.side;
                    material.needsUpdate = true;
                };

                if (mode === 'unlit') {
                    const convertOne = mat => {
                        const unlit = this.makeUnlitMaterial(mat, THREE, brightness, common);
                        if (unlit && unlit !== mat) entry.vrmScene.generatedMaterials.add(unlit);
                        return unlit;
                    };
                    obj.material = Array.isArray(original) ? original.map(convertOne) : convertOne(original);
                    if (Array.isArray(obj.material)) obj.material.forEach(applyCommon);
                    else applyCommon(obj.material);
                    return;
                }

                this.restoreOriginalMaterial(obj);
                const mats = Array.isArray(obj.material) ? obj.material : [obj.material];
                mats.forEach(material => {
                    if (!material) return;
                    applyCommon(material);
                    if (mode === 'boost') {
                        if (material.color && material.color.multiplyScalar) {
                            if (!material.userData) material.userData = {};
                            if (!material.userData._sundBgLiteBaseColor && material.color.clone) {
                                material.userData._sundBgLiteBaseColor = material.color.clone();
                            }
                            const base = material.userData._sundBgLiteBaseColor;
                            if (base && material.color.copy) material.color.copy(base).multiplyScalar(brightness);
                        }
                        if (material.emissive && material.emissive.copy) {
                            const baseColor = material.userData && material.userData._sundBgLiteBaseColor ? material.userData._sundBgLiteBaseColor : material.color;
                            if (baseColor) material.emissive.copy(baseColor);
                            if (material.emissive.multiplyScalar) material.emissive.multiplyScalar(emissiveIntensity);
                            if ('emissiveIntensity' in material) material.emissiveIntensity = Math.max(0.001, emissiveIntensity);
                            if (material.map && 'emissiveMap' in material) material.emissiveMap = material.map;
                        }
                        if ('toneMapped' in material) material.toneMapped = false;
                        material.needsUpdate = true;
                    } else {
                        if (material.userData && material.userData._sundBgLiteBaseColor && material.color && material.color.copy) {
                            material.color.copy(material.userData._sundBgLiteBaseColor);
                        }
                        if (material.emissive && material.emissive.setRGB) material.emissive.setRGB(0, 0, 0);
                        if ('emissiveIntensity' in material) material.emissiveIntensity = 1;
                        if ('emissiveMap' in material) material.emissiveMap = null;
                        material.needsUpdate = true;
                    }
                });
            });
        },

        applyVrmSceneTransform(entry) {
            if (!entry || !entry.vrmScene || !entry.vrmScene.model) return;
            const model = entry.vrmScene.model;
            model.position.set(toNumber(entry.x, 0), toNumber(entry.y, 0), toNumber(entry.z, 0));
            model.scale.setScalar(Math.max(0, toNumber(entry.scale, 1)));
            model.rotation.set(rad(entry.rotationX), rad(entry.rotationY), rad(entry.rotationZ));
            model.visible = !!entry.visible;
        },

        refreshModel(id) {
            const entry = this._entries.get(String(id || ''));
            if (!entry || (entry.type !== 'model' && entry.type !== 'liveModel')) {
                warn('RefreshModelBackground: 指定IDの3D背景がありません。', id);
                return;
            }
            if (entry.type === 'liveModel') {
                this.renderLiveModel(entry);
            } else {
                this.captureModel(entry);
            }
        },

        setTransform(args) {
            const id = String(args.id || '');
            const entry = this._entries.get(id);
            if (!entry) {
                warn('SetBackgroundTransform: 指定IDの背景がありません。', id);
                return;
            }
            if (args.x !== '') entry.x = toNumber(args.x, entry.x);
            if (args.y !== '') entry.y = toNumber(args.y, entry.y);
            if (args.width !== '') entry.width = toNumber(args.width, entry.width);
            if (args.height !== '') entry.height = toNumber(args.height, entry.height);
            if (args.opacity !== '') entry.opacity = clamp(toNumber(args.opacity, entry.opacity), 0, 255);
            if (args.layer !== '') entry.layer = normalizeLayer(args.layer);
            if (args.visible !== '') entry.visible = toBool(args.visible, entry.visible);
            entry.needsLayout = true;

            if (entry.type === 'model') {
                const w = entry.width || screenWidth();
                const h = entry.height || screenHeight();
                if (entry.bitmap && (entry.bitmap.width !== w || entry.bitmap.height !== h)) {
                    entry.bitmap.resize(w, h);
                }
            } else if (entry.type === 'liveModel') {
                this.resizeLiveModel(entry);
                entry.needsRender = true;
            }
        },

        hide(id, dispose) {
            const entry = this._entries.get(String(id || ''));
            if (!entry) return;
            if (dispose) this.disposeEntry(entry.id, true);
            else {
                entry.visible = false;
                entry.needsLayout = true;
                if (entry.type === 'vrmSceneModel') this.applyVrmSceneTransform(entry);
            }
        },

        clear() {
            for (const id of Array.from(this._entries.keys())) {
                this.disposeEntry(id, true);
            }
        },

        disposeEntry(id, remove) {
            const entry = this._entries.get(String(id || ''));
            if (!entry) return;
            disposeLiveResources(entry);
            disposeVrmSceneResources(entry);
            destroySprite(entry.sprite);
            entry.sprite = null;
            entry.bitmap = null;
            if (remove) this._entries.delete(String(id));
        },

        ensureSceneRoots(scene) {
            if (!scene) return null;
            if (!scene._sundBgLiteRoots) {
                scene._sundBgLiteRoots = {
                    back: new Sprite(),
                    underWindow: new Sprite(),
                    front: new Sprite()
                };
            }
            this.placeRoot(scene, scene._sundBgLiteRoots.back, 'back');
            this.placeRoot(scene, scene._sundBgLiteRoots.underWindow, 'underWindow');
            this.placeRoot(scene, scene._sundBgLiteRoots.front, 'front');
            return scene._sundBgLiteRoots;
        },

        placeRoot(scene, root, layer) {
            if (!root.parent) scene.addChild(root);
            let index = scene.children.indexOf(root);
            if (layer === 'back') {
                if (index !== 0) scene.setChildIndex(root, 0);
                return;
            }
            if (layer === 'underWindow') {
                let target = scene.children.length - 1;
                const windowIndex = scene._windowLayer ? scene.children.indexOf(scene._windowLayer) : -1;
                const fadeIndex = scene._fadeSprite ? scene.children.indexOf(scene._fadeSprite) : -1;
                const candidates = [windowIndex, fadeIndex].filter(i => i >= 0);
                if (candidates.length > 0) target = Math.max(0, Math.min(...candidates));
                index = scene.children.indexOf(root);
                if (index !== target) {
                    const adjusted = index >= 0 && index < target ? target - 1 : target;
                    scene.setChildIndex(root, clamp(adjusted, 0, scene.children.length - 1));
                }
                return;
            }
            if (layer === 'front') {
                const last = scene.children.length - 1;
                if (index !== last) scene.setChildIndex(root, last);
            }
        },

        updateScene(scene) {
            if (!scene || this._entries.size === 0) return;
            const roots = this.ensureSceneRoots(scene);
            if (!roots) return;
            for (const entry of this._entries.values()) {
                this.updateEntry(entry, roots);
            }
        },

        updateEntry(entry, roots) {
            if (!entry || !entry.sprite) return;
            const root = roots[normalizeLayer(entry.layer)];
            if (entry.sprite.parent !== root) {
                if (entry.sprite.parent) entry.sprite.parent.removeChild(entry.sprite);
                root.addChild(entry.sprite);
                entry.needsLayout = true;
            }
            if (entry.type === 'png' && entry.bitmap && entry.bitmap.isReady()) {
                this.checkLargePng(entry);
            }
            if (entry.type === 'liveModel') {
                this.updateLiveModel(entry);
            }
            this.applyLayout(entry);
        },

        checkLargePng(entry) {
            if (!P.warnOnLargeImage || !P.maxPngPixels || entry.warnedLarge) return;
            const pixels = entry.bitmap.width * entry.bitmap.height;
            if (pixels > P.maxPngPixels) {
                entry.warnedLarge = true;
                warn(`PNG背景が大きいです: ${entry.id} ${entry.bitmap.width}x${entry.bitmap.height} (${pixels} px)`);
            }
        },

        applyLayout(entry) {
            const sprite = entry.sprite;
            const dw = entry.width || screenWidth();
            const dh = entry.height || screenHeight();
            sprite.x = entry.x;
            sprite.y = entry.y;
            sprite.opacity = entry.opacity;
            sprite.visible = !!entry.visible;
            if (entry.type === 'png') {
                const bw = entry.bitmap && entry.bitmap.width ? entry.bitmap.width : dw;
                const bh = entry.bitmap && entry.bitmap.height ? entry.bitmap.height : dh;
                this.applyFit(sprite, bw, bh, dw, dh, entry.fitMode);
            } else if (entry.type === 'model') {
                sprite.scale.x = dw / Math.max(1, entry.bitmap ? entry.bitmap.width : dw);
                sprite.scale.y = dh / Math.max(1, entry.bitmap ? entry.bitmap.height : dh);
            } else if (entry.type === 'liveModel') {
                const rw = entry.live && entry.live.renderWidth ? entry.live.renderWidth : dw;
                const rh = entry.live && entry.live.renderHeight ? entry.live.renderHeight : dh;
                sprite.scale.x = dw / Math.max(1, rw);
                sprite.scale.y = dh / Math.max(1, rh);
            }
        },

        applyFit(sprite, bw, bh, dw, dh, fitMode) {
            fitMode = String(fitMode || 'cover');
            sprite.setFrame(0, 0, bw, bh);
            if (fitMode === 'none') {
                sprite.scale.x = 1;
                sprite.scale.y = 1;
                return;
            }
            const sx = dw / Math.max(1, bw);
            const sy = dh / Math.max(1, bh);
            if (fitMode === 'stretch') {
                sprite.scale.x = sx;
                sprite.scale.y = sy;
            } else if (fitMode === 'contain') {
                const s = Math.min(sx, sy);
                sprite.scale.x = s;
                sprite.scale.y = s;
            } else {
                const s = Math.max(sx, sy);
                sprite.scale.x = s;
                sprite.scale.y = s;
            }
        },

        async captureModel(entry) {
            if (!entry || entry.loading) return;
            const env = this.detect3DEnvironment();
            entry.threeEnv = env.detail;
            if (!env.THREE || !env.LoaderClass) {
                entry.error = env.message;
                warn(entry.error, env.detail, '3D背景は THREE.js と GLTFLoader の両方が必要です。PNG背景はこのまま使用できます。');
                return;
            }
            entry.loading = true;
            entry.loaded = false;
            entry.error = null;
            try {
                await this.captureModelInternal(entry, env.THREE, env.LoaderClass);
                entry.loaded = true;
            } catch (e) {
                entry.error = e;
                warn('3D背景のレンダリングに失敗しました。', entry.id, e);
            } finally {
                entry.loading = false;
            }
        },

        detect3DEnvironment() {
            const g = typeof globalThis !== 'undefined' ? globalThis : window;
            const w = typeof window !== 'undefined' ? window : g;

            const isThreeLike = (value) => {
                return !!(value && (value.WebGLRenderer || value.Scene || value.PerspectiveCamera || value.Box3));
            };
            const isLoaderLike = (value) => {
                if (typeof value !== 'function') return false;
                // GLTFLoader は constructor function で、prototype.load を持つ構成が多い。
                // ビルドによっては prototype が見えにくい場合もあるため function なら候補にする。
                return true;
            };
            const pushUniqueCandidate = (list, name, value) => {
                if (!value) return;
                if (!list.some(item => item[1] === value)) list.push([name, value]);
            };

            const threeCandidates = [];
            pushUniqueCandidate(threeCandidates, 'globalThis.THREE', g && g.THREE);
            pushUniqueCandidate(threeCandidates, 'window.THREE', w && w.THREE);
            pushUniqueCandidate(threeCandidates, 'window.__THREE__', w && w.__THREE__);
            pushUniqueCandidate(threeCandidates, 'globalThis.__THREE__', g && g.__THREE__);
            pushUniqueCandidate(threeCandidates, 'SUND_MODS.THREE', w && w.SUND_MODS && w.SUND_MODS.THREE);
            pushUniqueCandidate(threeCandidates, 'SunD_THREE', w && w.SunD_THREE);
            pushUniqueCandidate(threeCandidates, 'SunD.THREE', w && w.SunD && w.SunD.THREE);
            pushUniqueCandidate(threeCandidates, 'SunD_VRM.THREE', w && w.SunD_VRM && w.SunD_VRM.THREE);
            pushUniqueCandidate(threeCandidates, 'SUND_VRM_GLTFStage.THREE', w && w.SUND_VRM_GLTFStage && w.SUND_VRM_GLTFStage.THREE);
            pushUniqueCandidate(threeCandidates, 'SUND_VRM_GLTFStage.three', w && w.SUND_VRM_GLTFStage && w.SUND_VRM_GLTFStage.three);

            let THREE = null;
            let threeSource = '';
            for (const [name, value] of threeCandidates) {
                if (isThreeLike(value)) {
                    THREE = value;
                    threeSource = name;
                    break;
                }
            }

            const loaderCandidates = [];
            pushUniqueCandidate(loaderCandidates, 'globalThis.GLTFLoader', g && g.GLTFLoader);
            pushUniqueCandidate(loaderCandidates, 'window.GLTFLoader', w && w.GLTFLoader);
            pushUniqueCandidate(loaderCandidates, 'THREE.GLTFLoader', THREE && THREE.GLTFLoader);
            pushUniqueCandidate(loaderCandidates, 'window.__THREE__.GLTFLoader', w && w.__THREE__ && w.__THREE__.GLTFLoader);
            pushUniqueCandidate(loaderCandidates, 'globalThis.__THREE__.GLTFLoader', g && g.__THREE__ && g.__THREE__.GLTFLoader);
            pushUniqueCandidate(loaderCandidates, 'SUND_MODS.GLTFLoader', w && w.SUND_MODS && w.SUND_MODS.GLTFLoader);
            pushUniqueCandidate(loaderCandidates, 'SunD_GLTFLoader', w && w.SunD_GLTFLoader);
            pushUniqueCandidate(loaderCandidates, 'SunD.GLTFLoader', w && w.SunD && w.SunD.GLTFLoader);
            pushUniqueCandidate(loaderCandidates, 'SunD_VRM.GLTFLoader', w && w.SunD_VRM && w.SunD_VRM.GLTFLoader);
            pushUniqueCandidate(loaderCandidates, 'SUND_VRM_GLTFStage.GLTFLoader', w && w.SUND_VRM_GLTFStage && w.SUND_VRM_GLTFStage.GLTFLoader);
            pushUniqueCandidate(loaderCandidates, 'SUND_VRM_GLTFStage.LoaderClass', w && w.SUND_VRM_GLTFStage && w.SUND_VRM_GLTFStage.LoaderClass);
            pushUniqueCandidate(loaderCandidates, 'SUND_VRM_GLTFStage.loaderClass', w && w.SUND_VRM_GLTFStage && w.SUND_VRM_GLTFStage.loaderClass);

            let LoaderClass = null;
            let loaderSource = '';
            for (const [name, value] of loaderCandidates) {
                if (isLoaderLike(value)) {
                    LoaderClass = value;
                    loaderSource = name;
                    break;
                }
            }

            const summarizeCandidates = (list, checker) => list.map(([name, value]) => ({
                name,
                exists: !!value,
                type: typeof value,
                usable: checker(value),
                keys: value && typeof value === 'object' ? Object.keys(value).slice(0, 20) : []
            }));

            const detail = {
                ready: !!(THREE && LoaderClass),
                hasThree: !!THREE,
                hasGltfLoader: !!LoaderClass,
                threeSource,
                loaderSource,
                windowTHREE: !!(w && w.THREE),
                windowUnderscoreTHREE: !!(w && w.__THREE__),
                windowGLTFLoader: !!(w && w.GLTFLoader),
                sundModsExists: !!(w && w.SUND_MODS),
                sundModsHasThree: !!(w && w.SUND_MODS && w.SUND_MODS.THREE),
                sundModsHasGLTFLoader: !!(w && w.SUND_MODS && w.SUND_MODS.GLTFLoader),
                threeHasGLTFLoader: !!(THREE && THREE.GLTFLoader),
                threeCandidates: summarizeCandidates(threeCandidates, isThreeLike),
                loaderCandidates: summarizeCandidates(loaderCandidates, isLoaderLike),
                note: ''
            };

            let code = 1;
            let reason = 'ready';
            let message = '3D背景環境は使用可能です。';
            if (!THREE && !LoaderClass) {
                code = 101;
                reason = 'three_and_gltfloader_missing';
                message = 'THREE.js と GLTFLoader が見つかりません。';
                detail.note = 'SunD_VRM等が内部でTHREEを使っていても、window.THREEとして公開されていない場合、このプラグインからは利用できません。';
            } else if (!THREE) {
                code = 102;
                reason = 'three_missing';
                message = 'THREE.js が見つかりません。';
                detail.note = '3D背景の2D化には THREE.WebGLRenderer / Scene / Camera が必要です。';
            } else if (!LoaderClass) {
                code = 103;
                reason = 'gltfloader_missing';
                message = 'GLTFLoader が見つかりません。';
                detail.note = 'THREE.jsは見えていますが、GLB/GLTFを読み込むためのGLTFLoaderがグローバルに公開されていません。';
            }
            detail.code = code;
            detail.reason = reason;
            detail.message = message;
            return { THREE, LoaderClass, ready: detail.ready, code, reason, message, detail };
        },

        findGltfLoader(THREE) {
            const env = this.detect3DEnvironment();
            return env.LoaderClass || null;
        },

        loadGltf(loader, path) {
            return new Promise((resolve, reject) => {
                loader.load(path, resolve, undefined, reject);
            });
        },

        async captureModelInternal(entry, THREE, LoaderClass) {
            const args = entry.modelArgs || {};
            const displayW = entry.width || screenWidth();
            const displayH = entry.height || screenHeight();
            const renderW = clamp(toNumber(args.renderWidth, displayW) || displayW, 64, P.maxCaptureWidth);
            const renderH = clamp(toNumber(args.renderHeight, displayH) || displayH, 64, P.maxCaptureHeight);

            if (!entry.bitmap || entry.bitmap.width !== displayW || entry.bitmap.height !== displayH) {
                entry.bitmap = new Bitmap(displayW, displayH);
                entry.sprite.bitmap = entry.bitmap;
            }
            entry.bitmap.clear();

            const renderer = new THREE.WebGLRenderer({
                alpha: true,
                antialias: false,
                preserveDrawingBuffer: true,
                powerPreference: 'low-power'
            });
            renderer.setPixelRatio(Math.min(P.maxRendererPixelRatio, window.devicePixelRatio || 1));
            renderer.setSize(renderW, renderH, false);
            renderer.autoClear = true;
            renderer.outputEncoding = THREE.sRGBEncoding || renderer.outputEncoding;

            const scene = new THREE.Scene();
            const bgColor = String(args.backgroundColor || '').trim();
            if (bgColor) {
                scene.background = new THREE.Color(bgColor);
            }

            const ambientIntensity = toNumber(args.ambientIntensity, 1.0);
            const directionalIntensity = toNumber(args.directionalIntensity, 0.8);
            if (ambientIntensity > 0) scene.add(new THREE.AmbientLight(0xffffff, ambientIntensity));
            if (directionalIntensity > 0) {
                const dir = new THREE.DirectionalLight(0xffffff, directionalIntensity);
                dir.position.set(1, 2, 3);
                scene.add(dir);
            }

            const loader = new LoaderClass();
            const gltf = await this.loadGltf(loader, entry.modelPath);
            const model = gltf.scene || (gltf.scenes && gltf.scenes[0]);
            if (!model) throw new Error('GLTF sceneが見つかりません。');

            model.scale.setScalar(toNumber(args.modelScale, 1));
            model.rotation.set(rad(args.rotationX), rad(args.rotationY), rad(args.rotationZ));
            scene.add(model);

            const camera = new THREE.PerspectiveCamera(
                clamp(toNumber(args.cameraFov, 45), 1, 179),
                renderW / Math.max(1, renderH),
                0.01,
                100000
            );

            const target = new THREE.Vector3(
                toNumber(args.targetX, 0),
                toNumber(args.targetY, 1),
                toNumber(args.targetZ, 0)
            );

            const autoFit = toBool(args.autoFit, true);
            if (autoFit) {
                const box = new THREE.Box3().setFromObject(model);
                if (!box.isEmpty()) {
                    const center = new THREE.Vector3();
                    const size = new THREE.Vector3();
                    box.getCenter(center);
                    box.getSize(size);
                    model.position.sub(center);
                    const maxDim = Math.max(size.x, size.y, size.z, 0.001);
                    const fovRad = camera.fov * Math.PI / 180;
                    const distance = (maxDim / 2) / Math.tan(fovRad / 2) * 1.35;
                    camera.position.set(0, maxDim * 0.08, distance);
                    target.set(0, 0, 0);
                } else {
                    camera.position.set(toNumber(args.cameraX, 0), toNumber(args.cameraY, 1.2), toNumber(args.cameraZ, 4));
                }
            } else {
                camera.position.set(toNumber(args.cameraX, 0), toNumber(args.cameraY, 1.2), toNumber(args.cameraZ, 4));
            }
            camera.lookAt(target);
            camera.updateProjectionMatrix();

            const alpha = clamp(toNumber(args.backgroundAlpha, 0), 0, 1);
            renderer.setClearAlpha(alpha);
            renderer.render(scene, camera);

            const ctx = entry.bitmap.context;
            ctx.save();
            ctx.clearRect(0, 0, displayW, displayH);
            ctx.drawImage(renderer.domElement, 0, 0, renderW, renderH, 0, 0, displayW, displayH);
            ctx.restore();
            entry.bitmap.baseTexture.update();

            const shouldDispose = args.disposeAfterCapture === undefined
                ? P.dispose3DAfterCapture
                : toBool(args.disposeAfterCapture, P.dispose3DAfterCapture);
            if (shouldDispose) {
                disposeThreeObject(model);
                if (renderer.dispose) renderer.dispose();
                if (renderer.forceContextLoss) renderer.forceContextLoss();
                if (renderer.domElement && renderer.domElement.remove) renderer.domElement.remove();
            }
            log('3D背景を2D化しました。', entry.id, `${renderW}x${renderH}`, 'display', `${displayW}x${displayH}`);
        },

        async loadLiveModel(entry) {
            if (!entry || entry.loading) return;
            const env = this.detect3DEnvironment();
            entry.threeEnv = env.detail;
            if (!env.THREE || !env.LoaderClass) {
                entry.error = env.message;
                warn(entry.error, env.detail, '常駐3D背景は THREE.js と GLTFLoader の両方が必要です。');
                return;
            }
            entry.loading = true;
            entry.loaded = false;
            entry.error = null;
            try {
                await this.loadLiveModelInternal(entry, env.THREE, env.LoaderClass);
                entry.loaded = true;
                entry.needsRender = true;
                this.renderLiveModel(entry);
            } catch (e) {
                entry.error = e;
                warn('常駐3D背景の読み込みに失敗しました。', entry.id, e);
            } finally {
                entry.loading = false;
            }
        },

        async loadLiveModelInternal(entry, THREE, LoaderClass) {
            const args = entry.modelArgs || {};
            const displayW = entry.width || screenWidth();
            const displayH = entry.height || screenHeight();
            const renderW = clamp(toNumber(args.renderWidth, displayW) || displayW, 64, P.maxCaptureWidth);
            const renderH = clamp(toNumber(args.renderHeight, displayH) || displayH, 64, P.maxCaptureHeight);

            const renderer = new THREE.WebGLRenderer({
                alpha: true,
                antialias: false,
                preserveDrawingBuffer: false,
                powerPreference: 'low-power'
            });
            renderer.setPixelRatio(Math.min(P.maxRendererPixelRatio, window.devicePixelRatio || 1));
            renderer.setSize(renderW, renderH, false);
            renderer.autoClear = true;
            renderer.outputEncoding = THREE.sRGBEncoding || renderer.outputEncoding;

            const scene = new THREE.Scene();
            const bgColor = String(args.backgroundColor || '').trim();
            if (bgColor) scene.background = new THREE.Color(bgColor);

            const ambientIntensity = toNumber(args.ambientIntensity, 1.0);
            const directionalIntensity = toNumber(args.directionalIntensity, 0.8);
            let ambient = null;
            let directional = null;
            if (ambientIntensity > 0) {
                ambient = new THREE.AmbientLight(0xffffff, ambientIntensity);
                scene.add(ambient);
            }
            if (directionalIntensity > 0) {
                directional = new THREE.DirectionalLight(0xffffff, directionalIntensity);
                directional.position.set(1, 2, 3);
                scene.add(directional);
            }

            const loader = new LoaderClass();
            const gltf = await this.loadGltf(loader, entry.modelPath);
            const model = gltf.scene || (gltf.scenes && gltf.scenes[0]);
            if (!model) throw new Error('GLTF sceneが見つかりません。');

            model.scale.setScalar(toNumber(args.modelScale, 1));
            model.rotation.set(rad(args.rotationX), rad(args.rotationY), rad(args.rotationZ));
            scene.add(model);

            const camera = new THREE.PerspectiveCamera(
                clamp(toNumber(args.cameraFov, 45), 1, 179),
                renderW / Math.max(1, renderH),
                0.01,
                100000
            );
            const target = new THREE.Vector3(
                toNumber(args.targetX, 0),
                toNumber(args.targetY, 1),
                toNumber(args.targetZ, 0)
            );

            const autoFit = toBool(args.autoFit, true);
            if (autoFit) {
                const box = new THREE.Box3().setFromObject(model);
                if (!box.isEmpty()) {
                    const center = new THREE.Vector3();
                    const size = new THREE.Vector3();
                    box.getCenter(center);
                    box.getSize(size);
                    model.position.sub(center);
                    const maxDim = Math.max(size.x, size.y, size.z, 0.001);
                    const fovRad = camera.fov * Math.PI / 180;
                    const distance = (maxDim / 2) / Math.tan(fovRad / 2) * 1.35;
                    camera.position.set(0, maxDim * 0.08, distance);
                    target.set(0, 0, 0);
                } else {
                    camera.position.set(toNumber(args.cameraX, 0), toNumber(args.cameraY, 1.2), toNumber(args.cameraZ, 4));
                }
            } else {
                camera.position.set(toNumber(args.cameraX, 0), toNumber(args.cameraY, 1.2), toNumber(args.cameraZ, 4));
            }
            camera.lookAt(target);
            camera.updateProjectionMatrix();

            const alpha = clamp(toNumber(args.backgroundAlpha, 0), 0, 1);
            renderer.setClearAlpha(alpha);

            const texture = makePixiTextureFromCanvas(renderer.domElement);
            const sprite = new PIXI.Sprite(texture);
            sprite._sundBgLiteLiveSprite = true;

            entry.sprite = sprite;
            entry.bitmap = null;
            entry.live = {
                THREE, LoaderClass, renderer, scene, camera, target, model, gltf, texture,
                ambient, directional, renderWidth: renderW, renderHeight: renderH
            };
            log('常駐3D背景を読み込みました。', entry.id, `${renderW}x${renderH}`);
        },

        resizeLiveModel(entry) {
            if (!entry || !entry.live || !entry.live.renderer) return;
            const args = entry.modelArgs || {};
            const displayW = entry.width || screenWidth();
            const displayH = entry.height || screenHeight();
            const renderW = clamp(toNumber(args.renderWidth, displayW) || displayW, 64, P.maxCaptureWidth);
            const renderH = clamp(toNumber(args.renderHeight, displayH) || displayH, 64, P.maxCaptureHeight);
            const live = entry.live;
            if (renderW === live.renderWidth && renderH === live.renderHeight) return;
            live.renderWidth = renderW;
            live.renderHeight = renderH;
            live.renderer.setSize(renderW, renderH, false);
            live.camera.aspect = renderW / Math.max(1, renderH);
            live.camera.updateProjectionMatrix();
            if (live.texture && live.texture.baseTexture && live.texture.baseTexture.update) {
                live.texture.baseTexture.update();
            }
        },

        updateLiveModel(entry) {
            if (!entry || !entry.loaded || !entry.live) return;
            if (entry.continuousRender || entry.needsRender) {
                this.renderLiveModel(entry);
            }
        },

        renderLiveModel(entry) {
            if (!entry || !entry.live) return;
            const live = entry.live;
            live.renderer.render(live.scene, live.camera);
            if (live.texture && live.texture.baseTexture && live.texture.baseTexture.update) {
                live.texture.baseTexture.update();
            }
            entry.needsRender = false;
        },

        status(id) {
            const key = String(id || '');
            const entry = this._entries.get(key);
            const scene = SceneManager && SceneManager._scene ? SceneManager._scene : null;
            const result = {
                id: key,
                exists: !!entry,
                visible: false,
                code: 0,
                reason: 'not_checked',
                detail: {}
            };

            const fail = (code, reason, detail = {}) => {
                result.visible = false;
                result.code = code;
                result.reason = reason;
                result.detail = Object.assign(result.detail || {}, detail);
                return result;
            };
            const pass = (detail = {}) => {
                result.visible = true;
                result.code = 1;
                result.reason = 'visible';
                result.detail = Object.assign(result.detail || {}, detail);
                return result;
            };

            if (!key) return fail(10, 'id_empty');
            if (!entry) {
                return fail(11, 'not_registered', {
                    registeredIds: Array.from(this._entries.keys())
                });
            }

            const sprite = entry.sprite;
            const bitmap = entry.bitmap || (sprite && sprite.bitmap) || null;
            const live = entry.live || null;
            const layer = normalizeLayer(entry.layer);
            const dw = entry.width || screenWidth();
            const dh = entry.height || screenHeight();
            const sx = entry.x;
            const sy = entry.y;
            const screen = { width: screenWidth(), height: screenHeight() };

            result.detail = {
                id: entry.id,
                type: entry.type,
                layer,
                entryVisible: !!entry.visible,
                entryOpacity: entry.opacity,
                x: sx,
                y: sy,
                z: entry.z || 0,
                scale: entry.scale || 1,
                rotationX: entry.rotationX || 0,
                rotationY: entry.rotationY || 0,
                rotationZ: entry.rotationZ || 0,
                width: dw,
                height: dh,
                screen,
                loading: !!entry.loading,
                loaded: !!entry.loaded,
                error: entry.error ? String(entry.error.message || entry.error) : '',
                threeEnv: entry.threeEnv || null,
                hasScene: !!scene,
                hasSprite: !!sprite,
                hasBitmap: !!bitmap,
                hasLiveRenderer: !!(live && live.renderer),
                hasVrmSceneModel: !!(entry.vrmScene && entry.vrmScene.model),
                continuousRender: !!entry.continuousRender,
                needsRender: !!entry.needsRender,
                spriteParent: sprite && sprite.parent ? (sprite.parent.constructor && sprite.parent.constructor.name) || 'Container' : '',
                bitmapReady: bitmap && bitmap.isReady ? !!bitmap.isReady() : false,
                bitmapError: bitmap && bitmap.isError ? !!bitmap.isError() : false,
                bitmapWidth: bitmap ? bitmap.width : 0,
                bitmapHeight: bitmap ? bitmap.height : 0,
                liveRenderWidth: live ? live.renderWidth : 0,
                liveRenderHeight: live ? live.renderHeight : 0
            };

            if (entry.type === 'vrmSceneModel') {
                const runtime = this.getVrmRuntime();
                result.detail.hasSundVrm = !!runtime.api;
                result.detail.hasVrmScene = !!runtime.scene;
                if (entry.error) return fail(80, 'vrm_scene_model_error');
                if (entry.loading) return fail(81, 'vrm_scene_model_loading');
                if (!entry.loaded) return fail(82, 'vrm_scene_model_not_loaded');
                if (!entry.vrmScene || !entry.vrmScene.model) return fail(83, 'vrm_scene_model_missing');
                if (!entry.visible || !entry.vrmScene.model.visible) return fail(84, 'vrm_scene_model_hidden');
                if (!runtime.scene) return fail(85, 'sund_vrm_scene_missing');
                if (entry.vrmScene.model.parent !== runtime.scene) return fail(86, 'vrm_scene_model_not_added_to_sund_scene');
                return pass({
                    note: 'SunD_VRMと同じTHREE.Sceneに追加されています。VRMとの前後関係は3D座標とdepthTestで決まります。'
                });
            }

            if (!sprite) return fail(20, 'sprite_missing');
            if (!entry.visible) return fail(21, 'entry_hidden');
            if (!sprite.visible) return fail(22, 'sprite_hidden');
            if (entry.opacity <= 0 || sprite.opacity <= 0) return fail(23, 'opacity_zero');
            if (!bitmap && entry.type !== 'liveModel') return fail(24, 'bitmap_missing');

            if (entry.type === 'png') {
                if (bitmap.isError && bitmap.isError()) return fail(30, 'png_load_error');
                if (bitmap.isReady && !bitmap.isReady()) return fail(31, 'png_loading');
                if (!bitmap.width || !bitmap.height) return fail(32, 'png_size_zero');
            }

            if (entry.type === 'model') {
                if (entry.error) return fail(40, 'model_error');
                if (entry.loading) return fail(41, 'model_loading');
                if (!entry.loaded) return fail(42, 'model_not_loaded');
                if (!bitmap.width || !bitmap.height) return fail(43, 'model_bitmap_size_zero');
            }

            if (entry.type === 'liveModel') {
                if (entry.error) return fail(70, 'live_model_error');
                if (entry.loading) return fail(71, 'live_model_loading');
                if (!entry.loaded) return fail(72, 'live_model_not_loaded');
                if (!entry.live || !entry.live.renderer) return fail(73, 'live_renderer_missing');
            }

            if (!scene) return fail(50, 'scene_missing');
            if (!sprite.parent) return fail(51, 'sprite_not_added_to_scene');

            if (sx + dw <= 0 || sy + dh <= 0 || sx >= screen.width || sy >= screen.height) {
                return fail(60, 'offscreen', {
                    rect: { x: sx, y: sy, width: dw, height: dh }
                });
            }

            const roots = scene._sundBgLiteRoots || null;
            const expectedRoot = roots ? roots[layer] : null;
            if (expectedRoot && sprite.parent !== expectedRoot) {
                return fail(61, 'wrong_layer_parent', {
                    expectedLayer: layer
                });
            }

            return pass({
                rect: { x: sx, y: sy, width: dw, height: dh },
                note: 'This means the plugin sprite is in a drawable state. Another front layer, fade sprite, picture, or window may still cover it.'
            });
        },

        checkStatus(args) {
            const result = this.status(args.id);
            const setVar = (variableId, value) => {
                const n = Number(variableId || 0);
                if (n > 0 && window.$gameVariables) $gameVariables.setValue(n, value);
            };
            setVar(args.visibleVariableId, result.visible ? 1 : 0);
            setVar(args.codeVariableId, result.code);
            setVar(args.reasonVariableId, result.reason);
            setVar(args.detailVariableId, JSON.stringify(result.detail || {}));
            if (toBool(args.dumpConsole, true)) {
                const fn = result.visible ? console.log : console.warn;
                fn.call(console, '[SunD_BackgroundLite] CheckBackgroundStatus', result);
            }
            return result;
        },


        check3DEnvironment(args) {
            const env = this.detect3DEnvironment();
            const setVar = (variableId, value) => {
                const n = Number(variableId || 0);
                if (n > 0 && window.$gameVariables) $gameVariables.setValue(n, value);
            };
            setVar(args.readyVariableId, env.ready ? 1 : 0);
            setVar(args.codeVariableId, env.code);
            setVar(args.reasonVariableId, env.reason);
            setVar(args.detailVariableId, JSON.stringify(env.detail || {}));
            if (toBool(args.dumpConsole, true)) {
                const fn = env.ready ? console.log : console.warn;
                fn.call(console, '[SunD_BackgroundLite] Check3DEnvironment', env.detail);
            }
            return env.detail;
        },
        dumpStatus(id) {
            const key = String(id || '');
            if (key) {
                console.log('[SunD_BackgroundLite] BackgroundStatus', this.status(key));
                return;
            }
            const results = Array.from(this._entries.keys()).map(k => this.status(k));
            console.log('[SunD_BackgroundLite] BackgroundStatusList', results);
            if (results.length === 0) {
                console.warn('[SunD_BackgroundLite] 登録中の背景はありません。ShowPngBackground / ShowModelBackground が実行されていない可能性があります。');
            }
        }
    };

    window.SunD_BackgroundLite = Manager;
    Manager.reloadExternalConfig();
    Manager.installVrmSceneRenderBridge();

    PluginManager.registerCommand(pluginName, 'ShowPngBackground', args => {
        Manager.showPng(args);
    });

    PluginManager.registerCommand(pluginName, 'ShowModelBackground', args => {
        Manager.showModel(args);
    });

    PluginManager.registerCommand(pluginName, 'ShowLiveModelBackground', args => {
        Manager.showLiveModel(args);
    });

    PluginManager.registerCommand(pluginName, 'ShowVrmSceneModelBackground', args => {
        Manager.showVrmSceneModel(args);
    });

    PluginManager.registerCommand(pluginName, 'ShowVrmSceneModelBackgroundByKey', args => {
        Manager.showVrmSceneModelByKey(args);
    });

    PluginManager.registerCommand(pluginName, 'SetVrmSceneModelTransform', args => {
        Manager.setVrmSceneTransform(args);
    });

    PluginManager.registerCommand(pluginName, 'SetVrmSceneModelVisual', args => {
        Manager.setVrmSceneVisual(args);
    });

    PluginManager.registerCommand(pluginName, 'RefreshModelBackground', args => {
        Manager.refreshModel(args.id);
    });

    PluginManager.registerCommand(pluginName, 'SetBackgroundTransform', args => {
        Manager.setTransform(args);
    });

    PluginManager.registerCommand(pluginName, 'HideBackground', args => {
        Manager.hide(args.id, toBool(args.dispose, true));
    });

    PluginManager.registerCommand(pluginName, 'CheckBackgroundStatus', args => {
        Manager.checkStatus(args);
    });

    PluginManager.registerCommand(pluginName, 'DumpBackgroundStatus', args => {
        Manager.dumpStatus(args.id);
    });

    PluginManager.registerCommand(pluginName, 'Check3DEnvironment', args => {
        Manager.check3DEnvironment(args);
    });

    PluginManager.registerCommand(pluginName, 'ClearBackgrounds', () => {
        Manager.clear();
    });

    const _Scene_Base_update = Scene_Base.prototype.update;
    Scene_Base.prototype.update = function() {
        _Scene_Base_update.call(this);
        Manager.updateScene(this);
    };
})();
