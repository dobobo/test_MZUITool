/*:
 * @target MZ
 * @plugindesc すり抜け(Through)でも指定リージョンを進入不可にする v1.1（条件スイッチ対応）
 * @author DB
 *
 * @help
 * ■概要
 * - キャラクターが「すり抜け状態(Through ON)」でも、指定したリージョンIDのマスを進入不可にします。
 * - 例：デバッグ用すり抜け移動は許可したいが、「立入禁止リージョン」だけは絶対入れたくない場合に使えます。
 *
 * ■追加（v1.1）
 * - 「条件スイッチID」を指定すると、そのスイッチがONのときだけ本機能が有効になります。
 * - 条件スイッチIDが 0 の場合は、常に有効（従来通り）です。
 *
 * ■特徴
 * - 対象：プレイヤーのみ / プレイヤー+フォロワー / イベント / 全て を選択できます。
 * - 「すり抜け時だけブロック」or「常にブロック（すり抜けでも通常でも）」を選択できます。
 * - ゲーム中にプラグインコマンドで設定変更できます（セーブに保存されます）。
 *
 * ■注意
 * - このプラグインは「リージョン禁止」を最優先にします。
 *   つまり、対象キャラが Through ON でも、禁止リージョンへは進めません。
 *
 * ------------------------------------------------------------------
 * @param Enabled
 * @text 有効
 * @type boolean
 * @default true
 *
 * @param ConditionSwitchId
 * @text 条件スイッチID（ONの時だけ有効）
 * @type switch
 * @default 0
 * @desc 0=常に有効。1以上=そのスイッチがONの間だけ有効。
 *
 * @param BlockedRegions
 * @text 進入不可リージョンID（カンマ区切り）
 * @type string
 * @default 0
 *
 * @param BlockMode
 * @text ブロック方式
 * @type select
 * @option すり抜け時だけブロック
 * @value through_only
 * @option 常にブロック（通常でも）
 * @value always
 * @default through_only
 *
 * @param TargetScope
 * @text 対象キャラ
 * @type select
 * @option プレイヤーのみ
 * @value player
 * @option プレイヤー+フォロワー
 * @value party
 * @option イベントのみ
 * @value events
 * @option 全て（プレイヤー/フォロワー/イベント）
 * @value all
 * @default player
 *
 * ------------------------------------------------------------------
 * @command SetEnabled
 * @text 有効/無効切替
 * @arg enabled
 * @text 有効
 * @type boolean
 * @default true
 *
 * @command SetBlockedRegions
 * @text 進入不可リージョンをまとめて設定
 * @arg regions
 * @text リージョンID（カンマ区切り）
 * @type string
 * @default 0
 *
 * @command AddBlockedRegion
 * @text 進入不可リージョンを追加
 * @arg regionId
 * @text リージョンID
 * @type number
 * @default 0
 *
 * @command RemoveBlockedRegion
 * @text 進入不可リージョンを削除
 * @arg regionId
 * @text リージョンID
 * @type number
 * @default 0
 *
 * @command SetBlockMode
 * @text ブロック方式を設定
 * @arg mode
 * @text モード
 * @type select
 * @option すり抜け時だけブロック
 * @value through_only
 * @option 常にブロック（通常でも）
 * @value always
 * @default through_only
 *
 * @command SetTargetScope
 * @text 対象キャラを設定
 * @arg scope
 * @text 対象
 * @type select
 * @option プレイヤーのみ
 * @value player
 * @option プレイヤー+フォロワー
 * @value party
 * @option イベントのみ
 * @value events
 * @option 全て
 * @value all
 * @default player
 */

(() => {
  "use strict";

  const PLUGIN_NAME = document.currentScript.src.split("/").pop().replace(/\.js$/, "");
  const params = PluginManager.parameters(PLUGIN_NAME);

  // ------------------------------------------------------------
  // Util
  // ------------------------------------------------------------
  function parseRegionList(text) {
    const s = String(text ?? "").trim();
    if (!s || s === "0") return [];
    return s
      .split(",")
      .map(v => Number(String(v).trim()))
      .filter(n => Number.isFinite(n) && n > 0);
  }

  function uniq(arr) {
    return Array.from(new Set(arr));
  }

  // ------------------------------------------------------------
  // Save-backed settings (Game_System に持たせる)
  // ------------------------------------------------------------
  const DEFAULTS = {
    enabled: String(params.Enabled || "true") === "true",
    conditionSwitchId: Number(params.ConditionSwitchId || 0) || 0, // 0=always
    blockedRegions: parseRegionList(params.BlockedRegions || "0"),
    blockMode: String(params.BlockMode || "through_only"), // through_only | always
    targetScope: String(params.TargetScope || "player"),   // player | party | events | all
  };

  const _Game_System_initialize = Game_System.prototype.initialize;
  Game_System.prototype.initialize = function() {
    _Game_System_initialize.call(this);
    if (!this._regionBlocker) {
      this._regionBlocker = {
        enabled: DEFAULTS.enabled,
        conditionSwitchId: DEFAULTS.conditionSwitchId,
        blockedRegions: DEFAULTS.blockedRegions.slice(),
        blockMode: DEFAULTS.blockMode,
        targetScope: DEFAULTS.targetScope,
      };
    } else {
      // 既存セーブ互換：古いセーブに項目が無ければ補完
      if (this._regionBlocker.conditionSwitchId == null) {
        this._regionBlocker.conditionSwitchId = DEFAULTS.conditionSwitchId;
      }
    }
  };

  function state() {
    // セーブ前でも安全
    if (!$gameSystem._regionBlocker) {
      $gameSystem._regionBlocker = {
        enabled: DEFAULTS.enabled,
        conditionSwitchId: DEFAULTS.conditionSwitchId,
        blockedRegions: DEFAULTS.blockedRegions.slice(),
        blockMode: DEFAULTS.blockMode,
        targetScope: DEFAULTS.targetScope,
      };
    } else if ($gameSystem._regionBlocker.conditionSwitchId == null) {
      // 既存セーブ互換
      $gameSystem._regionBlocker.conditionSwitchId = DEFAULTS.conditionSwitchId;
    }
    return $gameSystem._regionBlocker;
  }

  function isConditionOk() {
    const s = state();
    if (!s.enabled) return false;
    const sw = Number(s.conditionSwitchId || 0);
    if (!Number.isFinite(sw) || sw <= 0) return true; // 0=常に有効
    return !!$gameSwitches.value(sw);
  }

  function isTargetCharacter(ch) {
    const s = state();
    switch (s.targetScope) {
      case "player":
        return (ch instanceof Game_Player);
      case "party":
        return (ch instanceof Game_Player) || (ch instanceof Game_Follower);
      case "events":
        return (ch instanceof Game_Event);
      case "all":
        return (ch instanceof Game_Player) || (ch instanceof Game_Follower) || (ch instanceof Game_Event);
      default:
        return (ch instanceof Game_Player);
    }
  }

  function isBlockedRegionXY(x, y) {
    const s = state();
    const rid = $gameMap.regionId(x, y);
    return (s.blockedRegions || []).includes(rid);
  }

  // ------------------------------------------------------------
  // Core: canPass をフックして Through より先に判定する
  // ------------------------------------------------------------
  const _Game_CharacterBase_canPass = Game_CharacterBase.prototype.canPass;
  Game_CharacterBase.prototype.canPass = function(x, y, d) {
    const s = state();

    if (isConditionOk() && isTargetCharacter(this)) {
      const x2 = $gameMap.roundXWithDirection(x, d);
      const y2 = $gameMap.roundYWithDirection(y, d);

      const shouldBlock =
        (s.blockMode === "always") ? true :
        (s.blockMode === "through_only") ? this.isThrough() : true;

      if (shouldBlock && isBlockedRegionXY(x2, y2)) {
        return false;
      }
    }

    return _Game_CharacterBase_canPass.call(this, x, y, d);
  };

  // ------------------------------------------------------------
  // Plugin Commands
  // ------------------------------------------------------------
  PluginManager.registerCommand(PLUGIN_NAME, "SetEnabled", args => {
    const s = state();
    s.enabled = String(args.enabled ?? "true") === "true";
  });

  PluginManager.registerCommand(PLUGIN_NAME, "SetBlockedRegions", args => {
    const s = state();
    s.blockedRegions = uniq(parseRegionList(args.regions ?? "0"));
  });

  PluginManager.registerCommand(PLUGIN_NAME, "AddBlockedRegion", args => {
    const s = state();
    const id = Number(args.regionId || 0);
    if (Number.isFinite(id) && id > 0) {
      s.blockedRegions = uniq([...(s.blockedRegions || []), id]);
    }
  });

  PluginManager.registerCommand(PLUGIN_NAME, "RemoveBlockedRegion", args => {
    const s = state();
    const id = Number(args.regionId || 0);
    s.blockedRegions = (s.blockedRegions || []).filter(r => r !== id);
  });

  PluginManager.registerCommand(PLUGIN_NAME, "SetBlockMode", args => {
    const s = state();
    const mode = String(args.mode || "through_only");
    s.blockMode = (mode === "always") ? "always" : "through_only";
  });

  PluginManager.registerCommand(PLUGIN_NAME, "SetTargetScope", args => {
    const s = state();
    const scope = String(args.scope || "player");
    const allowed = ["player", "party", "events", "all"];
    s.targetScope = allowed.includes(scope) ? scope : "player";
  });

})();
