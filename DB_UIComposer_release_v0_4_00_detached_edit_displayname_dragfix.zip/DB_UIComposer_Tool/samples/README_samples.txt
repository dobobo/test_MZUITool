DB_UIComposer samples / tutorial

[v0.3.83]
チュートリアル系サンプルを追加しました。

サンプル読込から選べる主なサンプル:
- Tutorial_01：シーン・グループ・ウィンドウの考え方
- Tutorial_02：パーツ種類とプロパティ確認
- Tutorial_03：保存・読込・再利用の流れ
- Basic_Status：基本ステータス画面
- Gauge_Sample：ゲージ一覧
- Log_Sample：ログ表示

おすすめの見方:
1. Tutorial_01 を読み込む
2. 左の一覧でシーン、グループ、ウィンドウを選ぶ
3. 右側プロパティを見ながら、説明テキストの内容と対応を確認する
4. Tutorial_02 でパーツごとの設定を見る
5. Tutorial_03 で保存/読込の流れを試す

DB_UIComposer Samples v0.3.80

まずはツール上部の「サンプル読込」から Basic_Status を読み込んでください。

同梱サンプル:
- scenes/Basic_Status.scene : 基本ステータス画面。構造理解用です。
- scenes/Gauge_Sample.scene : 横・縦・円ゲージの確認用です。
- scenes/Log_Sample.scene : ログパーツの確認用です。

部品単体:
- groups/HP_MP_TP_Gauge.group
- windows/Status_Panel.window
- parts/Circle_TP_Gauge.parts
- parts/Log_Item.parts

各ファイルは、一覧の読込アイコンからも読み込めます。
